import os
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from openai import OpenAI

app = FastAPI(title="Invest AI Financial Analyst")
client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

SYSTEM = """Eres el Analista IA de Invest AI, especializado en análisis financiero y mercados de capitales. Responde en español, de forma clara y rigurosa. Explica los datos antes de sacar conclusiones. Usa valoración, crecimiento/beneficios, salud financiera, momentum técnico, revisiones de analistas, noticias/sentimiento y riesgo/volatilidad. Distingue hechos, cálculos, hipótesis y opiniones de terceros. No inventes precios, resultados ni noticias. Si no tienes un dato actual, dilo. No conviertas una puntuación en una probabilidad de beneficio. Para una posición, explica qué tendría que deteriorarse para pasar de mantener a vigilar, preparar salida o salida. No ejecutes operaciones. Si la pregunta requiere información actual, puedes usar búsqueda web cuando esté disponible. El objetivo es ayudar al usuario a interpretar la información, no sustituir su decisión."""

class Chat(BaseModel):
    question: str
    portfolio: str = ""
    app_context: str = ""

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/chat")
def chat(body: Chat):
    if not os.environ.get("OPENAI_API_KEY"):
        raise HTTPException(status_code=500, detail="OPENAI_API_KEY no configurada")
    prompt = f"Contexto de cartera: {body.portfolio}\nContexto de Invest AI: {body.app_context}\n\nPregunta del usuario: {body.question}"
    response = client.responses.create(
        model="gpt-5.6-sol",
        instructions=SYSTEM,
        input=prompt,
        tools=[{"type": "web_search"}],
    )
    return {"answer": response.output_text}
