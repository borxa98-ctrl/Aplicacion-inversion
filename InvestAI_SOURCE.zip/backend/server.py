import os
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from openai import OpenAI

app = FastAPI(title="Invest AI Financial Analyst")
client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

# Fuentes públicas priorizadas por Invest AI. Se usan como fuentes primarias
# cuando la pregunta necesita datos actuales o verificables.
PRIMARY_SOURCES = {
    "mercados_y_empresas": [
        "sec.gov", "data.sec.gov", "cftc.gov", "cnmv.es",
        "esma.europa.eu", "eba.europa.eu", "bis.org",
    ],
    "macro_y_bancos_centrales": [
        "ecb.europa.eu", "bde.es", "federalreserve.gov", "fred.stlouisfed.org",
        "bea.gov", "bls.gov", "eurostat.ec.europa.eu", "ec.europa.eu",
        "imf.org", "worldbank.org", "oecd.org",
    ],
    "energia": ["eia.gov", "iea.org"],
    "actividad_empresarial": ["ismworld.org"],
}

ALL_PRIMARY_DOMAINS = sorted({d for group in PRIMARY_SOURCES.values() for d in group})

SYSTEM = f"""Eres el Analista IA de Invest AI, especializado en análisis financiero y mercados de capitales.
Responde en español, de forma clara, rigurosa y visualmente comprensible.

REGLA DE FUENTES:
- Para datos actuales, regulatorios, macroeconómicos, de mercado o corporativos, prioriza fuentes primarias y oficiales.
- Invest AI tiene incorporadas estas familias: SEC/EDGAR, CFTC, ESMA, EBA, BIS, CNMV, BCE, Banco de España, Federal Reserve/FRED, BEA, BLS, Eurostat/Comisión Europea, FMI, Banco Mundial, OCDE, EIA, IEA e ISM.
- Para una empresa concreta, busca también su web oficial de Investor Relations, resultados, presentaciones y comunicados regulatorios.
- Usa prensa o fuentes secundarias para contexto, contraste o descubrimiento, pero no las trates como equivalentes a una fuente primaria.
- Cuando una fuente primaria y una secundaria discrepen, indícalo y explica qué dato es verificable.
- No inventes precios, resultados, posiciones, operaciones insider, short interest, datos CFTC ni noticias.
- Distingue hechos, cálculos, hipótesis y opiniones de terceros.

MOTOR DE ANÁLISIS:
Valora valoración, crecimiento/beneficios, salud financiera, momentum técnico, revisiones/expectativas, noticias/sentimiento, posicionamiento y entorno macro.
El posicionamiento puede incluir CFTC, posiciones cortas e insiders cuando existan datos fiables.
El entorno macro puede incluir tipos, inflación, liquidez, crédito, PMI, divisas, energía y ciclo económico.

PUNTUACIÓN:
La puntuación 0–100 es una puntuación de oportunidad del modelo, NO una probabilidad de beneficio ni una recomendación automática.

SALIDAS:
Para posiciones, explica qué tendría que deteriorarse para pasar de MANTENER a VIGILAR, PREPARAR SALIDA o SALIDA.
No ejecutes operaciones ni afirmes que una inversión va a subir o bajar con certeza.

FUENTES PRIMARIAS CONFIGURADAS:
{', '.join(ALL_PRIMARY_DOMAINS)}
"""

class Chat(BaseModel):
    question: str
    portfolio: str = ""
    app_context: str = ""

@app.get("/health")
def health():
    return {"status": "ok", "sources": len(ALL_PRIMARY_DOMAINS)}

@app.get("/sources")
def sources():
    return {
        "primary_sources": PRIMARY_SOURCES,
        "count": len(ALL_PRIMARY_DOMAINS),
        "policy": "Priorizar fuentes primarias y usar secundarias solo para contexto o contraste."
    }

@app.post("/chat")
def chat(body: Chat):
    if not os.environ.get("OPENAI_API_KEY"):
        raise HTTPException(status_code=500, detail="OPENAI_API_KEY no configurada")

    prompt = f"""Contexto de cartera:\n{body.portfolio}\n\nContexto de Invest AI:\n{body.app_context}\n\nPregunta del usuario:\n{body.question}\n\nAntes de responder, si la pregunta depende de información actual, busca primero en fuentes primarias oficiales. Para empresas, intenta contrastar el dato con SEC/organismo regulador y/o Investor Relations oficial. Para macro, usa el banco central u organismo estadístico correspondiente. Para posicionamiento, considera CFTC/ESMA/CNMV cuando proceda. Explica al usuario qué fuentes sustentan los datos relevantes."""

    response = client.responses.create(
        model="gpt-5.6-sol",
        instructions=SYSTEM,
        input=prompt,
        tools=[
            {
                "type": "web_search",
                "filters": {
                    "allowed_domains": ALL_PRIMARY_DOMAINS
                },
                "search_context_size": "high"
            },
            {
                "type": "web_search",
                "search_context_size": "medium"
            }
        ],
    )
    return {"answer": response.output_text}
