import os
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from google import genai
from google.genai import types

app = FastAPI(title="Invest AI Financial Analyst")
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")
client = genai.Client(api_key=GEMINI_API_KEY) if GEMINI_API_KEY else None
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-2.5-flash")

# Fuentes públicas priorizadas por Invest AI. Se usan como fuentes primarias
# cuando la pregunta necesita datos actuales o verificables.
PRIMARY_SOURCES = {
    "mercados_y_empresas": [
        "sec.gov", "data.sec.gov", "cftc.gov", "cnmv.es",
        "esma.europa.eu", "eba.europa.eu", "bis.org",
    ],
    "macro_y_bancos_centrales": [
        "ecb.europa.eu", "bde.es", "federalreserve.gov", "fred.stlouisfed.org",
        "bea.gov", "bls.gov", "eurostat.ec.europa.eu", "ec.europa.eu",
        "imf.org", "worldbank.org", "oecd.org",
    ],
    "energia": ["eia.gov", "iea.org"],
    "actividad_empresarial": ["ismworld.org"],
}

ALL_PRIMARY_DOMAINS = sorted({d for group in PRIMARY_SOURCES.values() for d in group})

SYSTEM = f"""Eres el Analista IA de Invest AI, especializado en análisis financiero y mercados de capitales.
Responde en español, de forma clara, rigurosa y visualmente comprensible.

REGLA DE FUENTES:
- Para datos actuales, regulatorios, macroeconómicos, de mercado o corporativos, prioriza fuentes primarias y oficiales.
- Invest AI tiene incorporadas estas familias: SEC/EDGAR, CFTC, ESMA, EBA, BIS, CNMV, BCE, Banco de España, Federal Reserve/FRED, BEA, BLS, Eurostat/Comisión Europea, FMI, Banco Mundial, OCDE, EIA, IEA e ISM.
- Para una empresa concreta, busca también su web oficial de Investor Relations, resultados, presentaciones y comunicados regulatorios.
- Usa prensa o fuentes secundarias para contexto, contraste o descubrimiento, pero no las trates como equivalentes a una fuente primaria.
- Cuando una fuente primaria y una secundaria discrepen, indícalo y explica qué dato es verificable.
- No inventes precios, resultados, posiciones, operaciones insider, short interest, datos CFTC ni noticias.
- Distingue hechos, cálculos, hipótesis y opiniones de terceros.

MOTOR DE ANÁLISIS:
Valora valoración, crecimiento/beneficios, salud financiera, momentum técnico, revisiones/expectativas, noticias/sentimiento, posicionamiento y entorno macro.
El posicionamiento puede incluir CFTC, posiciones cortas e insiders cuando existan datos fiables.
El entorno macro puede incluir tipos, inflación, liquidez, crédito, PMI, divisas, energía y ciclo económico.

PUNTUACIÓN:
La puntuación 0–100 es una puntuación de oportunidad del modelo, NO una probabilidad de beneficio ni una recomendación automática.

SALIDAS:
Para posiciones, explica qué tendría que deteriorarse para pasar de MANTENER a VIGILAR, PREPARAR SALIDA o SALIDA.
No ejecutes operaciones ni afirmes que una inversión va a subir o bajar con certeza.

FUENTES PRIMARIAS CONFIGURADAS:
{', '.join(ALL_PRIMARY_DOMAINS)}
"""

class Chat(BaseModel):
    question: str
    portfolio: str = ""
    app_context: str = ""

@app.get("/health")
def health():
    return {"status": "ok", "sources": len(ALL_PRIMARY_DOMAINS), "provider": "Gemini + Google Search", "model": GEMINI_MODEL, "configured": bool(GEMINI_API_KEY)}

@app.get("/sources")
def sources():
    return {
        "primary_sources": PRIMARY_SOURCES,
        "count": len(ALL_PRIMARY_DOMAINS),
        "policy": "Priorizar fuentes primarias y usar secundarias solo para contexto o contraste."
    }


def _news_prompt():
    return """Busca las noticias financieras y empresariales más relevantes y recientes para los mercados que sigue Invest AI: S&P 500, Nasdaq-100, Dow Jones, Russell 2000, EURO STOXX 50, STOXX Europe 600, DAX 40, FTSE 100, CAC 40, IBEX 35, SMI, Nikkei 225, TOPIX, Hang Seng y S&P/ASX 200.

Devuelve exactamente un JSON válido con este formato: {\"items\":[{\"title\":\"...\",\"source\":\"...\",\"date\":\"...\",\"url\":\"https://...\",\"why\":\"...\"}]}

Condiciones:
- Máximo 6 titulares.
- Prioriza información de las últimas 48 horas cuando exista.
- Prioriza fuentes oficiales, regulatorias y webs oficiales de Investor Relations.
- Para contexto de mercado puedes usar medios financieros públicos y otras fuentes secundarias, pero identifica claramente la fuente.
- No inventes titulares, fechas ni URLs.
- Cada titular debe explicar brevemente por qué puede importar al mercado en el campo why (máximo 120 caracteres).
- No uses markdown, comentarios ni texto fuera del JSON."""

@app.get("/news")
def news():
    if not GEMINI_API_KEY or client is None:
        raise HTTPException(status_code=500, detail="GEMINI_API_KEY no configurada")
    try:
        prompt = _news_prompt() + "\n\nDevuelve solo el objeto JSON solicitado."
        response = client.models.generate_content(
            model=GEMINI_MODEL,
            contents=prompt,
            config=types.GenerateContentConfig(
                system_instruction=SYSTEM + "\nPara este endpoint debes devolver únicamente JSON válido, sin markdown.",
                temperature=0.2,
                response_mime_type="application/json",
                tools=[types.Tool(google_search=types.GoogleSearch())],
            ),
        )
        text = (response.text or "").strip()
        start = text.find("{")
        end = text.rfind("}")
        if start < 0 or end <= start:
            raise ValueError("La respuesta de Gemini no contiene un objeto JSON válido")
        data = __import__("json").loads(text[start:end+1])
        if not isinstance(data, dict) or not isinstance(data.get("items"), list):
            raise ValueError("Formato de noticias no válido")
        from datetime import datetime, timezone
        data["updated_at"] = datetime.now(timezone.utc).astimezone().strftime("%d/%m/%Y %H:%M")
        data["provider"] = "Gemini + Google Search"
        return data
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"No se pudieron actualizar las noticias: {exc}")

@app.post("/chat")
def chat(body: Chat):
    if not GEMINI_API_KEY or client is None:
        raise HTTPException(status_code=500, detail="GEMINI_API_KEY no configurada")

    prompt = f"""Contexto de cartera:\n{body.portfolio}\n\nContexto de Invest AI:\n{body.app_context}\n\nPregunta del usuario:\n{body.question}\n\nSi la pregunta depende de información actual, usa Google Search para verificarla. Prioriza fuentes primarias oficiales. Para empresas, contrasta con SEC/organismo regulador y/o Investor Relations oficial. Para macro, usa el banco central u organismo estadístico correspondiente. Para posicionamiento, considera CFTC/ESMA/CNMV cuando proceda. Explica las fuentes relevantes y distingue hechos, cálculos e hipótesis."""

    try:
        response = client.models.generate_content(
            model=GEMINI_MODEL,
            contents=prompt,
            config=types.GenerateContentConfig(
                system_instruction=SYSTEM,
                temperature=0.3,
                tools=[types.Tool(google_search=types.GoogleSearch())],
            ),
        )
        return {"answer": response.text or "Gemini no devolvió contenido.", "provider": "Gemini + Google Search"}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"No se pudo consultar Gemini: {exc}")
