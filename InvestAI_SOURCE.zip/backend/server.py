import json
import os
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from google import genai
from google.genai import types

app = FastAPI(title="Invest AI Financial Analyst")
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")
client = genai.Client(api_key=GEMINI_API_KEY) if GEMINI_API_KEY else None
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-3.6-flash")

# News/cache/quota settings. Google Search grounding can execute multiple searches
# for one Gemini request, so we keep a safety reserve below Google's 5,000/month figure.
CACHE_DIR = Path(os.environ.get("INVESTAI_CACHE_DIR", "/tmp/investai_cache"))
CACHE_DIR.mkdir(parents=True, exist_ok=True)
NEWS_CACHE_FILE = CACHE_DIR / "news.json"
USAGE_FILE = CACHE_DIR / "search_usage.json"
MONTHLY_SEARCH_BUDGET = int(os.environ.get("MONTHLY_SEARCH_BUDGET", "4000"))
REFRESH_INTERVAL_SECONDS = int(os.environ.get("NEWS_REFRESH_INTERVAL_SECONDS", "600"))
MIN_REFRESH_INTERVAL_SECONDS = int(os.environ.get("MIN_REFRESH_INTERVAL_SECONDS", "540"))
MAX_REFRESHES_PER_DAY = int(os.environ.get("MAX_REFRESHES_PER_DAY", "96"))
_lock = threading.Lock()
_last_refresh_started = 0.0
_background_started = False

PRIMARY_SOURCES = {
    "mercados_y_empresas": ["sec.gov", "data.sec.gov", "cftc.gov", "cnmv.es", "esma.europa.eu", "eba.europa.eu", "bis.org"],
    "macro_y_bancos_centrales": ["ecb.europa.eu", "bde.es", "federalreserve.gov", "fred.stlouisfed.org", "bea.gov", "bls.gov", "eurostat.ec.europa.eu", "ec.europa.eu", "imf.org", "worldbank.org", "oecd.org"],
    "energia": ["eia.gov", "iea.org"],
    "actividad_empresarial": ["ismworld.org"],
}
ALL_PRIMARY_DOMAINS = sorted({d for group in PRIMARY_SOURCES.values() for d in group})
SYSTEM = f"""Eres el Analista IA de Invest AI, especializado en análisis financiero y mercados de capitales.
Responde en español, de forma clara, rigurosa y visualmente comprensible.
Prioriza fuentes primarias y oficiales para datos actuales, regulatorios, macroeconómicos, de mercado y corporativos.
Para empresas, busca también Investor Relations y comunicados regulatorios oficiales.
Usa fuentes secundarias solo para contexto o contraste y distingue hechos, cálculos, hipótesis y opiniones de terceros.
No inventes precios, resultados, posiciones, insiders, short interest, datos CFTC ni noticias.
La puntuación 0–100 es una puntuación de oportunidad del modelo, NO una probabilidad de beneficio ni una recomendación automática.
Para posiciones, explica qué tendría que deteriorarse para pasar de MANTENER a VIGILAR, PREPARAR SALIDA o SALIDA.
No ejecutes operaciones ni afirmes que una inversión va a subir o bajar con certeza.
Fuentes primarias configuradas: {', '.join(ALL_PRIMARY_DOMAINS)}"""

class Chat(BaseModel):
    question: str
    portfolio: str = ""
    app_context: str = ""

def _now():
    return datetime.now(timezone.utc)

def _month():
    return _now().strftime("%Y-%m")

def _day():
    return _now().strftime("%Y-%m-%d")

def _load_usage():
    default = {"month": _month(), "searches": 0, "refreshes": 0, "day": _day(), "day_refreshes": 0}
    try:
        d = json.loads(USAGE_FILE.read_text(encoding="utf-8"))
        if d.get("month") != _month():
            d = default
        if d.get("day") != _day():
            d["day"] = _day(); d["day_refreshes"] = 0
        return d
    except Exception:
        return default

def _save_usage(d):
    tmp = USAGE_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(d), encoding="utf-8")
    tmp.replace(USAGE_FILE)

def _cache_age():
    try:
        d = json.loads(NEWS_CACHE_FILE.read_text(encoding="utf-8"))
        return max(0, time.time() - float(d["updated_at_epoch"]))
    except Exception:
        return float("inf")

def _read_cache():
    try:
        d = json.loads(NEWS_CACHE_FILE.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) and isinstance(d.get("items"), list) else None
    except Exception:
        return None

def _observed_searches(response):
    # Best effort: Gemini grounding metadata exposes the web search queries when present.
    try:
        total = 0
        for c in (getattr(response, "candidates", None) or []):
            gm = getattr(c, "grounding_metadata", None)
            qs = getattr(gm, "web_search_queries", None) if gm else None
            if qs: total += len(qs)
        return max(1, total)
    except Exception:
        return 1

def _news_prompt():
    return """Busca las noticias financieras y empresariales más relevantes y recientes para S&P 500, Nasdaq-100, Dow Jones, Russell 2000, EURO STOXX 50, STOXX Europe 600, DAX 40, FTSE 100, CAC 40, IBEX 35, SMI, Nikkei 225, TOPIX, Hang Seng y S&P/ASX 200.
Devuelve exactamente JSON válido: {\"items\":[{\"title\":\"...\",\"source\":\"...\",\"date\":\"...\",\"url\":\"https://...\",\"why\":\"...\"}]}
Máximo 6 titulares. Prioriza las últimas 48 horas, fuentes oficiales/regulatorias/Investor Relations, y después fuentes financieras secundarias. No inventes titulares, fechas ni URLs. why máximo 120 caracteres. Sin markdown ni texto fuera del JSON. Sé eficiente: usa el menor número razonable de consultas de Google Search."""

def _refresh_news(reason="scheduled"):
    global _last_refresh_started
    if not GEMINI_API_KEY or client is None:
        return False, "GEMINI_API_KEY no configurada"
    now = time.time()
    with _lock:
        # La primera actualización debe poder ejecutarse aunque el servicio
        # haya arrancado hace menos de MIN_REFRESH_INTERVAL_SECONDS.
        # El cooldown solo protege cuando ya existe una caché reciente/en curso.
        # Solo aplicar cooldown si existe una caché válida con timestamp.
        # Una caché parcial/corrupta (sin updated_at_epoch) debe tratarse como
        # inexistente para permitir la primera actualización.
        cache_age = _cache_age()
        has_valid_cache = cache_age != float("inf") and _read_cache() is not None
        if has_valid_cache and now - _last_refresh_started < MIN_REFRESH_INTERVAL_SECONDS:
            return False, "refresh en cooldown"
        u = _load_usage()
        if u["searches"] >= MONTHLY_SEARCH_BUDGET:
            return False, "presupuesto mensual de búsquedas agotado"
        if u["day_refreshes"] >= MAX_REFRESHES_PER_DAY:
            return False, "límite diario de actualizaciones alcanzado"
        _last_refresh_started = now
    try:
        response = client.models.generate_content(
            model=GEMINI_MODEL,
            contents=_news_prompt(),
            config=types.GenerateContentConfig(
                system_instruction=SYSTEM + "\nDevuelve únicamente JSON válido, sin markdown.",
                temperature=0.2,
                response_mime_type="application/json",
                tools=[types.Tool(google_search=types.GoogleSearch())],
            ),
        )
        text = (response.text or "").strip()
        start, end = text.find("{"), text.rfind("}")
        if start < 0 or end <= start: raise ValueError("Gemini no devolvió JSON válido")
        data = json.loads(text[start:end + 1])
        if not isinstance(data, dict) or not isinstance(data.get("items"), list): raise ValueError("Formato de noticias no válido")
        observed = _observed_searches(response)
        data.update({"updated_at": _now().astimezone().strftime("%d/%m/%Y %H:%M"), "updated_at_epoch": time.time(), "provider": "Gemini + Google Search", "model": GEMINI_MODEL, "refresh_reason": reason})
        with _lock:
            u = _load_usage(); u["searches"] += observed; u["refreshes"] += 1; u["day_refreshes"] += 1; _save_usage(u)
            data["usage"] = {"observed_searches_month": u["searches"], "monthly_budget": MONTHLY_SEARCH_BUDGET, "refreshes_today": u["day_refreshes"], "daily_refresh_limit": MAX_REFRESHES_PER_DAY}
            tmp = NEWS_CACHE_FILE.with_suffix(".tmp"); tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8"); tmp.replace(NEWS_CACHE_FILE)
        return True, "actualizado"
    except Exception as exc:
        return False, str(exc)

def _background_loop():
    while True:
        try:
            if _cache_age() >= REFRESH_INTERVAL_SECONDS: _refresh_news("scheduled")
        except Exception:
            pass
        time.sleep(30)

@app.on_event("startup")
def startup():
    global _background_started
    if not _background_started:
        _background_started = True
        threading.Thread(target=_background_loop, daemon=True, name="investai-news-refresh").start()

@app.get("/health")
def health():
    u = _load_usage(); age = _cache_age()
    return {"status":"ok", "sources":len(ALL_PRIMARY_DOMAINS), "provider":"Gemini + Google Search", "model":GEMINI_MODEL, "configured":bool(GEMINI_API_KEY), "news_cache_age_seconds":None if age == float("inf") else int(age), "refresh_interval_seconds":REFRESH_INTERVAL_SECONDS, "monthly_search_budget":MONTHLY_SEARCH_BUDGET, "observed_searches_month":u["searches"], "refreshes_today":u["day_refreshes"], "daily_refresh_limit":MAX_REFRESHES_PER_DAY}

@app.get("/sources")
def sources():
    return {"primary_sources":PRIMARY_SOURCES, "count":len(ALL_PRIMARY_DOMAINS), "policy":"Priorizar fuentes primarias y usar secundarias solo para contexto o contraste."}

@app.get("/news")
def news():
    if not GEMINI_API_KEY or client is None: raise HTTPException(500, "GEMINI_API_KEY no configurada")
    cached = _read_cache(); age = _cache_age()
    if cached is None or age >= REFRESH_INTERVAL_SECONDS:
        ok, msg = _refresh_news("on_request")
        if ok: cached = _read_cache(); age = _cache_age()
        elif cached is None: raise HTTPException(502, f"No se pudieron obtener las noticias: {msg}")
    if cached is None: raise HTTPException(503, "Noticias todavía no disponibles")
    cached["cache_age_seconds"] = int(age) if age != float("inf") else None
    cached["cache_status"] = "fresh" if age < REFRESH_INTERVAL_SECONDS else "stale"
    return cached

@app.post("/news/refresh")
def manual_news_refresh():
    ok, msg = _refresh_news("manual")
    if not ok: return {"updated":False, "reason":msg, "health":health()}
    return {"updated":True, "news":_read_cache(), "health":health()}

@app.post("/chat")
def chat(body: Chat):
    if not GEMINI_API_KEY or client is None: raise HTTPException(500, "GEMINI_API_KEY no configurada")
    with _lock:
        u = _load_usage()
        if u["searches"] >= MONTHLY_SEARCH_BUDGET: raise HTTPException(429, "Presupuesto interno de Google Search agotado este mes; Invest AI no hará más búsquedas para evitar consumo adicional.")
    prompt = f"Contexto de cartera:\n{body.portfolio}\n\nContexto de Invest AI:\n{body.app_context}\n\nPregunta:\n{body.question}\n\nSi depende de información actual, usa Google Search y prioriza fuentes primarias oficiales. Distingue hechos, cálculos e hipótesis."
    try:
        response = client.models.generate_content(model=GEMINI_MODEL, contents=prompt, config=types.GenerateContentConfig(system_instruction=SYSTEM, temperature=0.3, tools=[types.Tool(google_search=types.GoogleSearch())]))
        observed = _observed_searches(response)
        with _lock:
            u = _load_usage(); u["searches"] += observed; _save_usage(u)
        return {"answer":response.text or "Gemini no devolvió contenido.", "provider":"Gemini + Google Search", "usage":{"observed_searches_month":u["searches"], "monthly_budget":MONTHLY_SEARCH_BUDGET}}
    except Exception as exc:
        raise HTTPException(502, f"No se pudo consultar Gemini: {exc}")
