import json
import os
import re
import threading
import time
from datetime import datetime, timezone, timedelta
from html import unescape
from pathlib import Path
from urllib.parse import quote, urlparse
from urllib.request import Request, urlopen
import xml.etree.ElementTree as ET

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from google import genai
from google.genai import types

app = FastAPI(title="Invest AI Financial Analyst")
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")
client = genai.Client(api_key=GEMINI_API_KEY) if GEMINI_API_KEY else None
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-3.6-flash")

# v4.0: news discovery is performed directly against public RSS/Atom feeds.
# Gemini receives the collected headlines/snippets and performs analysis WITHOUT
# Google Search grounding. This avoids paid Search grounding while preserving
# traceable source URLs and a source-quality policy.
CACHE_DIR = Path(os.environ.get("INVESTAI_CACHE_DIR", "/tmp/investai_cache"))
CACHE_DIR.mkdir(parents=True, exist_ok=True)
NEWS_CACHE_FILE = CACHE_DIR / "news.json"
USAGE_FILE = CACHE_DIR / "usage.json"
COLLECTOR_STATUS_FILE = CACHE_DIR / "collector_status.json"
REFRESH_INTERVAL_SECONDS = int(os.environ.get("NEWS_REFRESH_INTERVAL_SECONDS", "600"))
MAX_REFRESHES_PER_DAY = int(os.environ.get("MAX_REFRESHES_PER_DAY", "96"))
MAX_GEMINI_CALLS_PER_DAY = int(os.environ.get("MAX_GEMINI_CALLS_PER_DAY", "96"))
FETCH_TIMEOUT_SECONDS = int(os.environ.get("NEWS_FETCH_TIMEOUT_SECONDS", "12"))
MAX_ITEMS_PER_FEED = int(os.environ.get("MAX_ITEMS_PER_FEED", "12"))
_lock = threading.Lock()
_last_refresh_started = 0.0
_background_started = False

PRIMARY_SOURCES = {
    "reguladores_y_oficiales": [
        "sec.gov", "cnmv.es", "esma.europa.eu", "eba.europa.eu", "ecb.europa.eu",
        "bde.es", "federalreserve.gov", "fred.stlouisfed.org", "bea.gov", "bls.gov",
        "eurostat.ec.europa.eu", "ec.europa.eu", "imf.org", "worldbank.org", "oecd.org",
        "eia.gov", "iea.org", "ismworld.org"
    ],
    "medios_financieros_de_contraste": ["reuters.com", "apnews.com", "cnbc.com", "marketwatch.com"],
}
ALL_PRIMARY_DOMAINS = sorted({d for group in PRIMARY_SOURCES.values() for d in group})

# Public feeds. Google News RSS is used only as a free discovery/transport layer;
# Gemini does not use Google Search grounding. Queries are restricted to named
# publishers or official domains so the backend can keep source provenance.
FEEDS = [
    # Official feeds. A failure is isolated and never blocks the collector.
    # SEC publishes EDGAR/press RSS and explicitly documents RSS as an access path.
    ("SEC", "https://www.sec.gov/news/pressreleases.rss", "official"),
    ("SEC EDGAR XBRL", "https://www.sec.gov/Archives/edgar/xbrlrss.all.xml", "official"),
    ("Federal Reserve", "https://www.federalreserve.gov/feeds/press_all.xml", "official"),
    ("BLS", "https://www.bls.gov/feed/bls_latest.rss", "official"),
    ("BLS CPI", "https://www.bls.gov/feed/cpi_latest.rss", "official"),
    ("BEA", "https://apps.bea.gov/rss/rss.xml", "official"),
    ("ECB", "https://www.ecb.europa.eu/rss/press.html", "official"),
    # Reputable publisher discovery feeds. The article URL is preserved and the
    # publisher is retained as the provenance; Gemini cannot create new URLs.
    ("Reuters", "https://news.google.com/rss/search?q=" + quote("site:reuters.com (markets OR stocks OR earnings OR economy)"), "reputable_secondary"),
    ("AP", "https://news.google.com/rss/search?q=" + quote("site:apnews.com (markets OR stocks OR economy)"), "reputable_secondary"),
    ("CNBC", "https://news.google.com/rss/search?q=" + quote("site:cnbc.com (markets OR stocks OR earnings OR economy)"), "reputable_secondary"),
    ("MarketWatch", "https://news.google.com/rss/search?q=" + quote("site:marketwatch.com (stocks OR markets OR earnings)"), "reputable_secondary"),
    ("CNMV", "https://news.google.com/rss/search?q=" + quote("site:cnmv.es (mercados OR cotizadas OR hechos relevantes)"), "official_discovery"),
    ("ECB/Euro area", "https://news.google.com/rss/search?q=" + quote("site:ecb.europa.eu euro area monetary policy"), "official_discovery"),
    ("EU Commission", "https://news.google.com/rss/search?q=" + quote("site:ec.europa.eu economy finance markets"), "official_discovery"),
]

SYSTEM = f"""Eres el Analista IA de Invest AI, especializado en mercados de capitales.
Responde en español, con rigor y sin inventar información.
La información que recibes procede de un recopilador de fuentes públicas. NO tienes Google Search en esta llamada y NO debes fingir que has verificado nada fuera del material proporcionado.
Prioridad de evidencia: fuentes regulatorias/oficiales > comunicados corporativos > Reuters/AP/CNBC/MarketWatch > otros.
No conviertas un rumor en un hecho. Si una noticia importante solo tiene una fuente secundaria, indícalo como no corroborada.
Cuando dos fuentes independientes describan el mismo hecho, puedes indicar que está corroborado, pero no inventes corroboración.
Conserva siempre la URL de la fuente proporcionada.
La puntuación 0–100 es una puntuación de oportunidad del modelo, NO una probabilidad de beneficio ni una recomendación automática.
Fuentes oficiales configuradas: {', '.join(ALL_PRIMARY_DOMAINS)}"""

class Chat(BaseModel):
    question: str
    portfolio: str = ""
    app_context: str = ""


def _now(): return datetime.now(timezone.utc)
def _day(): return _now().strftime("%Y-%m-%d")

def _load_usage():
    default = {"day": _day(), "refreshes": 0, "gemini_calls": 0}
    try:
        d = json.loads(USAGE_FILE.read_text(encoding="utf-8"))
        if d.get("day") != _day(): d = default
        return d
    except Exception:
        return default

def _save_usage(d):
    tmp = USAGE_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(d), encoding="utf-8")
    tmp.replace(USAGE_FILE)

def _cache_age():
    try:
        d = json.loads(NEWS_CACHE_FILE.read_text(encoding="utf-8"))
        return max(0, time.time() - float(d["updated_at_epoch"]))
    except Exception:
        return float("inf")

def _read_cache():
    try:
        d = json.loads(NEWS_CACHE_FILE.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) and isinstance(d.get("items"), list) and d.get("updated_at_epoch") else None
    except Exception:
        return None

def _strip_html(value):
    value = unescape(value or "")
    value = re.sub(r"<[^>]+>", " ", value)
    return re.sub(r"\s+", " ", value).strip()

def _domain(url):
    try: return urlparse(url).netloc.lower().removeprefix("www.")
    except Exception: return ""

def _save_collector_status(statuses):
    try:
        payload = {"updated_at_epoch": time.time(), "statuses": statuses}
        tmp = COLLECTOR_STATUS_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        tmp.replace(COLLECTOR_STATUS_FILE)
    except Exception:
        pass


def _load_collector_status():
    try:
        d = json.loads(COLLECTOR_STATUS_FILE.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) and isinstance(d.get("statuses"), list) else {"updated_at_epoch": 0, "statuses": []}
    except Exception:
        return {"updated_at_epoch": 0, "statuses": []}


def _fetch_feed(name, url, tier):
    headers = {
        "User-Agent": "InvestAI/4.2 (news reader; contact: investai@example.invalid)",
        "Accept": "application/rss+xml, application/atom+xml, application/xml, text/xml;q=0.9, */*;q=0.1",
        "Accept-Language": "en-US,en;q=0.8,es;q=0.7",
        "Cache-Control": "no-cache",
    }
    last_error = None
    for attempt in range(2):
        req = Request(url, headers=headers)
        try:
            with urlopen(req, timeout=FETCH_TIMEOUT_SECONDS) as r:
                raw = r.read(600_000)
            root = ET.fromstring(raw)
            items = []
            for node in list(root):
                tag = node.tag.lower().split("}")[-1]
                if tag not in ("item", "entry"):
                    continue
                vals = {}
                for child in list(node):
                    key = child.tag.lower().split("}")[-1]
                    text = (child.text or "").strip()
                    if key == "link" and not text:
                        text = child.attrib.get("href", "")
                    vals[key] = text
                link = vals.get("link", "")
                if not link:
                    for child in list(node):
                        if child.tag.lower().split("}")[-1] == "link" and child.attrib.get("href"):
                            link = child.attrib["href"]
                            break
                title = _strip_html(vals.get("title", ""))
                desc = _strip_html(vals.get("description", vals.get("summary", "")))
                date = vals.get("pubdate") or vals.get("published") or vals.get("updated") or vals.get("date") or ""
                if title and link:
                    items.append({"title": title, "snippet": desc[:500], "source": name, "source_tier": tier, "date": date, "url": link, "domain": _domain(link)})
            return items[:MAX_ITEMS_PER_FEED], None
        except Exception as exc:
            last_error = exc
            if attempt == 0:
                time.sleep(0.4)
    return [], f"{name}: {last_error}"


def _collect_news():
    all_items, errors, statuses = [], [], []
    for name, url, tier in FEEDS:
        items, err = _fetch_feed(name, url, tier)
        if err:
            errors.append(err)
            statuses.append({"source": name, "status": "error", "items": 0, "error": str(err)})
        else:
            all_items.extend(items)
            statuses.append({"source": name, "status": "ok", "items": len(items)})
    _save_collector_status(statuses)
    seen, unique = set(), []
    for item in all_items:
        key = item["url"].split("#")[0] or (item["source"], item["title"].lower())
        if key in seen:
            continue
        seen.add(key)
        unique.append(item)
    return unique, errors, statuses

def _news_prompt(items):
    payload = json.dumps(items[:100], ensure_ascii=False)
    return f"""Analiza este conjunto de titulares/noticias recopilados de fuentes públicas.
Selecciona como máximo 8 noticias realmente relevantes para los índices S&P 500, Nasdaq-100, Dow Jones, Russell 2000, EURO STOXX 50, STOXX Europe 600, DAX 40, FTSE 100, CAC 40, IBEX 35, SMI, Nikkei 225, TOPIX, Hang Seng y S&P/ASX 200.
Prioriza hechos recientes (idealmente 48h), fuentes oficiales y noticias corroboradas.
No inventes información ni completes huecos con conocimiento externo.
Si una noticia es importante pero solo procede de una fuente secundaria, conserva el titular pero marca reliability como "Media" y corroborated como false.
Si procede de un regulador/organismo oficial, reliability puede ser "Alta".
Devuelve SOLO JSON con esta estructura:
{{"items":[{{"title":"...","source":"...","date":"...","url":"...","why":"por qué importa, <=180 caracteres","reliability":"Alta|Media-alta|Media","corroborated":true,"affected_markets":["..."]}}],"method":"..."}}
No cambies las URLs proporcionadas. No inventes fechas. No incluyas markdown.

DATOS RECOPILADOS:
{payload}"""

def _refresh_news(reason="scheduled"):
    global _last_refresh_started
    if not GEMINI_API_KEY or client is None: return False, "GEMINI_API_KEY no configurada"
    now = time.time()
    with _lock:
        cache_age = _cache_age(); has_valid_cache = cache_age != float("inf") and _read_cache() is not None
        if has_valid_cache and now - _last_refresh_started < 540: return False, "refresh en cooldown"
        u = _load_usage()
        if u.get("refreshes", 0) >= MAX_REFRESHES_PER_DAY: return False, "límite diario de actualizaciones alcanzado"
        if u.get("gemini_calls", 0) >= MAX_GEMINI_CALLS_PER_DAY: return False, "límite diario de llamadas Gemini alcanzado"
        _last_refresh_started = now
    collected, errors, statuses = _collect_news()
    if not collected:
        detail = "; ".join(errors[:5]) if errors else "ninguna fuente devolvió elementos"
        return False, "No se pudieron recopilar noticias utilizables: " + detail
    try:
        response = client.models.generate_content(
            model=GEMINI_MODEL,
            contents=_news_prompt(collected),
            config=types.GenerateContentConfig(system_instruction=SYSTEM + "\nDevuelve únicamente JSON válido, sin markdown.", temperature=0.2, response_mime_type="application/json"),
        )
        text = (response.text or "").strip(); start, end = text.find("{"), text.rfind("}")
        if start < 0 or end <= start: raise ValueError("Gemini no devolvió JSON válido")
        data = json.loads(text[start:end + 1])
        if not isinstance(data, dict) or not isinstance(data.get("items"), list): raise ValueError("Formato de noticias no válido")
        # Only allow URLs that came from the collector.
        source_by_url = {i["url"]: i for i in collected}
        clean = []
        for item in data["items"]:
            if item.get("url") not in source_by_url: continue
            original = source_by_url[item["url"]]
            item["source"] = original["source"]
            item["url"] = original["url"]
            clean.append(item)
        data["items"] = clean[:8]
        data.update({"updated_at": _now().astimezone().strftime("%d/%m/%Y %H:%M"), "updated_at_epoch": time.time(), "provider": "Fuentes públicas + Gemini", "model": GEMINI_MODEL, "refresh_reason": reason, "collector_errors": errors[:8], "collector_status": statuses})
        with _lock:
            u = _load_usage(); u["gemini_calls"] = u.get("gemini_calls", 0) + 1; u["refreshes"] = u.get("refreshes", 0) + 1; _save_usage(u)
            data["usage"] = {"gemini_calls_today": u["gemini_calls"], "refreshes_today": u["refreshes"], "daily_refresh_limit": MAX_REFRESHES_PER_DAY, "daily_gemini_limit": MAX_GEMINI_CALLS_PER_DAY}
            tmp = NEWS_CACHE_FILE.with_suffix(".tmp"); tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8"); tmp.replace(NEWS_CACHE_FILE)
        return True, "actualizado"
    except Exception as exc:
        return False, str(exc)

def _background_loop():
    while True:
        try:
            if _cache_age() >= REFRESH_INTERVAL_SECONDS: _refresh_news("scheduled")
        except Exception: pass
        time.sleep(30)

@app.on_event("startup")
def startup():
    global _background_started
    if not _background_started:
        _background_started = True
        threading.Thread(target=_background_loop, daemon=True, name="investai-news-refresh").start()

@app.get("/health")
def health():
    u = _load_usage(); age = _cache_age()
    cached = _read_cache()
    statuses = cached.get("collector_status", []) if cached else _load_collector_status().get("statuses", [])
    ok_count = sum(1 for x in statuses if x.get("status") == "ok")
    failed_count = sum(1 for x in statuses if x.get("status") == "error")
    return {"status":"ok", "sources":len(ALL_PRIMARY_DOMAINS), "provider":"Fuentes públicas + Gemini", "model":GEMINI_MODEL, "configured":bool(GEMINI_API_KEY), "news_cache_age_seconds":None if age == float("inf") else int(age), "refresh_interval_seconds":REFRESH_INTERVAL_SECONDS, "gemini_calls_today":u.get("gemini_calls",0), "daily_gemini_limit":MAX_GEMINI_CALLS_PER_DAY, "refreshes_today":u.get("refreshes",0), "daily_refresh_limit":MAX_REFRESHES_PER_DAY, "google_search_grounding":False, "collector_sources_ok":ok_count, "collector_sources_failed":failed_count, "collector_source_status":statuses}

@app.get("/sources")
def sources():
    return {"primary_sources":PRIMARY_SOURCES, "count":len(ALL_PRIMARY_DOMAINS), "feeds":len(FEEDS), "collector":"Official RSS/Atom feeds + publisher discovery feeds", "policy":"Priorizar fuentes oficiales; usar Reuters/AP/CNBC/MarketWatch para contraste; cada fuente es independiente y una caída no detiene el resto; Gemini analiza solo material recopilado y conserva URLs."}

@app.get("/news")
def news():
    if not GEMINI_API_KEY or client is None: raise HTTPException(500, "GEMINI_API_KEY no configurada")
    cached = _read_cache(); age = _cache_age()
    if cached is None or age >= REFRESH_INTERVAL_SECONDS:
        ok, msg = _refresh_news("on_request")
        if ok: cached = _read_cache(); age = _cache_age()
        elif cached is None: raise HTTPException(502, f"No se pudieron obtener las noticias: {msg}")
    if cached is None: raise HTTPException(503, "Noticias todavía no disponibles")
    cached["cache_age_seconds"] = int(age) if age != float("inf") else None
    cached["cache_status"] = "fresh" if age < REFRESH_INTERVAL_SECONDS else "stale"
    return cached

@app.post("/news/refresh")
def manual_news_refresh():
    ok, msg = _refresh_news("manual")
    if not ok: return {"updated":False, "reason":msg, "health":health()}
    return {"updated":True, "news":_read_cache(), "health":health()}

@app.post("/chat")
def chat(body: Chat):
    if not GEMINI_API_KEY or client is None: raise HTTPException(500, "GEMINI_API_KEY no configurada")
    with _lock:
        u = _load_usage()
        if u.get("gemini_calls", 0) >= MAX_GEMINI_CALLS_PER_DAY:
            raise HTTPException(429, "Límite diario interno de Gemini alcanzado; Invest AI no hará más llamadas hoy.")
        u["gemini_calls"] = u.get("gemini_calls", 0) + 1; _save_usage(u)
    prompt = f"Contexto de cartera:\n{body.portfolio}\n\nContexto de Invest AI:\n{body.app_context}\n\nPregunta:\n{body.question}\n\nResponde usando solo el contexto proporcionado y conocimiento general; no afirmes haber consultado Internet en esta llamada."
    try:
        response = client.models.generate_content(model=GEMINI_MODEL, contents=prompt, config=types.GenerateContentConfig(system_instruction=SYSTEM, temperature=0.3))
        return {"answer":response.text or "Gemini no devolvió contenido.", "provider":"Gemini", "usage":{"gemini_calls_today":u["gemini_calls"], "daily_gemini_limit":MAX_GEMINI_CALLS_PER_DAY}}
    except Exception as exc:
        with _lock:
            u = _load_usage(); u["gemini_calls"] = max(0, u.get("gemini_calls", 1)-1); _save_usage(u)
        raise HTTPException(502, f"No se pudo consultar Gemini: {exc}")
