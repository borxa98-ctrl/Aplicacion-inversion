# Invest AI — backend del Analista IA

Backend FastAPI para el Analista IA de Invest AI.

## Fuentes incorporadas al motor de búsqueda

El motor prioriza fuentes primarias públicas y regulatorias:

- SEC / EDGAR
- CFTC
- ESMA
- EBA
- BIS
- CNMV
- BCE
- Banco de España
- Federal Reserve / FRED
- BEA
- BLS
- Eurostat / Comisión Europea
- FMI
- Banco Mundial
- OCDE
- EIA
- IEA
- ISM
- Investor Relations oficiales de las empresas cuando corresponda

La búsqueda oficial está restringida a los dominios primarios anteriores mediante `allowed_domains`; además existe una búsqueda web general para contexto y contraste. La documentación de Gemini confirma que el tool `web_search` de Responses API admite `filters.allowed_domains` y `search_context_size`.

## Configuración

Define la variable de entorno:

```bash
GEMINI_API_KEY=...
```

No introduzcas la clave dentro del APK.

## Endpoints

- `GET /health`
- `GET /sources`
- `POST /chat`

## Nota

Las fuentes son gratuitas/públicas siempre que el propio organismo las publique así. La búsqueda web no convierte automáticamente datos licenciados de Reuters/Bloomberg/FT en datos gratuitos; esas fuentes pueden aparecer como contexto si están accesibles, pero no son el núcleo primario del motor.
