# Analista IA de Invest AI

Este servidor conecta la app Android con OpenAI sin exponer la API key dentro del APK. La app envía la pregunta y el contexto disponible; el servidor conserva la clave.

## Configuración

1. Define `OPENAI_API_KEY` como variable de entorno en el servidor.
2. Instala dependencias: `pip install -r requirements.txt`.
3. Ejecuta: `uvicorn server:app --host 0.0.0.0 --port 8000`.
4. En Invest AI → Más → Analista IA, introduce `http://IP_DEL_SERVIDOR:8000`.

La API usa la Responses API y un modelo de razonamiento de OpenAI. La clave no debe introducirse en el APK ni en el código Android.
