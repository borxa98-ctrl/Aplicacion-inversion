# Invest AI — Android

Aplicación Android nativa para el proyecto Invest AI.

## Qué incluye
- Inicio con oportunidad global.
- Mercados con los 15 índices definidos.
- Top global.
- Mi cartera manual para posiciones de MyInvestor.
- Señales MANTENER / VIGILAR / PREPARAR SALIDA / SALIDA.
- Consulta de precios públicos mediante Yahoo Finance.
- Titulares recientes mediante el backend IA y búsqueda web pública, con enlaces a la fuente.
- Conexión opcional al backend Invest AI para noticias, fuentes y análisis IA.
- Diseño pensado para smartphone.

## Abrir
Android Studio > Open > selecciona esta carpeta.

Después:
Build > Build APK(s)

El APK aparecerá normalmente en:
app/build/outputs/apk/debug/app-debug.apk

## Backend
En Ajustes de la app puedes indicar la URL de un backend Invest AI si quieres usar el motor completo que ya tenemos.
Ejemplo en una red local:
http://192.168.1.50:8000

Si no se configura backend, la aplicación usa el modo móvil público integrado para precios/noticias y una puntuación técnica local.

## Nota
Esta primera compilación Android está preparada para instalarse y probarse directamente. La conexión al motor completo permite ampliar después el universo de componentes, fundamentales, histórico y backtesting sin cambiar la interfaz.


## Compilación sin PC
Este paquete incluye `.github/workflows/build-apk.yml`. Puedes subir el proyecto
a un repositorio PRIVADO de GitHub desde el propio teléfono y ejecutar el workflow
"Build Invest AI APK". GitHub compila el APK en la nube y lo deja disponible como
Artifact para descargar desde el teléfono.

También incluye `build_apk.sh` para una compilación local en Android/Termux si se
dispone del SDK Android y Java.

## UX 2.1 — mercados interactivos
Cada índice de la pantalla **Mercados** es ahora pulsable. Al tocarlo se abre una pantalla con las **10 empresas recomendadas** para ese índice, con posición, puntuación 0–100 y explicación visual. En esta versión los nombres y puntuaciones son de demostración; el motor real los sustituirá cuando se conecten los datos públicos.


## v2.3 — Analista IA
Incluye un chatbot financiero conectado a un backend seguro. La app no contiene la API key. Configura el servidor en Más → Analista IA. El backend usa la Responses API y búsqueda web para preguntas que necesiten contexto actual.

## v2.7 — Actualidad en la pantalla de inicio

La sección **Estado** ya no muestra un mensaje fijo de “datos no conectados”. La pantalla de inicio incorpora **Actualidad del mercado**, donde el backend puede devolver hasta 6 titulares recientes analizados por Invest AI, con fuente, fecha, motivo de relevancia y enlace a la noticia. Si no hay backend configurado, la app lo indica sin inventar datos.

Endpoint: `GET /news`.

## v2.8 — Rediseño visual
La interfaz se ha actualizado con una estética de app bancaria/broker moderna: fondo oscuro azul marino, tarjetas limpias, jerarquía tipográfica, tarjeta de patrimonio, navegación inferior y secciones de mercados, actualidad y Analista IA.


## Motor IA y noticias (v5.7.5)
El backend usa Gemini REST para analizar titulares recopilados de feeds públicos RSS/Atom. Google Search Grounding está desactivado: el análisis se limita al material recogido y conserva las URLs originales. Configura `GEMINI_API_KEY` en Render para análisis IA; si falta la clave o se agota la cuota, `/news` conserva los titulares mediante un fallback local claramente identificado, sin presentarlo como análisis IA completo.

## Motor de noticias v4.2
Recopilador público tolerante a fallos: RSS/Atom oficiales + feeds de contraste restringidos por dominio. Gemini analiza solo el material recopilado; Google Search Grounding permanece desactivado.

## v5.7.2 — atribución de noticias reforzada
- Añade `affected_sectors` para transmitir noticias sectoriales a empresas del universo sin fingir impacto directo.
- Mantiene `affected_companies` solo para relaciones directas o inequívocas.
- El score de noticias usa relación directa 1.00, sector 0.65 e índice 0.40.
- Zumitow se mantiene como fuente secundaria especializada con peso conservador.

## v5.7.5 — robustez del pipeline de noticias
- El esquema JSON de Gemini incluye ahora los campos de atribución de empresas y sectores que solicita el prompt.
- Selección de hasta 12 noticias en rondas por fuente para reducir el sesgo de las fuentes con feeds más largos.
- Exige una respuesta por URL de entrada; si faltan noticias, completa las omitidas con fallback y marca el análisis como `partial`.
- Añade `analysis_method` y `ai_diagnostics` con número de noticias analizadas por IA, completadas por fallback y URLs inválidas.
- Evita falsos positivos de tickers de una letra (por ejemplo, `V` dentro de palabras en inglés).
- El fallback recupera índices macroeconómicos reconocibles y nunca presenta sus puntuaciones como análisis IA completo.
- Una noticia solo cuenta una vez por empresa: prevalece el vínculo directo sobre sector e índice.
- La cobertura de noticias baja cuando solo hay análisis determinista y su peso en el score se reduce.
- Los límites y timeouts de configuración numérica se validan para que variables de entorno mal formadas no impidan iniciar el backend.
- Si Gemini no está configurado o se alcanza su límite diario, `/news` sigue devolviendo titulares con estado de fallback, en lugar de fallar completamente.
