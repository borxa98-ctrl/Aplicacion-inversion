# Invest AI — backend de noticias y análisis

Backend FastAPI para Invest AI. Las noticias se recopilan de feeds RSS/Atom públicos y se analizan con Gemini REST sin Google Search Grounding. Se conservan el título, fuente, fecha y URL originales del recopilador; Gemini aporta únicamente la explicación, el sentimiento, la importancia y las atribuciones validadas.

## Fuentes del recopilador

La configuración incluye SEC, Federal Reserve, BLS, BLS CPI, BEA, ECB, Reuters, AP, CNBC, MarketWatch, Zumitow, CNMV, ECB/Euro area y Comisión Europea. La disponibilidad de cada feed cambia; consulta `GET /health` para ver estados y errores actuales. Un HTTP 403 en una fuente no debe bloquear las demás. Zumitow se trata como fuente secundaria especializada y no como fuente primaria.

## Configuración

Define `GEMINI_API_KEY` como variable de entorno en Render. No incluyas la clave en el APK ni en GitHub. Sin clave o al agotar la cuota diaria, `/news` puede seguir mostrando titulares con `ai_status: fallback_colector`; ese resultado no equivale a un análisis IA completo.

## Endpoints

- `GET /health` — estado del servicio, fuentes y límites de uso.
- `GET /sources` — política y configuración general de fuentes.
- `GET /news` — noticias analizadas o fallback identificado.
- `POST /news/refresh` — solicita actualización.
- `GET /gemini-test` — prueba básica de conexión con Gemini.
- `POST /chat` — chat financiero.

## Interpretación de estado de noticias

- `ai_status: ok`: todas las noticias seleccionadas tienen análisis IA validado.
- `ai_status: partial`: Gemini respondió, pero algunas noticias se completaron con reglas locales.
- `ai_status: fallback_colector`: no se pudo usar el análisis IA; se publican titulares con análisis local limitado.

Consulta `ai_diagnostics` para distinguir el número de noticias de entrada, analizadas por IA, completadas por fallback y URLs descartadas. Las puntuaciones de fallback tienen menor peso y no deben interpretarse como recomendaciones de inversión por sí solas.


## Calidad y resiliencia del feed (v5.7.9)

- Las atribuciones de sectores e índices se contrastan con evidencia textual antes de guardarse y entrar en las puntuaciones.
- La corroboración requiere otra noticia similar de una familia editorial independiente y con fecha compatible.
- Se eliminan duplicados casi idénticos de la misma familia editorial antes del análisis IA.
- Si los RSS de BLS o BLS CPI devuelven error, se intenta un RSS de descubrimiento limitado al dominio oficial `bls.gov`; el campo `collector_status[].fallback_used` permite identificarlo.
- `ai_diagnostics` expone `near_duplicate_items_removed`, `source_fallbacks_used`, `unsupported_sector_tags_removed`, `unsupported_market_tags_removed` y `unsupported_corroboration_claims_removed`.
