import json
import os
import re
import threading
import time
from datetime import datetime, timezone, timedelta
from html import unescape
from pathlib import Path
from urllib.parse import quote, urlparse
from urllib.request import Request, urlopen

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import feedparser

app = FastAPI(title="Invest AI Financial Analyst", version="4.10")
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "").strip().strip('"').strip("'")
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-3.5-flash-lite")
GEMINI_FALLBACK_MODEL = os.environ.get("GEMINI_FALLBACK_MODEL", "gemini-3.8-flash")

# Compatibilidad con despliegues anteriores: si Render conserva las variables
# antiguas apuntando ambas a Gemini 3.8, corregimos automáticamente la pareja
# para que el nivel gratuito use Flash-Lite como primario.
if GEMINI_MODEL == "gemini-3.8-flash" and GEMINI_FALLBACK_MODEL == "gemini-3.8-flash":
    GEMINI_MODEL = "gemini-3.5-flash-lite"
    GEMINI_FALLBACK_MODEL = "gemini-3.8-flash"
GEMINI_PRIMARY_RETRIES = int(os.environ.get("GEMINI_PRIMARY_RETRIES", "3"))
GEMINI_FALLBACK_RETRIES = int(os.environ.get("GEMINI_FALLBACK_RETRIES", "2"))
GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
INDEXES = {
    "S&P 500", "Nasdaq-100", "Dow Jones", "Russell 2000", "EURO STOXX 50",
    "STOXX Europe 600", "DAX 40", "FTSE 100", "CAC 40", "IBEX 35", "SMI",
    "Nikkei 225", "TOPIX", "Hang Seng", "S&P/ASX 200"
}

# v4.0: news discovery is performed directly against public RSS/Atom feeds.
# Gemini receives the collected headlines/snippets and performs analysis WITHOUT
# Google Search grounding. This avoids paid Search grounding while preserving
# traceable source URLs and a source-quality policy.
CACHE_DIR = Path(os.environ.get("INVESTAI_CACHE_DIR", "/tmp/investai_cache"))
CACHE_DIR.mkdir(parents=True, exist_ok=True)
NEWS_CACHE_FILE = CACHE_DIR / "news.json"
USAGE_FILE = CACHE_DIR / "usage.json"
COLLECTOR_STATUS_FILE = CACHE_DIR / "collector_status.json"
REFRESH_INTERVAL_SECONDS = int(os.environ.get("NEWS_REFRESH_INTERVAL_SECONDS", "600"))
MAX_REFRESHES_PER_DAY = int(os.environ.get("MAX_REFRESHES_PER_DAY", "96"))
MAX_GEMINI_CALLS_PER_DAY = int(os.environ.get("MAX_GEMINI_CALLS_PER_DAY", "96"))
FETCH_TIMEOUT_SECONDS = int(os.environ.get("NEWS_FETCH_TIMEOUT_SECONDS", "12"))
MAX_ITEMS_PER_FEED = int(os.environ.get("MAX_ITEMS_PER_FEED", "12"))
MAX_ITEMS_FOR_GEMINI = int(os.environ.get("MAX_ITEMS_FOR_GEMINI", "60"))
GEMINI_HTTP_TIMEOUT_SECONDS = int(os.environ.get("GEMINI_HTTP_TIMEOUT_SECONDS", "90"))
_lock = threading.Lock()
_last_refresh_started = 0.0
_background_started = False

PRIMARY_SOURCES = {
    "reguladores_y_oficiales": [
        "sec.gov", "cnmv.es", "esma.europa.eu", "eba.europa.eu", "ecb.europa.eu",
        "bde.es", "federalreserve.gov", "fred.stlouisfed.org", "bea.gov", "bls.gov",
        "eurostat.ec.europa.eu", "ec.europa.eu", "imf.org", "worldbank.org", "oecd.org",
        "eia.gov", "iea.org", "ismworld.org"
    ],
    "medios_financieros_de_contraste": ["reuters.com", "apnews.com", "cnbc.com", "marketwatch.com"],
}
ALL_PRIMARY_DOMAINS = sorted({d for group in PRIMARY_SOURCES.values() for d in group})

# Public feeds. Google News RSS is used only as a free discovery/transport layer;
# Gemini does not use Google Search grounding. Queries are restricted to named
# publishers or official domains so the backend can keep source provenance.
FEEDS = [
    # Official feeds. A failure is isolated and never blocks the collector.
    # SEC publishes EDGAR/press RSS and explicitly documents RSS as an access path.
    ("SEC", "https://www.sec.gov/news/pressreleases.rss", "official"),
        ("Federal Reserve", "https://www.federalreserve.gov/feeds/press_all.xml", "official"),
    ("BLS", "https://www.bls.gov/feed/bls_latest.rss", "official"),
    ("BLS CPI", "https://www.bls.gov/feed/cpi_latest.rss", "official"),
    ("BEA", "https://apps.bea.gov/rss/rss.xml", "official"),
    ("ECB", "https://www.ecb.europa.eu/rss/press.html", "official"),
    # Reputable publisher discovery feeds. The article URL is preserved and the
    # publisher is retained as the provenance; Gemini cannot create new URLs.
    ("Reuters", "https://news.google.com/rss/search?q=" + quote("site:reuters.com (markets OR stocks OR earnings OR economy)"), "reputable_secondary"),
    ("AP", "https://news.google.com/rss/search?q=" + quote("site:apnews.com (markets OR stocks OR economy)"), "reputable_secondary"),
    ("CNBC", "https://news.google.com/rss/search?q=" + quote("site:cnbc.com (markets OR stocks OR earnings OR economy)"), "reputable_secondary"),
    ("MarketWatch", "https://news.google.com/rss/search?q=" + quote("site:marketwatch.com (stocks OR markets OR earnings)"), "reputable_secondary"),
    ("CNMV", "https://news.google.com/rss/search?q=" + quote("site:cnmv.es (mercados OR cotizadas OR hechos relevantes)"), "official_discovery"),
    ("ECB/Euro area", "https://news.google.com/rss/search?q=" + quote("site:ecb.europa.eu euro area monetary policy"), "official_discovery"),
    ("EU Commission", "https://news.google.com/rss/search?q=" + quote("site:ec.europa.eu economy finance markets"), "official_discovery"),
]

SYSTEM = f"""Eres el Analista IA de Invest AI, especializado en mercados de capitales.
Responde en español, con rigor y sin inventar información.
La información que recibes procede de un recopilador de fuentes públicas. NO tienes Google Search en esta llamada y NO debes fingir que has verificado nada fuera del material proporcionado.
Prioridad de evidencia: fuentes regulatorias/oficiales > comunicados corporativos > Reuters/AP/CNBC/MarketWatch > otros.
No conviertas un rumor en un hecho. Si una noticia importante solo tiene una fuente secundaria, indícalo como no corroborada.
Cuando dos fuentes independientes describan el mismo hecho, puedes indicar que está corroborado, pero no inventes corroboración.
Conserva siempre la URL de la fuente proporcionada.
La puntuación 0–100 es una puntuación de oportunidad del modelo, NO una probabilidad de beneficio ni una recomendación automática.
Fuentes oficiales configuradas: {', '.join(ALL_PRIMARY_DOMAINS)}"""

class Chat(BaseModel):
    question: str
    portfolio: str = ""
    app_context: str = ""


def _now(): return datetime.now(timezone.utc)
def _day(): return _now().strftime("%Y-%m-%d")

def _load_usage():
    default = {"day": _day(), "refreshes": 0, "gemini_calls": 0}
    try:
        d = json.loads(USAGE_FILE.read_text(encoding="utf-8"))
        if d.get("day") != _day(): d = default
        return d
    except Exception:
        return default

def _save_usage(d):
    tmp = USAGE_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(d), encoding="utf-8")
    tmp.replace(USAGE_FILE)

def _cache_age():
    try:
        d = json.loads(NEWS_CACHE_FILE.read_text(encoding="utf-8"))
        return max(0, time.time() - float(d["updated_at_epoch"]))
    except Exception:
        return float("inf")

def _read_cache():
    try:
        d = json.loads(NEWS_CACHE_FILE.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) and isinstance(d.get("items"), list) and d.get("updated_at_epoch") else None
    except Exception:
        return None

def _strip_html(value):
    value = unescape(value or "")
    value = re.sub(r"<[^>]+>", " ", value)
    return re.sub(r"\s+", " ", value).strip()

def _domain(url):
    try: return urlparse(url).netloc.lower().removeprefix("www.")
    except Exception: return ""

def _save_collector_status(statuses):
    try:
        payload = {"updated_at_epoch": time.time(), "statuses": statuses}
        tmp = COLLECTOR_STATUS_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        tmp.replace(COLLECTOR_STATUS_FILE)
    except Exception:
        pass


def _load_collector_status():
    try:
        d = json.loads(COLLECTOR_STATUS_FILE.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) and isinstance(d.get("statuses"), list) else {"updated_at_epoch": 0, "statuses": []}
    except Exception:
        return {"updated_at_epoch": 0, "statuses": []}


def _fetch_feed(name, url, tier):
    """Fetch RSS/Atom/RDF without allowing one malformed feed to break collection.

    feedparser is intentionally used here instead of ElementTree because several
    public feeds are imperfect XML (or RDF) and may contain recoverable entries.
    """
    headers = {
        "User-Agent": "InvestAI/4.3 (news reader; public-source collector)",
        "Accept": "application/rss+xml, application/atom+xml, application/rdf+xml, application/xml, text/xml;q=0.9, */*;q=0.1",
        "Accept-Language": "en-US,en;q=0.8,es;q=0.7",
        "Cache-Control": "no-cache",
    }
    last_error = None
    for attempt in range(2):
        try:
            req = Request(url, headers=headers)
            with urlopen(req, timeout=FETCH_TIMEOUT_SECONDS) as r:
                raw = r.read(800_000)
            parsed = feedparser.parse(raw)
            entries = getattr(parsed, "entries", []) or []
            items = []
            for entry in entries[:MAX_ITEMS_PER_FEED]:
                title = _strip_html(entry.get("title", ""))
                link = entry.get("link", "") or ""
                if not link and entry.get("links"):
                    for candidate in entry.get("links", []):
                        if candidate.get("href"):
                            link = candidate["href"]
                            break
                desc = _strip_html(entry.get("summary", entry.get("description", "")))
                date = entry.get("published", "") or entry.get("updated", "") or entry.get("created", "") or ""
                if title and link:
                    items.append({
                        "title": title,
                        "snippet": desc[:500],
                        "source": name,
                        "source_tier": tier,
                        "date": date,
                        "url": link,
                        "domain": _domain(link),
                    })

            # HTTP success + no entries is a warning, not a successful source.
            if not items:
                bozo = getattr(parsed, "bozo", False)
                bozo_exc = getattr(parsed, "bozo_exception", None)
                reason = "feed sin elementos"
                if bozo and bozo_exc:
                    reason += f"; parser: {bozo_exc}"
                return [], {"status": "warning", "items": 0, "reason": reason}

            # A malformed feed can still be useful if feedparser recovered entries.
            if getattr(parsed, "bozo", False):
                bozo_exc = getattr(parsed, "bozo_exception", None)
                return items, {"status": "warning", "items": len(items), "reason": f"feed recuperado con advertencia: {bozo_exc}"}

            return items, {"status": "ok", "items": len(items)}
        except Exception as exc:
            last_error = exc
            if attempt == 0:
                time.sleep(0.4)
    return [], {"status": "error", "items": 0, "error": f"{name}: {last_error}"}


def _collect_news():
    all_items, errors, statuses = [], [], []
    for name, url, tier in FEEDS:
        items, result = _fetch_feed(name, url, tier)
        all_items.extend(items)
        status = {"source": name, **result}
        statuses.append(status)
        if result.get("status") == "error":
            errors.append(result.get("error", f"{name}: error desconocido"))
    _save_collector_status(statuses)
    seen, unique = set(), []
    for item in all_items:
        key = item["url"].split("#")[0] or (item["source"], item["title"].lower())
        if key in seen:
            continue
        seen.add(key)
        unique.append(item)
    return unique, errors, statuses

def _news_prompt(items):
    # Limitamos el contexto enviado al modelo para reducir latencia y consumo.
    compact = []
    for item in items[:MAX_ITEMS_FOR_GEMINI]:
        compact.append({
            "title": item.get("title", ""),
            "snippet": (item.get("snippet", "") or "")[:320],
            "source": item.get("source", ""),
            "date": item.get("date", ""),
            "url": item.get("url", ""),
        })
    payload = json.dumps(compact, ensure_ascii=False)
    return f"""Analiza este conjunto de titulares/noticias recopilados de fuentes públicas.
Selecciona como máximo 8 noticias realmente relevantes para los índices S&P 500, Nasdaq-100, Dow Jones, Russell 2000, EURO STOXX 50, STOXX Europe 600, DAX 40, FTSE 100, CAC 40, IBEX 35, SMI, Nikkei 225, TOPIX, Hang Seng y S&P/ASX 200.
Prioriza hechos recientes (idealmente 48h), fuentes oficiales y noticias corroboradas.
No inventes información ni completes huecos con conocimiento externo.
Si una noticia es importante pero solo procede de una fuente secundaria, conserva el titular pero marca reliability como "Media" y corroborated como false.
Si procede de un regulador/organismo oficial, reliability puede ser "Alta".
Devuelve SOLO JSON con esta estructura:
{{"items":[{{"title":"...","source":"...","date":"...","url":"...","why":"por qué importa, <=180 caracteres","reliability":"Alta|Media-alta|Media","corroborated":true,"affected_markets":["..."]}}],"method":"..."}}
No cambies las URLs proporcionadas. No inventes fechas. No incluyas markdown.

DATOS RECOPILADOS:
{payload}"""


def _extract_json_object(text):
    """Extrae JSON cuando Gemini lo entrega bien y recupera noticias si no."""
    if not isinstance(text, str) or not text.strip():
        raise ValueError("Gemini no devolvió contenido")
    cleaned = text.strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.I)
    cleaned = re.sub(r"\s*```$", "", cleaned)

    decoder = json.JSONDecoder()
    first = cleaned.find("{")
    if first >= 0:
        try:
            value, _ = decoder.raw_decode(cleaned[first:])
            if isinstance(value, dict):
                return value
        except json.JSONDecodeError:
            pass

    # Buscar objetos JSON completos dentro de una respuesta rota.
    objects = []
    depth = 0
    in_string = False
    escaped = False
    obj_start = None
    for i, ch in enumerate(cleaned[first if first >= 0 else 0:], start=first if first >= 0 else 0):
        if in_string:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == '"':
                in_string = False
            continue
        if ch == '"':
            in_string = True
        elif ch == '{':
            if depth == 0:
                obj_start = i
            depth += 1
        elif ch == '}':
            if depth:
                depth -= 1
                if depth == 0 and obj_start is not None:
                    try:
                        obj = json.loads(cleaned[obj_start:i+1])
                        if isinstance(obj, dict):
                            objects.append(obj)
                    except json.JSONDecodeError:
                        pass
                    obj_start = None

    recovered = []
    method = ""
    for obj in objects:
        if isinstance(obj.get("items"), list):
            recovered.extend(x for x in obj["items"] if isinstance(x, dict))
        elif obj.get("title") and obj.get("url"):
            recovered.append(obj)
        if obj.get("method") and not method:
            method = str(obj["method"])
    if recovered:
        return {"items": recovered[:8], "method": method or "Recuperación JSON parcial"}

    # Último intento: localizar URLs y títulos de la respuesta. Se validarán
    # posteriormente contra las URLs que realmente entregó el recopilador.
    urls = re.findall(r'https?://[^\s<>"\\]+', cleaned)
    loose_items = []
    for url in urls:
        url = url.rstrip('.,);]')
        pos = cleaned.find(url)
        before = cleaned[max(0, pos-350):pos]
        lines = [re.sub(r'^\s*[-*\d.)]+\s*', '', x).strip() for x in before.splitlines() if x.strip()]
        title = lines[-1] if lines else ""
        title = re.sub(r'^["\']|["\']$', '', title)
        if title and len(title) > 12:
            loose_items.append({"title": title[:300], "url": url, "source": "", "date": "", "why": "Titular relevante detectado por el motor de análisis.", "reliability": "Media", "corroborated": False, "affected_markets": []})
    if loose_items:
        return {"items": loose_items[:8], "method": "Recuperación de URLs y titulares"}
    raise ValueError("Gemini devolvió una respuesta que no pudo convertirse a noticias")

class GeminiRESTError(RuntimeError):
    def __init__(self, message, status_code=None):
        super().__init__(message)
        self.status_code = status_code


def _gemini_generate_once(model, prompt, system_instruction=None, temperature=0.2, response_mime_type=None):
    if not GEMINI_API_KEY:
        raise GeminiRESTError("GEMINI_API_KEY no configurada")
    body = {
        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
        "generationConfig": {
            "maxOutputTokens": 1200,
        },
    }
    if system_instruction:
        body["systemInstruction"] = {"parts": [{"text": system_instruction}]}
    if response_mime_type:
        # Este backend usa models:generateContent. Google documenta Structured
        # Output aquí mediante generationConfig.responseMimeType + responseSchema.
        if response_mime_type == "application/json":
            schema = {
                "type": "OBJECT",
                "properties": {
                    "items": {
                        "type": "ARRAY",
                        "maxItems": 8,
                        "items": {
                            "type": "OBJECT",
                            "properties": {
                                "title": {"type": "STRING"},
                                "source": {"type": "STRING"},
                                "date": {"type": "STRING"},
                                "url": {"type": "STRING"},
                                "why": {"type": "STRING"},
                                "reliability": {"type": "STRING"},
                                "corroborated": {"type": "BOOLEAN"},
                                "affected_markets": {"type": "ARRAY", "items": {"type": "STRING"}}
                            },
                            "required": ["title", "source", "date", "url", "why", "reliability", "corroborated", "affected_markets"],
                        }
                    },
                    "method": {"type": "STRING"}
                },
                "required": ["items", "method"],
            }
            body["generationConfig"]["responseMimeType"] = "application/json"
            body["generationConfig"]["responseSchema"] = schema
        else:
            body["generationConfig"]["responseMimeType"] = response_mime_type
    # Gemini 3.x permite reducir el nivel de razonamiento para minimizar latencia.
    # Usamos minimal en el principal y low en el fallback; no desactivamos
    # completamente el razonamiento.
    body["generationConfig"]["thinkingConfig"] = {
        "thinkingLevel": "minimal" if model == "gemini-3.5-flash-lite" else "low"
    }
    data = json.dumps(body, ensure_ascii=False).encode("utf-8")
    req = Request(
        GEMINI_API_URL.format(model=quote(model, safe="")),
        data=data,
        headers={
            "Content-Type": "application/json",
            "x-goog-api-key": GEMINI_API_KEY,
            "User-Agent": "InvestAI/4.8.6",
        },
        method="POST",
    )
    try:
        with urlopen(req, timeout=GEMINI_HTTP_TIMEOUT_SECONDS) as r:
            raw = r.read(2_000_000)
        payload = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        status = getattr(exc, "code", None)
        detail = getattr(exc, "read", lambda: b"")()
        if detail:
            try:
                detail_text = detail.decode("utf-8", errors="replace")
            except Exception:
                detail_text = str(detail)
            raise GeminiRESTError(f"Gemini REST ({status or 'HTTP'}): {detail_text[:2500]}", status) from exc
        raise GeminiRESTError(f"Gemini REST ({status or 'HTTP'}): {exc}", status) from exc

    parts = []
    for candidate in payload.get("candidates", []) or []:
        content = candidate.get("content") or {}
        for part in content.get("parts", []) or []:
            if isinstance(part, dict) and part.get("text"):
                parts.append(part["text"])
    text = "\n".join(parts).strip()
    if not text:
        raise GeminiRESTError(f"Gemini REST ({model}): respuesta sin texto")
    return text


def _gemini_generate(prompt, system_instruction=None, temperature=0.2, response_mime_type=None):
    """Gemini REST con reintentos conservadores y fallback automático.

    - Primario: GEMINI_MODEL (por defecto gemini-3.5-flash-lite).
    - Fallback: GEMINI_FALLBACK_MODEL (por defecto gemini-3.8-flash).
    - 503/408/504/timeout: backoff conservador y después fallback.
    - 429 de cuota/rate limit: no se insiste innecesariamente en el mismo modelo; se pasa directamente al fallback.
    - 401/402/403: se propagan sin ocultarlos.
    """
    models = [(GEMINI_MODEL, max(1, GEMINI_PRIMARY_RETRIES))]
    if GEMINI_FALLBACK_MODEL and GEMINI_FALLBACK_MODEL != GEMINI_MODEL:
        models.append((GEMINI_FALLBACK_MODEL, max(1, GEMINI_FALLBACK_RETRIES)))

    last_exc = None
    for model_index, (model, attempts) in enumerate(models):
        for attempt in range(attempts):
            try:
                text = _gemini_generate_once(model, prompt, system_instruction, temperature, response_mime_type)
                return text, model
            except GeminiRESTError as exc:
                last_exc = exc
                # 503 = capacidad temporalmente no disponible: reintentamos
                # con backoff antes de pasar al siguiente modelo.
                if exc.status_code in (503, 408, 504) or exc.status_code is None:
                    if attempt < attempts - 1:
                        delay = 2 * (2 ** attempt) + (0.5 * attempt)
                        time.sleep(delay)
                    continue

                # 429 = cuota/rate limit. Reintentar el mismo modelo puede
                # consumir tiempo sin cambiar el estado de la cuota, así que
                # pasamos directamente al fallback si existe.
                if exc.status_code == 429:
                    break

                # 401/402/403 u otros errores de configuración no deben
                # ocultarse haciendo llamadas adicionales a otro modelo.
                raise
        if model_index == 0 and len(models) > 1:
            continue
    raise last_exc or GeminiRESTError("Gemini REST: error desconocido")

def _refresh_news(reason="scheduled"):
    global _last_refresh_started
    if not GEMINI_API_KEY: return False, "GEMINI_API_KEY no configurada"
    now = time.time()
    with _lock:
        cache_age = _cache_age(); has_valid_cache = cache_age != float("inf") and _read_cache() is not None
        if has_valid_cache and now - _last_refresh_started < 540: return False, "refresh en cooldown"
        u = _load_usage()
        if u.get("refreshes", 0) >= MAX_REFRESHES_PER_DAY: return False, "límite diario de actualizaciones alcanzado"
        if u.get("gemini_calls", 0) >= MAX_GEMINI_CALLS_PER_DAY: return False, "límite diario de llamadas Gemini alcanzado"
        _last_refresh_started = now
    collected, errors, statuses = _collect_news()
    if not collected:
        detail = "; ".join(errors[:5]) if errors else "ninguna fuente devolvió elementos"
        return False, "No se pudieron recopilar noticias utilizables: " + detail
    ai_error = None
    used_model = None
    ai_status = "ok"
    try:
        text, used_model = _gemini_generate(
            _news_prompt(collected),
            system_instruction=SYSTEM + "\nDevuelve únicamente JSON válido, sin markdown.",
            temperature=0.2,
            response_mime_type="application/json",
        )
        data = _extract_json_object(text)
        if not isinstance(data, dict) or not isinstance(data.get("items"), list):
            raise ValueError("Formato de noticias no válido")
    except Exception as exc:
        # Garantía de servicio: las noticias no dependen de que Gemini produzca
        # JSON perfecto. Si Gemini falla, publicamos directamente los titulares
        # verificados por el recopilador y dejamos constancia del estado de IA.
        ai_error = str(exc)
        ai_status = "fallback_colector"
        used_model = None
        data = {
            "items": [
                {
                    "title": item.get("title", ""),
                    "source": item.get("source", ""),
                    "date": item.get("date", ""),
                    "url": item.get("url", ""),
                    "why": "Titular recopilado de una fuente pública; análisis IA no disponible en esta actualización.",
                    "reliability": "Alta" if item.get("source_tier") in ("official", "official_discovery") else "Media",
                    "corroborated": False,
                    "affected_markets": [],
                }
                for item in collected[:8]
            ],
            "method": "Fuentes públicas (fallback sin IA)"
        }

    # Solo permitimos URLs que realmente procedan del recopilador.
    source_by_url = {i["url"]: i for i in collected}
    clean = []
    for item in data.get("items", []):
        if not isinstance(item, dict) or item.get("url") not in source_by_url:
            continue
        original = source_by_url[item["url"]]
        # La URL es la identidad de la noticia. El título, fuente y fecha se
        # toman SIEMPRE del recopilador para impedir que una respuesta JSON
        # parcialmente rota de Gemini contamine la noticia con fragmentos de
        # JSON, texto truncado o datos inventados. Gemini solo puede aportar
        # el contexto analítico.
        safe = {
            "title": original.get("title", ""),
            "source": original.get("source", ""),
            "date": original.get("date", ""),
            "url": original.get("url", ""),
            "why": "Titular recopilado de una fuente pública.",
            "reliability": "Alta" if original.get("source_tier") in ("official", "official_discovery") else "Media",
            "corroborated": False,
            "affected_markets": [],
        }
        why = item.get("why")
        if isinstance(why, str) and 20 <= len(why.strip()) <= 300 and '"items"' not in why and not why.lstrip().startswith("{"):
            safe["why"] = why.strip()
        reliability = item.get("reliability")
        if reliability in ("Alta", "Media-alta", "Media"):
            safe["reliability"] = reliability
        safe["corroborated"] = bool(item.get("corroborated", False))
        markets = item.get("affected_markets")
        if isinstance(markets, list):
            safe["affected_markets"] = [str(m) for m in markets if str(m) in INDEXES][:8]
        clean.append(safe)
    data["items"] = clean[:8]
    if not data["items"]:
        # Si Gemini devolvió JSON pero descartó todas las URLs, también se usa
        # el fallback del recopilador para que el endpoint nunca quede vacío.
        data["items"] = [
            {
                "title": i.get("title", ""), "source": i.get("source", ""),
                "date": i.get("date", ""), "url": i.get("url", ""),
                "why": "Titular recopilado de una fuente pública; análisis IA no disponible para esta noticia.",
                "reliability": "Alta" if i.get("source_tier") in ("official", "official_discovery") else "Media",
                "corroborated": False, "affected_markets": []
            } for i in collected[:8]
        ]
        ai_status = "fallback_colector"

    data.update({
        "updated_at": _now().astimezone().strftime("%d/%m/%Y %H:%M"),
        "updated_at_epoch": time.time(),
        "provider": "Fuentes públicas + Gemini",
        "model": used_model,
        "requested_model": GEMINI_MODEL,
        "fallback_model": GEMINI_FALLBACK_MODEL,
        "ai_status": ai_status,
        "ai_error": ai_error[:1000] if ai_error else None,
        "refresh_reason": reason,
        "collector_errors": errors[:8],
        "collector_status": statuses,
    })
    with _lock:
        u = _load_usage()
        if used_model:
            u["gemini_calls"] = u.get("gemini_calls", 0) + 1
        u["refreshes"] = u.get("refreshes", 0) + 1
        _save_usage(u)
        data["usage"] = {"gemini_calls_today": u["gemini_calls"], "refreshes_today": u["refreshes"], "daily_refresh_limit": MAX_REFRESHES_PER_DAY, "daily_gemini_limit": MAX_GEMINI_CALLS_PER_DAY}
        tmp = NEWS_CACHE_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        tmp.replace(NEWS_CACHE_FILE)
    return True, "actualizado"

def _background_loop():
    while True:
        try:
            if _cache_age() >= REFRESH_INTERVAL_SECONDS: _refresh_news("scheduled")
        except Exception: pass
        time.sleep(30)

@app.on_event("startup")
def startup():
    global _background_started
    if not _background_started:
        _background_started = True
        threading.Thread(target=_background_loop, daemon=True, name="investai-news-refresh").start()

@app.get("/health")
def health():
    u = _load_usage(); age = _cache_age()
    cached = _read_cache()
    statuses = cached.get("collector_status", []) if cached else _load_collector_status().get("statuses", [])
    ok_count = sum(1 for x in statuses if x.get("status") == "ok")
    failed_count = sum(1 for x in statuses if x.get("status") == "error")
    warning_count = sum(1 for x in statuses if x.get("status") == "warning")
    return {"status":"ok", "sources":len(ALL_PRIMARY_DOMAINS), "provider":"Fuentes públicas + Gemini", "model":GEMINI_MODEL, "fallback_model":GEMINI_FALLBACK_MODEL, "gemini_http_timeout_seconds":GEMINI_HTTP_TIMEOUT_SECONDS, "gemini_thinking_level":"minimal (primary) / low (fallback)", "configured":bool(GEMINI_API_KEY), "news_cache_age_seconds":None if age == float("inf") else int(age), "refresh_interval_seconds":REFRESH_INTERVAL_SECONDS, "gemini_calls_today":u.get("gemini_calls",0), "daily_gemini_limit":MAX_GEMINI_CALLS_PER_DAY, "refreshes_today":u.get("refreshes",0), "daily_refresh_limit":MAX_REFRESHES_PER_DAY, "google_search_grounding":False, "collector_sources_ok":ok_count, "collector_sources_warning":warning_count, "collector_sources_failed":failed_count, "collector_source_status":statuses}

@app.get("/sources")
def sources():
    return {"primary_sources":PRIMARY_SOURCES, "count":len(ALL_PRIMARY_DOMAINS), "feeds":len(FEEDS), "collector":"Official RSS/Atom feeds + publisher discovery feeds", "policy":"Priorizar fuentes oficiales; usar Reuters/AP/CNBC/MarketWatch para contraste; cada fuente es independiente y una caída no detiene el resto; Gemini analiza solo material recopilado y conserva URLs."}

@app.get("/gemini-test")
def gemini_test():
    """Minimal authentication/model diagnostic; does not consume the news cache."""
    if not GEMINI_API_KEY:
        raise HTTPException(500, "GEMINI_API_KEY no configurada")
    try:
        text, used_model = _gemini_generate("Responde únicamente: OK", temperature=0.0)
        return {"ok": True, "model": used_model, "requested_model": GEMINI_MODEL, "fallback_model": GEMINI_FALLBACK_MODEL, "provider": "Gemini REST", "response": text}
    except Exception as exc:
        raise HTTPException(502, f"Gemini test falló: {exc}")

@app.get("/news")
def news():
    if not GEMINI_API_KEY: raise HTTPException(500, "GEMINI_API_KEY no configurada")
    cached = _read_cache(); age = _cache_age()
    if cached is None or age >= REFRESH_INTERVAL_SECONDS:
        ok, msg = _refresh_news("on_request")
        if ok: cached = _read_cache(); age = _cache_age()
        elif cached is None: raise HTTPException(502, f"No se pudieron obtener las noticias: {msg}")
    if cached is None: raise HTTPException(503, "Noticias todavía no disponibles")
    cached["cache_age_seconds"] = int(age) if age != float("inf") else None
    cached["cache_status"] = "fresh" if age < REFRESH_INTERVAL_SECONDS else "stale"
    return cached

@app.post("/news/refresh")
def manual_news_refresh():
    ok, msg = _refresh_news("manual")
    if not ok: return {"updated":False, "reason":msg, "health":health()}
    return {"updated":True, "news":_read_cache(), "health":health()}

@app.post("/chat")
def chat(body: Chat):
    if not GEMINI_API_KEY: raise HTTPException(500, "GEMINI_API_KEY no configurada")
    with _lock:
        u = _load_usage()
        if u.get("gemini_calls", 0) >= MAX_GEMINI_CALLS_PER_DAY:
            raise HTTPException(429, "Límite diario interno de Gemini alcanzado; Invest AI no hará más llamadas hoy.")
        u["gemini_calls"] = u.get("gemini_calls", 0) + 1; _save_usage(u)
    prompt = f"Contexto de cartera:\n{body.portfolio}\n\nContexto de Invest AI:\n{body.app_context}\n\nPregunta:\n{body.question}\n\nResponde usando solo el contexto proporcionado y conocimiento general; no afirmes haber consultado Internet en esta llamada."
    try:
        answer, used_model = _gemini_generate(prompt, system_instruction=SYSTEM, temperature=0.3)
        return {"answer":answer or "Gemini no devolvió contenido.", "provider":"Gemini", "model":used_model, "usage":{"gemini_calls_today":u["gemini_calls"], "daily_gemini_limit":MAX_GEMINI_CALLS_PER_DAY}}
    except Exception as exc:
        with _lock:
            u = _load_usage(); u["gemini_calls"] = max(0, u.get("gemini_calls", 1)-1); _save_usage(u)
        raise HTTPException(502, f"No se pudo consultar Gemini: {exc}")
