import json
import os
import re
import random
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone, timedelta
from html import unescape
from pathlib import Path
from urllib.parse import quote, urlparse
from urllib.request import Request, urlopen

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import feedparser

app = FastAPI(title="Invest AI Financial Analyst", version="5.7")
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "").strip().strip('"').strip("'")
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-3.5-flash-lite")
GEMINI_FALLBACK_MODEL = os.environ.get("GEMINI_FALLBACK_MODEL", "gemini-3.8-flash")

# Compatibilidad con despliegues anteriores: si Render conserva las variables
# antiguas apuntando ambas a Gemini 3.8, corregimos automáticamente la pareja
# para que el nivel gratuito use Flash-Lite como primario.
if GEMINI_MODEL == "gemini-3.8-flash" and GEMINI_FALLBACK_MODEL == "gemini-3.8-flash":
    GEMINI_MODEL = "gemini-3.5-flash-lite"
    GEMINI_FALLBACK_MODEL = "gemini-3.8-flash"
GEMINI_PRIMARY_RETRIES = int(os.environ.get("GEMINI_PRIMARY_RETRIES", "3"))
GEMINI_FALLBACK_RETRIES = int(os.environ.get("GEMINI_FALLBACK_RETRIES", "2"))
GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
INDEXES = {
    "S&P 500", "Nasdaq-100", "Dow Jones", "Russell 2000", "EURO STOXX 50",
    "STOXX Europe 600", "DAX 40", "FTSE 100", "CAC 40", "IBEX 35", "SMI",
    "Nikkei 225", "TOPIX", "Hang Seng", "S&P/ASX 200"
}

# v4.0: news discovery is performed directly against public RSS/Atom feeds.
# Gemini receives the collected headlines/snippets and performs analysis WITHOUT
# Google Search grounding. This avoids paid Search grounding while preserving
# traceable source URLs and a source-quality policy.
CACHE_DIR = Path(os.environ.get("INVESTAI_CACHE_DIR", "/tmp/investai_cache"))
CACHE_DIR.mkdir(parents=True, exist_ok=True)
NEWS_CACHE_FILE = CACHE_DIR / "news.json"
USAGE_FILE = CACHE_DIR / "usage.json"
COLLECTOR_STATUS_FILE = CACHE_DIR / "collector_status.json"
REFRESH_INTERVAL_SECONDS = int(os.environ.get("NEWS_REFRESH_INTERVAL_SECONDS", "600"))
MAX_REFRESHES_PER_DAY = int(os.environ.get("MAX_REFRESHES_PER_DAY", "96"))
MAX_GEMINI_CALLS_PER_DAY = int(os.environ.get("MAX_GEMINI_CALLS_PER_DAY", "96"))
FETCH_TIMEOUT_SECONDS = int(os.environ.get("NEWS_FETCH_TIMEOUT_SECONDS", "12"))
MAX_ITEMS_PER_FEED = int(os.environ.get("MAX_ITEMS_PER_FEED", "12"))
MAX_ITEMS_FOR_GEMINI = int(os.environ.get("MAX_ITEMS_FOR_GEMINI", "48"))
GEMINI_HTTP_TIMEOUT_SECONDS = int(os.environ.get("GEMINI_HTTP_TIMEOUT_SECONDS", "90"))
_lock = threading.Lock()
_last_refresh_started = 0.0
_background_started = False

PRIMARY_SOURCES = {
    "reguladores_y_oficiales": [
        "sec.gov", "cnmv.es", "esma.europa.eu", "eba.europa.eu", "ecb.europa.eu",
        "bde.es", "federalreserve.gov", "fred.stlouisfed.org", "bea.gov", "bls.gov",
        "eurostat.ec.europa.eu", "ec.europa.eu", "imf.org", "worldbank.org", "oecd.org",
        "eia.gov", "iea.org", "ismworld.org"
    ],
    "medios_financieros_de_contraste": ["reuters.com", "apnews.com", "cnbc.com", "marketwatch.com"],
}
ALL_PRIMARY_DOMAINS = sorted({d for group in PRIMARY_SOURCES.values() for d in group})

# v5.0 - market scoring engine. Quantitative score is calculated locally from
# provider data; Gemini is never allowed to invent numeric inputs.
MARKET_CACHE_FILE = CACHE_DIR / "market.json"
MARKET_REFRESH_SECONDS = int(os.environ.get("MARKET_REFRESH_SECONDS", "900"))
MARKET_PRICE_PROVIDER = os.environ.get("MARKET_PRICE_PROVIDER", "yahoo_chart_public")
MARKET_DATA_MIN_DAYS = int(os.environ.get("MARKET_DATA_MIN_DAYS", "60"))
MARKET_REQUEST_DELAY_SECONDS = float(os.environ.get("MARKET_REQUEST_DELAY_SECONDS", "0.25"))
MARKET_RETRY_SECONDS = float(os.environ.get("MARKET_RETRY_SECONDS", "0.0"))
MARKET_CACHE_MAX_AGE_SECONDS = int(os.environ.get("MARKET_CACHE_MAX_AGE_SECONDS", "1800"))
MARKET_MAX_SYMBOLS_PER_REFRESH = int(os.environ.get("MARKET_MAX_SYMBOLS_PER_REFRESH", "150"))
MARKET_WORKERS = int(os.environ.get("MARKET_WORKERS", "8"))
MARKET_YAHOO_TIMEOUT_SECONDS = float(os.environ.get("MARKET_YAHOO_TIMEOUT_SECONDS", "4"))
MARKET_STOOQ_TIMEOUT_SECONDS = float(os.environ.get("MARKET_STOOQ_TIMEOUT_SECONDS", "5"))
MARKET_REFRESH_LOCK = threading.Lock()
MARKET_CACHE_WRITE_LOCK = threading.Lock()
MARKET_REFRESH_STATE = {"last_started": 0.0, "last_finished": 0.0, "last_success": 0, "last_failed": 0, "last_429": 0, "provider_used": {}, "last_error": None, "in_progress": False, "completed": 0, "total": 0}

# Initial universe: ten companies per selected index. These are an analysis
# universe, not an automatic recommendation or ranking. Exchange tickers are
# mapped to a public chart provider symbol where known.
COMPANY_UNIVERSE = {
    "S&P 500": [("NVIDIA","NVDA"),("Microsoft","MSFT"),("Amazon","AMZN"),("Meta","META"),("Alphabet","GOOGL"),("Broadcom","AVGO"),("Apple","AAPL"),("Eli Lilly","LLY"),("JPMorgan","JPM"),("Exxon Mobil","XOM")],
    "Nasdaq-100": [("NVIDIA","NVDA"),("Microsoft","MSFT"),("Amazon","AMZN"),("Meta","META"),("Broadcom","AVGO"),("Alphabet","GOOGL"),("Apple","AAPL"),("Tesla","TSLA"),("Netflix","NFLX"),("Costco","COST")],
    "Dow Jones": [("Microsoft","MSFT"),("Apple","AAPL"),("JPMorgan","JPM"),("Visa","V"),("Coca-Cola","KO"),("Amazon","AMZN"),("Walmart","WMT"),("Goldman Sachs","GS"),("American Express","AXP"),("McDonald's","MCD")],
    "Russell 2000": [("AppLovin","APP"),("Rocket Lab","RKLB"),("Cava Group","CAVA"),("Sprouts Farmers Market","SFM"),("Vertiv","VRT"),("Comfort Systems USA","FIX"),("Fabrinet","FN"),("Abercrombie & Fitch","ANF"),("Wingstop","WING"),("Duolingo","DUOL")],
    "EURO STOXX 50": [("ASML","ASML"),("SAP","SAP"),("LVMH","MC.PA"),("Siemens","SIE.DE"),("Schneider Electric","SU.PA"),("Airbus","AIR.PA"),("Allianz","ALV.DE"),("TotalEnergies","TTE.PA"),("Sanofi","SAN.PA"),("Deutsche Telekom","DTE.DE")],
    "STOXX Europe 600": [("ASML","ASML"),("SAP","SAP"),("Schneider Electric","SU.PA"),("Siemens","SIE.DE"),("Airbus","AIR.PA"),("Roche","ROG.SW"),("Novartis","NOVN.SW"),("Allianz","ALV.DE"),("LVMH","MC.PA"),("ABB","ABBN.SW")],
    "DAX 40": [("SAP","SAP.DE"),("Siemens","SIE.DE"),("Allianz","ALV.DE"),("Airbus","AIR.DE"),("Munich Re","MUV2.DE"),("Rheinmetall","RHM.DE"),("Deutsche Telekom","DTE.DE"),("Infineon","IFX.DE"),("Mercedes-Benz","MBG.DE"),("BASF","BAS.DE")],
    "FTSE 100": [("AstraZeneca","AZN.L"),("Shell","SHEL.L"),("HSBC","HSBA.L"),("Unilever","ULVR.L"),("Rolls-Royce","RR.L"),("BP","BP.L"),("RELX","REL.L"),("BAE Systems","BA.L"),("GSK","GSK.L"),("National Grid","NG.L")],
    "CAC 40": [("LVMH","MC.PA"),("Schneider Electric","SU.PA"),("Airbus","AIR.PA"),("Safran","SAF.PA"),("L'Oreal","OR.PA"),("Hermes","RMS.PA"),("Vinci","DG.PA"),("Air Liquide","AI.PA"),("AXA","CS.PA"),("TotalEnergies","TTE.PA")],
    "IBEX 35": [("Inditex","ITX.MC"),("Iberdrola","IBE.MC"),("Santander","SAN.MC"),("BBVA","BBVA.MC"),("Amadeus IT","AMS.MC"),("Aena","AENA.MC"),("Ferrovial","FER.MC"),("Cellnex Telecom","CLNX.MC"),("CaixaBank","CABK.MC"),("ACS","ACS.MC")],
    "SMI": [("Nestle","NESN.SW"),("Novartis","NOVN.SW"),("Roche","ROG.SW"),("UBS","UBSG.SW"),("ABB","ABBN.SW"),("Zurich Insurance","ZURN.SW"),("Richemont","CFR.SW"),("Sika","SIKA.SW"),("Holcim","HOLN.SW"),("Swiss Re","SREN.SW")],
    "Nikkei 225": [("Toyota","7203.T"),("Sony","6758.T"),("Mitsubishi UFJ","8306.T"),("Hitachi","6501.T"),("Tokyo Electron","8035.T"),("Keyence","6861.T"),("Nintendo","7974.T"),("Fast Retailing","9983.T"),("Mitsubishi Heavy Industries","7011.T"),("Recruit Holdings","6098.T")],
    "TOPIX": [("Toyota","7203.T"),("Sony","6758.T"),("Tokyo Electron","8035.T"),("Mitsubishi UFJ","8306.T"),("Hitachi","6501.T"),("Keyence","6861.T"),("Nintendo","7974.T"),("Fast Retailing","9983.T"),("Advantest","6857.T"),("SoftBank Group","9984.T")],
    "Hang Seng": [("Tencent","0700.HK"),("Alibaba","9988.HK"),("Meituan","3690.HK"),("HSBC","0005.HK"),("China Mobile","0941.HK"),("AIA Group","1299.HK"),("Xiaomi","1810.HK"),("JD.com","9618.HK"),("CNOOC","0883.HK"),("Lenovo","0992.HK")],
    "S&P/ASX 200": [("BHP","BHP.AX"),("Commonwealth Bank","CBA.AX"),("CSL","CSL.AX"),("Westpac","WBC.AX"),("ANZ Group","ANZ.AX"),("Macquarie Group","MQG.AX"),("Woodside Energy","WDS.AX"),("Wesfarmers","WES.AX"),("Goodman Group","GMG.AX"),("Transurban","TCL.AX")],
}

# v5.7 - company-level news attribution. Each news item may point to exact
# universe tickers; index-level news is distributed with a lower relation weight.
SYMBOL_TO_COMPANY = {}
SYMBOL_TO_INDEXES = {}
for _idx, _companies in COMPANY_UNIVERSE.items():
    for _name, _symbol in _companies:
        SYMBOL_TO_COMPANY[_symbol] = _name
        SYMBOL_TO_INDEXES.setdefault(_symbol, []).append(_idx)
ALL_UNIVERSE_SYMBOLS = sorted(SYMBOL_TO_COMPANY)

SCORE_WEIGHTS = {"valuation":20,"growth":20,"financial_health":15,"technical":15,"analyst_revisions":10,"news_sentiment":10,"risk":10}


# v5.5 - fundamental engine. Numeric fundamentals are collected from public
# structured endpoints. SEC CompanyFacts is preferred for US issuers; Yahoo's
# public fundamentals-timeseries endpoint is used as a secondary public source
# for the broader international universe. Gemini is never used to invent a
# financial number.
FUNDAMENTALS_CACHE_FILE = CACHE_DIR / "fundamentals.json"
FUNDAMENTALS_REFRESH_SECONDS = int(os.environ.get("FUNDAMENTALS_REFRESH_SECONDS", "21600"))
FUNDAMENTALS_TIMEOUT_SECONDS = float(os.environ.get("FUNDAMENTALS_TIMEOUT_SECONDS", "8"))
FUNDAMENTALS_WORKERS = int(os.environ.get("FUNDAMENTALS_WORKERS", "6"))
FUNDAMENTALS_LOOKBACK_YEARS = int(os.environ.get("FUNDAMENTALS_LOOKBACK_YEARS", "5"))
FUNDAMENTALS_REFRESH_LOCK = threading.Lock()
FUNDAMENTALS_STATE = {"last_started": 0.0, "last_finished": 0.0, "last_success": 0,
                      "last_failed": 0, "in_progress": False, "completed": 0,
                      "total": 0, "last_error": None, "source_usage": {}}

# Symbols whose accounting structure makes generic debt/EBITDA valuation
# misleading. They receive a financial-sector scoring profile instead.
BANK_SYMBOLS = {
    "JPM","GS","AXP","SAN.MC","BBVA.MC","CABK.MC","UBSG.SW","8306.T",
    "0005.HK","CBA.AX","WBC.AX","ANZ.AX","MQG.AX"
}
INSURANCE_SYMBOLS = {
    "ALV.DE","MUV2.DE","ZURN.SW","SREN.SW","1299.HK"
}

SEC_TICKER_CACHE_FILE = CACHE_DIR / "sec_tickers.json"
SEC_TICKER_CACHE_MAX_AGE = 7 * 86400

FUNDAMENTAL_FIELDS = [
    "annualTotalRevenue", "annualOperatingIncome", "annualNetIncome",
    "annualFreeCashFlow", "annualDilutedEPS", "annualTotalDebt",
    "annualCashCashEquivalentsAndShortTermInvestments", "annualStockholdersEquity",
    "annualTotalAssets", "annualDilutedAverageShares", "annualEBITDA",
    "annualDepreciationAndAmortization"
]


def _load_fundamentals_cache():
    try:
        if not FUNDAMENTALS_CACHE_FILE.exists():
            return {}
        d = json.loads(FUNDAMENTALS_CACHE_FILE.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _save_fundamentals_cache(data):
    tmp = FUNDAMENTALS_CACHE_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    tmp.replace(FUNDAMENTALS_CACHE_FILE)


def _sec_ticker_map():
    """Return ticker -> CIK from SEC's public ticker file, cached for a week."""
    now = time.time()
    try:
        if SEC_TICKER_CACHE_FILE.exists() and now - SEC_TICKER_CACHE_FILE.stat().st_mtime < SEC_TICKER_CACHE_MAX_AGE:
            return json.loads(SEC_TICKER_CACHE_FILE.read_text(encoding="utf-8"))
    except Exception:
        pass
    try:
        req = Request(
            "https://www.sec.gov/files/company_tickers.json",
            headers={"User-Agent": "InvestAI research contact investai@example.com", "Accept": "application/json"},
        )
        with urlopen(req, timeout=FUNDAMENTALS_TIMEOUT_SECONDS) as r:
            raw = json.loads(r.read(5_000_000).decode("utf-8"))
        mapping = {}
        for item in raw.values() if isinstance(raw, dict) else []:
            ticker = str(item.get("ticker", "")).upper()
            cik = str(item.get("cik_str", "")).zfill(10)
            if ticker and cik:
                mapping[ticker] = cik
        SEC_TICKER_CACHE_FILE.write_text(json.dumps(mapping), encoding="utf-8")
        return mapping
    except Exception:
        return {}


def _sec_companyfacts(symbol):
    """Extract the latest annual facts and previous annual facts from SEC XBRL."""
    mapping = _sec_ticker_map()
    cik = mapping.get(symbol.upper())
    if not cik:
        return None
    url = f"https://data.sec.gov/api/xbrl/companyfacts/CIK{cik}.json"
    req = Request(url, headers={"User-Agent": "InvestAI research contact investai@example.com", "Accept": "application/json"})
    with urlopen(req, timeout=FUNDAMENTALS_TIMEOUT_SECONDS) as r:
        data = json.loads(r.read(15_000_000).decode("utf-8"))
    facts = data.get("facts", {})
    usgaap = facts.get("us-gaap", {})
    if not usgaap:
        return None

    aliases = {
        "revenue": ["Revenues", "RevenueFromContractWithCustomerExcludingAssessedTax", "SalesRevenueNet"],
        "operating_income": ["OperatingIncomeLoss"],
        "net_income": ["NetIncomeLoss", "ProfitLoss"],
        "fcf": [],
        "eps": ["EarningsPerShareDiluted"],
        "debt": ["LongTermDebtAndFinanceLeaseObligationsCurrent", "LongTermDebtCurrent", "LongTermDebtNoncurrent"],
        "cash": ["CashAndCashEquivalentsAtCarryingValue"],
        "equity": ["StockholdersEquity", "StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest"],
        "assets": ["Assets"],
        "shares": ["WeightedAverageNumberOfDilutedSharesOutstanding"],
        "ebitda": [],
        "da": ["DepreciationDepletionAndAmortization"],
    }
    def choose(names):
        for name in names:
            unit = usgaap.get(name)
            if not unit:
                continue
            units = unit.get("units", {})
            candidates = []
            for arr in units.values():
                for x in arr:
                    if x.get("form") in ("10-K", "10-K/A", "20-F", "40-F") and x.get("fy"):
                        candidates.append(x)
            if candidates:
                candidates.sort(key=lambda x: (int(x.get("fy", 0)), x.get("filed", "")))
                return candidates[-1], candidates[-2] if len(candidates) > 1 else None
        return None, None
    out = {}
    for key, names in aliases.items():
        if not names:
            continue
        latest, previous = choose(names)
        if latest:
            out[key] = {"latest": latest.get("val"), "previous": previous.get("val") if previous else None,
                        "fy": latest.get("fy"), "filed": latest.get("filed"), "source": "SEC CompanyFacts"}
    # FCF is not a universal single XBRL tag. Calculate it only when both CFO and
    # capex are available, keeping the provenance explicit.
    cfo, _ = choose(["NetCashProvidedByUsedInOperatingActivities"])
    capex, _ = choose(["PaymentsToAcquirePropertyPlantAndEquipment"])
    if cfo:
        out["cfo"] = {"latest": cfo.get("val"), "previous": None, "fy": cfo.get("fy"), "filed": cfo.get("filed"), "source": "SEC CompanyFacts"}
    if capex:
        out["capex"] = {"latest": capex.get("val"), "previous": None, "fy": capex.get("fy"), "filed": capex.get("filed"), "source": "SEC CompanyFacts"}
    if cfo and capex:
        out["fcf"] = {"latest": float(cfo.get("val", 0)) - float(capex.get("val", 0)), "previous": None,
                       "fy": cfo.get("fy"), "filed": cfo.get("filed"), "source": "SEC CompanyFacts (calculado)"}
    return out or None


def _yahoo_fundamental_series(symbol):
    period1 = int(time.time()) - FUNDAMENTALS_LOOKBACK_YEARS * 370 * 86400
    period2 = int(time.time())
    types = ",".join(FUNDAMENTAL_FIELDS)
    url = ("https://query1.finance.yahoo.com/ws/fundamentals-timeseries/v1/finance/timeseries/"
           f"{quote(symbol, safe='')}?symbol={quote(symbol, safe='')}&type={quote(types, safe=',')}&merge=false"
           f"&period1={period1}&period2={period2}")
    req = Request(url, headers={"User-Agent": "Mozilla/5.0 InvestAI/5.5", "Accept": "application/json"})
    with urlopen(req, timeout=FUNDAMENTALS_TIMEOUT_SECONDS) as r:
        payload = json.loads(r.read(5_000_000).decode("utf-8"))
    result = ((payload.get("timeseries") or {}).get("result") or [])
    out = {}
    for series in result:
        for field in FUNDAMENTAL_FIELDS:
            arr = series.get(field)
            if not isinstance(arr, list) or not arr:
                continue
            rows = sorted([x for x in arr if isinstance(x, dict) and x.get("reportedValue") is not None], key=lambda x: x.get("asOfDate", ""))
            if rows:
                vals = []
                for row in rows:
                    rv = row.get("reportedValue")
                    value = rv.get("raw") if isinstance(rv, dict) else rv
                    if isinstance(value, (int, float)):
                        vals.append({"value": float(value), "date": row.get("asOfDate"), "periodType": row.get("periodType")})
                if vals:
                    out[field] = vals
    return out or None


def _series_latest(series, field):
    arr = series.get(field) if isinstance(series, dict) else None
    if not arr:
        return None
    annual = [x for x in arr if x.get("periodType") in ("12M", "FY", "annual")]
    return (annual or arr)[-1]


def _fundamental_metric(series, field):
    x = _series_latest(series, field)
    return x.get("value") if x else None


def _fundamental_snapshot(name, symbol, market_price=None):
    """Return normalized metrics and three component scores, never fabricating missing data."""
    source = None
    raw = None
    try:
        raw = _sec_companyfacts(symbol) if symbol.isalpha() and "." not in symbol else None
        source = "SEC CompanyFacts" if raw else None
    except Exception:
        raw = None
    if raw is None:
        series = _yahoo_fundamental_series(symbol)
        raw = {}
        for key, arr in (series or {}).items():
            latest = arr[-1] if arr else None
            previous = arr[-2] if len(arr) > 1 else None
            if latest:
                raw[key] = {"latest": latest.get("value"), "previous": previous.get("value") if previous else None,
                            "date": latest.get("date"), "source": "Yahoo fundamentals-timeseries"}
        source = "Yahoo fundamentals-timeseries" if raw else None
    if not raw:
        raise RuntimeError("sin datos fundamentales públicos")

    def val(k):
        x = raw.get(k)
        return x.get("latest") if isinstance(x, dict) else None
    def prev(k):
        x = raw.get(k)
        return x.get("previous") if isinstance(x, dict) else None

    revenue = val("annualTotalRevenue") or val("revenue")
    op = val("annualOperatingIncome") or val("operating_income")
    net = val("annualNetIncome") or val("net_income")
    fcf = val("annualFreeCashFlow") or val("fcf")
    eps = val("annualDilutedEPS") or val("eps")
    debt = val("annualTotalDebt") or val("debt")
    cash = val("annualCashCashEquivalentsAndShortTermInvestments") or val("cash")
    equity = val("annualStockholdersEquity") or val("equity")
    assets = val("annualTotalAssets") or val("assets")
    shares = val("annualDilutedAverageShares") or val("shares")
    ebitda = val("annualEBITDA")
    da = val("annualDepreciationAndAmortization") or val("da")
    if ebitda is None and op is not None and da is not None:
        ebitda = op + abs(da)

    revenue_prev = prev("annualTotalRevenue") or prev("revenue")
    net_prev = prev("annualNetIncome") or prev("net_income")
    eps_prev = prev("annualDilutedEPS") or prev("eps")
    growth_revenue = ((revenue / revenue_prev) - 1) * 100 if revenue is not None and revenue_prev and revenue_prev != 0 else None
    growth_net = ((net / net_prev) - 1) * 100 if net is not None and net_prev and net_prev != 0 else None
    growth_eps = ((eps / eps_prev) - 1) * 100 if eps is not None and eps_prev and eps_prev != 0 else None
    margin = (op / revenue) * 100 if op is not None and revenue else None
    roe = (net / equity) * 100 if net is not None and equity else None
    debt_to_ebitda = debt / ebitda if debt is not None and ebitda and ebitda > 0 else None
    current_fcf_yield = (fcf / (market_price * shares)) * 100 if fcf is not None and market_price and shares and market_price > 0 else None
    pe = market_price / eps if market_price and eps and eps > 0 else None

    def bounded_inverse(x, good, bad):
        if x is None: return None
        if good == bad: return 50
        return _score_band(100 * (bad - x) / (bad - good))
    def bounded_direct(x, bad, good):
        if x is None: return None
        if good == bad: return 50
        return _score_band(100 * (x - bad) / (good - bad))

    financial_sector = symbol in BANK_SYMBOLS or symbol in INSURANCE_SYMBOLS
    if financial_sector:
        # For banks/insurers, leverage is structural and EV/EBITDA is not useful.
        valuation_parts = [bounded_inverse(pe, 10, 35)]
        health_parts = [bounded_direct(roe, 0, 20)]
        if equity and assets:
            health_parts.append(bounded_direct(equity / assets * 100, 2, 15))
    else:
        valuation_parts = [bounded_inverse(pe, 10, 35), bounded_inverse(debt_to_ebitda, 1, 5), bounded_direct(current_fcf_yield, -2, 10)]
        health_parts = [bounded_direct(roe, 0, 20), bounded_inverse(debt_to_ebitda, 1, 5)]
        if equity and assets:
            health_parts.append(bounded_direct(equity / assets * 100, 10, 50))
    valuation = _score_band(sum(x for x in valuation_parts if x is not None) / len([x for x in valuation_parts if x is not None])) if any(x is not None for x in valuation_parts) else None
    growth_values = [bounded_direct(x, -10, 25) for x in (growth_revenue, growth_net, growth_eps)]
    growth = _score_band(sum(x for x in growth_values if x is not None) / len([x for x in growth_values if x is not None])) if any(x is not None for x in growth_values) else None
    health = _score_band(sum(x for x in health_parts if x is not None) / len([x for x in health_parts if x is not None])) if any(x is not None for x in health_parts) else None
    return {
        "source": source,
        "reported_date": (raw.get("annualTotalRevenue") or raw.get("revenue") or {}).get("date") or (raw.get("revenue") or {}).get("filed"),
        "metrics": {"revenue": revenue, "operating_income": op, "net_income": net, "free_cash_flow": fcf,
                    "eps": eps, "debt": debt, "cash": cash, "equity": equity, "assets": assets,
                    "ebitda": ebitda, "shares": shares, "pe": pe, "fcf_yield_pct": current_fcf_yield,
                    "revenue_growth_pct": growth_revenue, "net_income_growth_pct": growth_net,
                    "eps_growth_pct": growth_eps, "operating_margin_pct": margin, "roe_pct": roe,
                    "debt_to_ebitda": debt_to_ebitda},
        "scores": {"valuation": valuation, "growth": growth, "financial_health": health},
        "data_quality": "alta" if source == "SEC CompanyFacts" else "media",
    }


def _fundamental_market_score(index_name, name, symbol, market_price):
    cache = _load_fundamentals_cache()
    entry = cache.get(symbol) if isinstance(cache, dict) else None
    if not entry:
        return {"fundamentals": None, "scores": {}}
    fundamentals = entry.get("fundamentals") if isinstance(entry, dict) else None
    if not fundamentals:
        return {"fundamentals": None, "scores": {}}
    # IMPORTANT: market screens must never trigger a fresh fundamentals request.
    # Reuse the verified cached figures and only recompute metrics that depend on
    # today's cached market price (P/E and FCF yield).
    metrics = dict(fundamentals.get("metrics", {}))
    eps = metrics.get("eps"); fcf = metrics.get("free_cash_flow"); shares = metrics.get("shares")
    if market_price and eps and eps > 0:
        metrics["pe"] = market_price / eps
    if market_price and fcf is not None and shares and shares > 0:
        metrics["fcf_yield_pct"] = (fcf / (market_price * shares)) * 100
    scores = dict(fundamentals.get("scores", {}))
    # Refresh valuation score from current price where enough inputs exist.
    pe = metrics.get("pe"); fcf_yield = metrics.get("fcf_yield_pct"); debt_ebitda = metrics.get("debt_to_ebitda")
    def inv(x, good, bad):
        if x is None or bad == good: return None
        return _score_band(100 * (bad - x) / (bad - good))
    def direct(x, bad, good):
        if x is None or bad == good: return None
        return _score_band(100 * (x - bad) / (good - bad))
    vals = [inv(pe, 10, 35), inv(debt_ebitda, 1, 5), direct(fcf_yield, -2, 10)]
    vals = [x for x in vals if x is not None]
    if symbol in BANK_SYMBOLS or symbol in INSURANCE_SYMBOLS:
        vals = [inv(pe, 10, 35)]
    if vals:
        scores["valuation"] = _score_band(sum(vals) / len(vals))
    updated = dict(fundamentals)
    updated["metrics"] = metrics
    updated["scores"] = scores
    return {"fundamentals": updated, "scores": scores}


def _refresh_one_fundamental(pair):
    name, symbol = pair
    try:
        # Fundamental snapshot uses current market price only if it is already cached.
        market_cache = _load_market_cache(); price = None
        m = market_cache.get(symbol) if isinstance(market_cache, dict) else None
        if isinstance(m, dict) and m.get("rows"):
            price = m["rows"][-1].get("close")
        snap = _fundamental_snapshot(name, symbol, market_price=price)
        return symbol, {"name": name, "symbol": symbol, "updated_at_epoch": time.time(), "fundamentals": snap}, None
    except Exception as exc:
        return symbol, None, str(exc)[:500]


def _refresh_fundamentals(symbols=None):
    work = list(symbols or _all_market_symbols())[:MARKET_MAX_SYMBOLS_PER_REFRESH]
    if not work or not FUNDAMENTALS_REFRESH_LOCK.acquire(blocking=False):
        return {"refreshed": 0, "failed": 0, "reason": "actualización ya en curso"}
    started = time.time()
    FUNDAMENTALS_STATE.update({"last_started": started, "last_finished": 0.0, "last_success": 0,
                               "last_failed": 0, "in_progress": True, "completed": 0,
                               "total": len(work), "last_error": None, "source_usage": {}})
    cache = _load_fundamentals_cache(); ok = failed = 0
    try:
        with ThreadPoolExecutor(max_workers=max(1, min(FUNDAMENTALS_WORKERS, len(work))), thread_name_prefix="fundamental-fetch") as pool:
            futures = [pool.submit(_refresh_one_fundamental, pair) for pair in work]
            for fut in as_completed(futures):
                symbol, entry, error = fut.result()
                if entry:
                    cache[symbol] = entry; ok += 1
                    FUNDAMENTALS_STATE["source_usage"][symbol] = entry["fundamentals"].get("source")
                else:
                    failed += 1; FUNDAMENTALS_STATE["last_error"] = error
                FUNDAMENTALS_STATE["completed"] = ok + failed
                FUNDAMENTALS_STATE["last_success"] = ok; FUNDAMENTALS_STATE["last_failed"] = failed
                _save_fundamentals_cache(cache)
    except Exception as exc:
        FUNDAMENTALS_STATE["last_error"] = str(exc)[:500]
    finally:
        FUNDAMENTALS_STATE["last_finished"] = time.time(); FUNDAMENTALS_STATE["last_success"] = ok
        FUNDAMENTALS_STATE["last_failed"] = failed; FUNDAMENTALS_STATE["in_progress"] = False
        FUNDAMENTALS_REFRESH_LOCK.release()
    return {"refreshed": ok, "failed": failed, "duration_seconds": round(time.time()-started, 1)}


def _ensure_fundamentals_refresh_started():
    cache = _load_fundamentals_cache()
    total = len(_all_market_symbols())
    if len(cache) >= total and all(isinstance(v, dict) for v in cache.values()):
        # Still refresh periodically in the background; don't launch a duplicate.
        newest = max([float(v.get("updated_at_epoch", 0)) for v in cache.values()] or [0])
        if time.time() - newest < FUNDAMENTALS_REFRESH_SECONDS:
            return False
    if FUNDAMENTALS_STATE.get("in_progress") or FUNDAMENTALS_REFRESH_LOCK.locked():
        return False
    threading.Thread(target=lambda: _refresh_fundamentals(), daemon=True, name="investai-fundamentals-refresh").start()
    return True

def _score_band(value):
    if value is None: return None
    return max(0, min(100, round(float(value))))

def _weighted_score(parts):
    available=[]; weighted=0.0; total_weight=0.0
    for key,w in SCORE_WEIGHTS.items():
        v=parts.get(key)
        if isinstance(v,(int,float)) and v == v:
            available.append(key); weighted += float(v)*w; total_weight += w
    if total_weight <= 0: return None, 0, []
    # Never pretend missing dimensions were zero: renormalize across available data.
    return _score_band(weighted/total_weight), round(total_weight), available

def _technical_score(closes):
    if len(closes) < 60: return None
    last=closes[-1]; sma20=sum(closes[-20:])/20; sma50=sum(closes[-50:])/50
    ret20=(last/closes[-21]-1)*100 if closes[-21] else 0
    score=50 + (15 if last>sma20 else -15) + (20 if last>sma50 else -20) + max(-15,min(15,ret20*1.5))
    return _score_band(score)

def _risk_score(closes):
    if len(closes) < 30: return None
    rets=[]
    for a,b in zip(closes[-31:-1],closes[-30:]):
        if a: rets.append(b/a-1)
    if len(rets)<20: return None
    mean=sum(rets)/len(rets); var=sum((x-mean)**2 for x in rets)/len(rets); vol=(var**0.5)*(252**0.5)
    # Higher score = lower observed volatility. This is not a forecast.
    return _score_band(100-max(0,min(100,vol*250)))

def _market_provider_status():
    return {"provider":"cache + Yahoo/Stooq fallback","disclaimer":"Precios de mercado pueden tener retraso y están sujetos a los términos de los proveedores; no se presentan como cotización en tiempo real."}

# Public feeds. Google News RSS is used only as a free discovery/transport layer;
# Gemini does not use Google Search grounding. Queries are restricted to named
# publishers or official domains so the backend can keep source provenance.
FEEDS = [
    # Official feeds. A failure is isolated and never blocks the collector.
    # SEC publishes EDGAR/press RSS and explicitly documents RSS as an access path.
    ("SEC", "https://www.sec.gov/news/pressreleases.rss", "official"),
        ("Federal Reserve", "https://www.federalreserve.gov/feeds/press_all.xml", "official"),
    ("BLS", "https://www.bls.gov/feed/bls_latest.rss", "official"),
    ("BLS CPI", "https://www.bls.gov/feed/cpi_latest.rss", "official"),
    ("BEA", "https://apps.bea.gov/rss/rss.xml", "official"),
    ("ECB", "https://www.ecb.europa.eu/rss/press.html", "official"),
    # Reputable publisher discovery feeds. The article URL is preserved and the
    # publisher is retained as the provenance; Gemini cannot create new URLs.
    ("Reuters", "https://news.google.com/rss/search?q=" + quote("site:reuters.com (markets OR stocks OR earnings OR economy)"), "reputable_secondary"),
    ("AP", "https://news.google.com/rss/search?q=" + quote("site:apnews.com (markets OR stocks OR economy)"), "reputable_secondary"),
    ("CNBC", "https://news.google.com/rss/search?q=" + quote("site:cnbc.com (markets OR stocks OR earnings OR economy)"), "reputable_secondary"),
    ("MarketWatch", "https://news.google.com/rss/search?q=" + quote("site:marketwatch.com (stocks OR markets OR earnings)"), "reputable_secondary"),
    ("CNMV", "https://news.google.com/rss/search?q=" + quote("site:cnmv.es (mercados OR cotizadas OR hechos relevantes)"), "official_discovery"),
    ("ECB/Euro area", "https://news.google.com/rss/search?q=" + quote("site:ecb.europa.eu euro area monetary policy"), "official_discovery"),
    ("EU Commission", "https://news.google.com/rss/search?q=" + quote("site:ec.europa.eu economy finance markets"), "official_discovery"),
]

SYSTEM = f"""Eres el Analista IA de Invest AI, especializado en mercados de capitales.
Responde en español, con rigor y sin inventar información.
La información que recibes procede de un recopilador de fuentes públicas. NO tienes Google Search en esta llamada y NO debes fingir que has verificado nada fuera del material proporcionado.
Prioridad de evidencia: fuentes regulatorias/oficiales > comunicados corporativos > Reuters/AP/CNBC/MarketWatch > otros.
No conviertas un rumor en un hecho. Si una noticia importante solo tiene una fuente secundaria, indícalo como no corroborada.
Cuando dos fuentes independientes describan el mismo hecho, puedes indicar que está corroborado, pero no inventes corroboración.
Conserva siempre la URL de la fuente proporcionada.
La puntuación 0–100 es una puntuación de oportunidad del modelo, NO una probabilidad de beneficio ni una recomendación automática.
Fuentes oficiales configuradas: {', '.join(ALL_PRIMARY_DOMAINS)}"""

class Chat(BaseModel):
    question: str
    portfolio: str = ""
    app_context: str = ""


def _now(): return datetime.now(timezone.utc)
def _day(): return _now().strftime("%Y-%m-%d")

def _load_usage():
    default = {"day": _day(), "refreshes": 0, "gemini_calls": 0}
    try:
        d = json.loads(USAGE_FILE.read_text(encoding="utf-8"))
        if d.get("day") != _day(): d = default
        return d
    except Exception:
        return default

def _save_usage(d):
    tmp = USAGE_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(d), encoding="utf-8")
    tmp.replace(USAGE_FILE)

def _cache_age():
    try:
        d = json.loads(NEWS_CACHE_FILE.read_text(encoding="utf-8"))
        return max(0, time.time() - float(d["updated_at_epoch"]))
    except Exception:
        return float("inf")

def _read_cache():
    try:
        d = json.loads(NEWS_CACHE_FILE.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) and isinstance(d.get("items"), list) and d.get("updated_at_epoch") else None
    except Exception:
        return None

def _strip_html(value):
    value = unescape(value or "")
    value = re.sub(r"<[^>]+>", " ", value)
    return re.sub(r"\s+", " ", value).strip()

def _domain(url):
    try: return urlparse(url).netloc.lower().removeprefix("www.")
    except Exception: return ""

def _save_collector_status(statuses):
    try:
        payload = {"updated_at_epoch": time.time(), "statuses": statuses}
        tmp = COLLECTOR_STATUS_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        tmp.replace(COLLECTOR_STATUS_FILE)
    except Exception:
        pass


def _load_collector_status():
    try:
        d = json.loads(COLLECTOR_STATUS_FILE.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) and isinstance(d.get("statuses"), list) else {"updated_at_epoch": 0, "statuses": []}
    except Exception:
        return {"updated_at_epoch": 0, "statuses": []}


def _fetch_feed(name, url, tier):
    """Fetch RSS/Atom/RDF without allowing one malformed feed to break collection.

    feedparser is intentionally used here instead of ElementTree because several
    public feeds are imperfect XML (or RDF) and may contain recoverable entries.
    """
    headers = {
        "User-Agent": "InvestAI/4.3 (news reader; public-source collector)",
        "Accept": "application/rss+xml, application/atom+xml, application/rdf+xml, application/xml, text/xml;q=0.9, */*;q=0.1",
        "Accept-Language": "en-US,en;q=0.8,es;q=0.7",
        "Cache-Control": "no-cache",
    }
    last_error = None
    for attempt in range(2):
        try:
            req = Request(url, headers=headers)
            with urlopen(req, timeout=FETCH_TIMEOUT_SECONDS) as r:
                raw = r.read(800_000)
            parsed = feedparser.parse(raw)
            entries = getattr(parsed, "entries", []) or []
            items = []
            for entry in entries[:MAX_ITEMS_PER_FEED]:
                title = _strip_html(entry.get("title", ""))
                link = entry.get("link", "") or ""
                if not link and entry.get("links"):
                    for candidate in entry.get("links", []):
                        if candidate.get("href"):
                            link = candidate["href"]
                            break
                desc = _strip_html(entry.get("summary", entry.get("description", "")))
                date = entry.get("published", "") or entry.get("updated", "") or entry.get("created", "") or ""
                if title and link:
                    items.append({
                        "title": title,
                        "snippet": desc[:500],
                        "source": name,
                        "source_tier": tier,
                        "date": date,
                        "url": link,
                        "domain": _domain(link),
                    })

            # HTTP success + no entries is a warning, not a successful source.
            if not items:
                bozo = getattr(parsed, "bozo", False)
                bozo_exc = getattr(parsed, "bozo_exception", None)
                reason = "feed sin elementos"
                if bozo and bozo_exc:
                    reason += f"; parser: {bozo_exc}"
                return [], {"status": "warning", "items": 0, "reason": reason}

            # A malformed feed can still be useful if feedparser recovered entries.
            if getattr(parsed, "bozo", False):
                bozo_exc = getattr(parsed, "bozo_exception", None)
                return items, {"status": "warning", "items": len(items), "reason": f"feed recuperado con advertencia: {bozo_exc}"}

            return items, {"status": "ok", "items": len(items)}
        except Exception as exc:
            last_error = exc
            if attempt == 0:
                time.sleep(0.4)
    return [], {"status": "error", "items": 0, "error": f"{name}: {last_error}"}


def _collect_news():
    all_items, errors, statuses = [], [], []
    for name, url, tier in FEEDS:
        items, result = _fetch_feed(name, url, tier)
        all_items.extend(items)
        status = {"source": name, **result}
        statuses.append(status)
        if result.get("status") == "error":
            errors.append(result.get("error", f"{name}: error desconocido"))
    _save_collector_status(statuses)
    seen, unique = set(), []
    per_source = {}
    # Diversificamos el contexto antes de enviarlo a Gemini. El orden bruto de
    # los RSS puede dejar 12 noticias de SEC delante de todo lo demás y hacer
    # que el modelo ignore Reuters/AP/CNBC/MarketWatch y Europa.
    for item in all_items:
        key = item["url"].split("#")[0] or (item["source"], item["title"].lower())
        if key in seen:
            continue
        seen.add(key)
        src = item.get("source", "")
        per_source[src] = per_source.get(src, 0) + 1
        unique.append(item)
    # Máximo 6 por fuente en el contexto de IA; después completamos con el
    # resto más reciente. Esto mejora la cobertura geográfica y sectorial.
    balanced = []
    counts = {}
    for item in sorted(unique, key=lambda x: x.get("date", ""), reverse=True):
        src = item.get("source", "")
        if counts.get(src, 0) >= 6:
            continue
        balanced.append(item)
        counts[src] = counts.get(src, 0) + 1
        if len(balanced) >= MAX_ITEMS_FOR_GEMINI:
            break
    return balanced, errors, statuses

def _news_prompt(items):
    compact = []
    for item in items[:MAX_ITEMS_FOR_GEMINI]:
        compact.append({
            "title": item.get("title", ""),
            "snippet": (item.get("snippet", "") or "")[:500],
            "source": item.get("source", ""),
            "date": item.get("date", ""),
            "url": item.get("url", ""),
        })
    by_source = {}
    for row in compact:
        src = row.get("source", "") or "Desconocido"
        by_source.setdefault(src, []).append(row)
    selected = []
    for src, rows in by_source.items():
        selected.extend(rows[:3])
    selected = selected[:36]
    payload = json.dumps(selected, ensure_ascii=False)
    indexes = ", ".join(INDEXES)
    universe = ", ".join(f"{sym}={SYMBOL_TO_COMPANY[sym]}" for sym in ALL_UNIVERSE_SYMBOLS)
    return f"""Analiza EXCLUSIVAMENTE las noticias suministradas abajo. No uses conocimiento externo.
Selecciona hasta 8 noticias con impacto financiero real para estos índices: {indexes}.
Diversifica las fuentes y regiones y prioriza las últimas 48 horas, hechos oficiales, resultados, guidance, regulación, tipos, inflación, empleo, energía, materias primas y geopolítica con efecto económico.

ATRIBUCIÓN EMPRESARIAL: para cada noticia identifica solo las empresas de este universo que tengan relación razonable con el contenido. Usa EXACTAMENTE sus tickers, sin inventar ni modificar símbolos.
Universo: {universe}
- affected_companies: lista de 0 a 8 tickers exactos. Úsala solo cuando exista impacto directo o claramente identificable sobre una empresa concreta.
- affected_markets: solo nombres exactos de la lista de índices.
- Si el impacto es principalmente macro/indexial y no puede atribuirse a empresas concretas, affected_companies puede quedar vacío.

Para cada noticia devuelve:
- why: explicación sencilla de por qué importa (máximo 220 caracteres).
- reliability: Alta, Media-alta o Media.
- corroborated: true solo si el material suministrado permite ver el mismo hecho en más de una fuente; si no, false.
- affected_companies: tickers exactos del universo.
- affected_markets: nombres exactos de índices.
- sentiment: entero entre -100 y 100. Negativo = perjudicial, 0 = neutral, positivo = favorable para los afectados.
- importance: entero entre 0 y 100 según importancia potencial.

Devuelve SOLO JSON válido, sin markdown. Conserva exactamente una URL suministrada por elemento:
{{"items":[{{"url":"URL_EXACTA","why":"...","reliability":"Alta|Media-alta|Media","corroborated":false,"affected_companies":["NVDA"],"affected_markets":["S&P 500"],"sentiment":0,"importance":50}}]}}

DATOS RECOPILADOS:
{payload}"""


def _extract_json_object(text):
    """Extrae JSON cuando Gemini lo entrega bien y recupera noticias si no."""
    if not isinstance(text, str) or not text.strip():
        raise ValueError("Gemini no devolvió contenido")
    cleaned = text.strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.I)
    cleaned = re.sub(r"\s*```$", "", cleaned)

    # Gemini puede devolver un array JSON aunque se haya pedido un objeto.
    # Aceptamos ambos formatos y normalizamos a {items:[...]}.
    try:
        direct = json.loads(cleaned)
        if isinstance(direct, list):
            return {"items": direct[:8], "method": "JSON array normalizado"}
        if isinstance(direct, dict):
            return direct
    except json.JSONDecodeError:
        pass

    decoder = json.JSONDecoder()
    first = cleaned.find("{")
    if first >= 0:
        try:
            value, _ = decoder.raw_decode(cleaned[first:])
            if isinstance(value, dict):
                return value
        except json.JSONDecodeError:
            pass

    # Buscar objetos JSON completos dentro de una respuesta rota.
    objects = []
    depth = 0
    in_string = False
    escaped = False
    obj_start = None
    for i, ch in enumerate(cleaned[first if first >= 0 else 0:], start=first if first >= 0 else 0):
        if in_string:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == '"':
                in_string = False
            continue
        if ch == '"':
            in_string = True
        elif ch == '{':
            if depth == 0:
                obj_start = i
            depth += 1
        elif ch == '}':
            if depth:
                depth -= 1
                if depth == 0 and obj_start is not None:
                    try:
                        obj = json.loads(cleaned[obj_start:i+1])
                        if isinstance(obj, dict):
                            objects.append(obj)
                    except json.JSONDecodeError:
                        pass
                    obj_start = None

    recovered = []
    method = ""
    for obj in objects:
        if isinstance(obj.get("items"), list):
            recovered.extend(x for x in obj["items"] if isinstance(x, dict))
        elif obj.get("title") and obj.get("url"):
            recovered.append(obj)
        if obj.get("method") and not method:
            method = str(obj["method"])
    if recovered:
        return {"items": recovered[:8], "method": method or "Recuperación JSON parcial"}

    # Último intento: localizar URLs y títulos de la respuesta. Se validarán
    # posteriormente contra las URLs que realmente entregó el recopilador.
    urls = re.findall(r'https?://[^\s<>"\\]+', cleaned)
    loose_items = []
    for url in urls:
        url = url.rstrip('.,);]')
        pos = cleaned.find(url)
        before = cleaned[max(0, pos-350):pos]
        lines = [re.sub(r'^\s*[-*\d.)]+\s*', '', x).strip() for x in before.splitlines() if x.strip()]
        title = lines[-1] if lines else ""
        title = re.sub(r'^["\']|["\']$', '', title)
        if title and len(title) > 12:
            loose_items.append({"title": title[:300], "url": url, "source": "", "date": "", "why": "Titular relevante detectado por el motor de análisis.", "reliability": "Media", "corroborated": False, "affected_markets": []})
    if loose_items:
        return {"items": loose_items[:8], "method": "Recuperación de URLs y titulares"}
    raise ValueError("Gemini devolvió una respuesta que no pudo convertirse a noticias")

class GeminiRESTError(RuntimeError):
    def __init__(self, message, status_code=None):
        super().__init__(message)
        self.status_code = status_code


def _gemini_generate_once(model, prompt, system_instruction=None, temperature=0.2, response_mime_type=None):
    if not GEMINI_API_KEY:
        raise GeminiRESTError("GEMINI_API_KEY no configurada")
    body = {
        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
        "generationConfig": {"maxOutputTokens": 4096},
    }
    if system_instruction:
        body["systemInstruction"] = {"parts": [{"text": system_instruction}]}
    if response_mime_type == "application/json":
        # Esquema deliberadamente pequeño: reduce errores 500 de la API y deja
        # la validación de rangos/listas a nuestro backend.
        body["generationConfig"]["responseMimeType"] = "application/json"
        body["generationConfig"]["responseSchema"] = {
            "type": "OBJECT",
            "properties": {
                "items": {
                    "type": "ARRAY",
                    "items": {
                        "type": "OBJECT",
                        "properties": {
                            "url": {"type": "STRING"},
                            "why": {"type": "STRING"},
                            "reliability": {"type": "STRING"},
                            "corroborated": {"type": "BOOLEAN"},
                            "affected_markets": {"type": "ARRAY", "items": {"type": "STRING"}},
                            "sentiment": {"type": "INTEGER"},
                            "importance": {"type": "INTEGER"}
                        },
                        "required": ["url", "why", "reliability", "corroborated", "affected_markets", "sentiment", "importance"]
                    }
                }
            },
            "required": ["items"]
        }
    elif response_mime_type:
        body["generationConfig"]["responseMimeType"] = response_mime_type
    if model.startswith("gemini-3"):
        body["generationConfig"]["thinkingConfig"] = {
            "thinkingLevel": "minimal" if model == "gemini-3.5-flash-lite" else "low"
        }
    data = json.dumps(body, ensure_ascii=False).encode("utf-8")
    req = Request(
        GEMINI_API_URL.format(model=quote(model, safe="")),
        data=data,
        headers={"Content-Type":"application/json", "x-goog-api-key":GEMINI_API_KEY, "User-Agent":"InvestAI/5.6.2"},
        method="POST",
    )
    try:
        with urlopen(req, timeout=GEMINI_HTTP_TIMEOUT_SECONDS) as r:
            raw = r.read(2_000_000)
        payload = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        status = getattr(exc, "code", None)
        detail = getattr(exc, "read", lambda: b"")()
        detail_text = ""
        if detail:
            try: detail_text = detail.decode("utf-8", errors="replace")
            except Exception: detail_text = str(detail)
        raise GeminiRESTError(f"Gemini REST ({status or 'HTTP'}): {detail_text[:2500] or exc}", status) from exc
    parts=[]
    for candidate in payload.get("candidates", []) or []:
        for part in (candidate.get("content") or {}).get("parts", []) or []:
            if isinstance(part, dict) and isinstance(part.get("text"), str) and part.get("text").strip():
                parts.append(part["text"])
        # Si Gemini termina sin texto, conserva la razón exacta para diagnóstico.
        if not parts and candidate.get("finishReason"):
            raise GeminiRESTError(f"Gemini REST ({model}): sin texto; finishReason={candidate.get("finishReason")}")
    text="\n".join(parts).strip()
    if not text:
        raise GeminiRESTError(f"Gemini REST ({model}): respuesta sin texto")
    return text

def _gemini_generate(prompt, system_instruction=None, temperature=0.2, response_mime_type=None):
    """Gemini REST con reintentos conservadores y fallback automático.

    - Primario: GEMINI_MODEL (por defecto gemini-3.5-flash-lite).
    - Fallback: GEMINI_FALLBACK_MODEL (por defecto gemini-3.8-flash).
    - 503/408/504/timeout: backoff conservador y después fallback.
    - 429 de cuota/rate limit: no se insiste innecesariamente en el mismo modelo; se pasa directamente al fallback.
    - 401/402/403: se propagan sin ocultarlos.
    """
    models = [(GEMINI_MODEL, max(1, GEMINI_PRIMARY_RETRIES))]
    if GEMINI_FALLBACK_MODEL and GEMINI_FALLBACK_MODEL != GEMINI_MODEL:
        models.append((GEMINI_FALLBACK_MODEL, max(1, GEMINI_FALLBACK_RETRIES)))

    last_exc = None
    for model_index, (model, attempts) in enumerate(models):
        for attempt in range(attempts):
            try:
                text = _gemini_generate_once(model, prompt, system_instruction, temperature, response_mime_type)
                return text, model
            except GeminiRESTError as exc:
                last_exc = exc
                # 503 = capacidad temporalmente no disponible: reintentamos
                # con backoff antes de pasar al siguiente modelo.
                if exc.status_code in (500, 502, 503, 408, 504) or exc.status_code is None:
                    if attempt < attempts - 1:
                        delay = 2 * (2 ** attempt) + (0.5 * attempt)
                        time.sleep(delay)
                    continue

                # 429 = cuota/rate limit. Reintentar el mismo modelo puede
                # consumir tiempo sin cambiar el estado de la cuota, así que
                # pasamos directamente al fallback si existe.
                if exc.status_code == 429:
                    break

                # 401/402/403 u otros errores de configuración no deben
                # ocultarse haciendo llamadas adicionales a otro modelo.
                raise
        if model_index == 0 and len(models) > 1:
            continue
    raise last_exc or GeminiRESTError("Gemini REST: error desconocido")


def _local_news_analysis(items):
    """Fallback determinista: nunca inventa hechos; solo puntúa el titular suministrado."""
    positive = ("beat", "beats", "raises", "raise", "growth", "profit", "profits", "record", "upgrade", "recovery", "falls in unemployment", "rate cut", "lower rates", "strong")
    negative = ("fraud", "defraud", "fraudulent", "charges", "charge", "worst", "fall", "falls", "drop", "drops", "cut", "cuts", "downgrade", "loss", "losses", "inflation", "war", "default", "warning")
    out=[]
    for i in items[:8]:
        title=(i.get("title") or "").lower()
        score=0
        for w in positive:
            if w in title: score += 12
        for w in negative:
            if w in title: score -= 12
        score=max(-100,min(100,score))
        importance=45
        if i.get("source_tier") in ("official","official_discovery"): importance += 15
        if any(w in title for w in ("rate", "inflation", "employment", "stress test", "regulation", "fraud")): importance += 15
        out.append({
            "title":i.get("title",""),"source":i.get("source",""),"date":i.get("date",""),"url":i.get("url",""),
            "why":"Análisis automático del titular; no sustituye el análisis IA.",
            "reliability":"Alta" if i.get("source_tier") in ("official","official_discovery") else "Media",
            "corroborated":False,"affected_markets":[],"sentiment":score,"importance":min(100,importance)
        })
    return {"items":out,"method":"Análisis automático del titular (fallback sin IA)"}

def _refresh_news(reason="scheduled"):
    global _last_refresh_started
    if not GEMINI_API_KEY: return False, "GEMINI_API_KEY no configurada"
    now = time.time()
    with _lock:
        cache_age = _cache_age(); has_valid_cache = cache_age != float("inf") and _read_cache() is not None
        if has_valid_cache and now - _last_refresh_started < 540: return False, "refresh en cooldown"
        u = _load_usage()
        if u.get("refreshes", 0) >= MAX_REFRESHES_PER_DAY: return False, "límite diario de actualizaciones alcanzado"
        if u.get("gemini_calls", 0) >= MAX_GEMINI_CALLS_PER_DAY: return False, "límite diario de llamadas Gemini alcanzado"
        _last_refresh_started = now
    collected, errors, statuses = _collect_news()
    if not collected:
        detail = "; ".join(errors[:5]) if errors else "ninguna fuente devolvió elementos"
        return False, "No se pudieron recopilar noticias utilizables: " + detail
    ai_error = None
    used_model = None
    ai_status = "ok"
    try:
        text, used_model = _gemini_generate(
            _news_prompt(collected),
            system_instruction=SYSTEM + "\nDevuelve únicamente JSON válido, sin markdown.",
            temperature=0.2,
            response_mime_type="application/json",
        )
        data = _extract_json_object(text)
        if not isinstance(data, dict) or not isinstance(data.get("items"), list) or not data.get("items"):
            raise ValueError("Gemini devolvió JSON sin noticias utilizables")
    except Exception as exc:
        # Garantía de servicio: las noticias no dependen de que Gemini produzca
        # JSON perfecto. Si Gemini falla, publicamos directamente los titulares
        # verificados por el recopilador y dejamos constancia del estado de IA.
        ai_error = str(exc)
        ai_status = "fallback_colector"
        used_model = None
        data = _local_news_analysis(collected)

    # Solo permitimos URLs que realmente procedan del recopilador.
    source_by_url = {i["url"]: i for i in collected}
    clean = []
    for item in data.get("items", []):
        if not isinstance(item, dict) or item.get("url") not in source_by_url:
            continue
        original = source_by_url[item["url"]]
        # La URL es la identidad de la noticia. El título, fuente y fecha se
        # toman SIEMPRE del recopilador para impedir que una respuesta JSON
        # parcialmente rota de Gemini contamine la noticia con fragmentos de
        # JSON, texto truncado o datos inventados. Gemini solo puede aportar
        # el contexto analítico.
        safe = {
            "title": original.get("title", ""),
            "source": original.get("source", ""),
            "date": original.get("date", ""),
            "url": original.get("url", ""),
            "why": "Titular recopilado de una fuente pública.",
            "reliability": "Alta" if original.get("source_tier") in ("official", "official_discovery") else "Media",
            "corroborated": False,
            "affected_companies": [],
            "affected_markets": [],
        }
        why = item.get("why")
        if isinstance(why, str) and 20 <= len(why.strip()) <= 300 and '"items"' not in why and not why.lstrip().startswith("{"):
            safe["why"] = why.strip()
        reliability = item.get("reliability")
        if reliability in ("Alta", "Media-alta", "Media"):
            safe["reliability"] = reliability
        safe["corroborated"] = bool(item.get("corroborated", False))
        try:
            safe["sentiment"] = max(-100, min(100, int(item.get("sentiment", 0))))
        except (TypeError, ValueError):
            safe["sentiment"] = 0
        try:
            safe["importance"] = max(0, min(100, int(item.get("importance", 50))))
        except (TypeError, ValueError):
            safe["importance"] = 50
        companies = item.get("affected_companies")
        if isinstance(companies, list):
            safe["affected_companies"] = [str(x).upper() for x in companies if str(x).upper() in SYMBOL_TO_COMPANY][:8]
        markets = item.get("affected_markets")
        if isinstance(markets, list):
            safe["affected_markets"] = [str(m) for m in markets if str(m) in INDEXES][:8]
        clean.append(safe)
    data["items"] = clean[:8]
    if not data["items"]:
        # Si Gemini devolvió JSON pero descartó todas las URLs, también se usa
        # el fallback del recopilador para que el endpoint nunca quede vacío.
        data["items"] = [
            {
                "title": i.get("title", ""), "source": i.get("source", ""),
                "date": i.get("date", ""), "url": i.get("url", ""),
                "why": "Titular recopilado de una fuente pública; análisis IA no disponible para esta noticia.",
                "reliability": "Alta" if i.get("source_tier") in ("official", "official_discovery") else "Media",
                "corroborated": False, "affected_companies": [], "affected_markets": [], "sentiment": 0, "importance": 40
            } for i in collected[:8]
        ]
        ai_status = "fallback_colector"

    data.update({
        "updated_at": _now().astimezone().strftime("%d/%m/%Y %H:%M"),
        "updated_at_epoch": time.time(),
        "provider": "Fuentes públicas + Gemini",
        "model": used_model,
        "requested_model": GEMINI_MODEL,
        "fallback_model": GEMINI_FALLBACK_MODEL,
        "ai_status": ai_status,
        "ai_error": ai_error[:1000] if ai_error else None,
        "refresh_reason": reason,
        "collector_errors": errors[:8],
        "collector_status": statuses,
    })
    with _lock:
        u = _load_usage()
        if used_model:
            u["gemini_calls"] = u.get("gemini_calls", 0) + 1
        u["refreshes"] = u.get("refreshes", 0) + 1
        _save_usage(u)
        data["usage"] = {"gemini_calls_today": u["gemini_calls"], "refreshes_today": u["refreshes"], "daily_refresh_limit": MAX_REFRESHES_PER_DAY, "daily_gemini_limit": MAX_GEMINI_CALLS_PER_DAY}
        tmp = NEWS_CACHE_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        tmp.replace(NEWS_CACHE_FILE)
    return True, "actualizado"

def _background_loop():
    last_market=0.0
    while True:
        try:
            if _cache_age() >= REFRESH_INTERVAL_SECONDS: _refresh_news("scheduled")
            if time.time()-last_market >= MARKET_REFRESH_SECONDS:
                _refresh_market_symbols(_all_market_symbols())
                last_market=time.time()
        except Exception:
            pass
        time.sleep(30)

def _stooq_symbol(symbol):
    # Stooq uses lower-case tickers with exchange suffixes. It is used only as
    # a free fallback when Yahoo throttles the Render IP.
    s=symbol.lower()
    suffix_map={".mc":".es",".pa":".fr",".de":".de",".sw":".ch",".l":".uk",".t":".jp",".hk":".hk",".ax":".au"}
    for y,st in suffix_map.items():
        if s.endswith(y): return s[:-len(y)] + st
    return s + ".us"

def _fetch_yahoo(symbol):
    period1=int(time.time())-400*86400; period2=int(time.time())
    url=f"https://query1.finance.yahoo.com/v8/finance/chart/{quote(symbol,safe='')}?period1={period1}&period2={period2}&interval=1d&events=history&includeAdjustedClose=true"
    req=Request(url,headers={"User-Agent":"Mozilla/5.0 InvestAI/5.2","Accept":"application/json"})
    with urlopen(req,timeout=MARKET_YAHOO_TIMEOUT_SECONDS) as r: payload=json.loads(r.read(2_000_000).decode("utf-8"))
    result=((payload.get("chart") or {}).get("result") or [None])[0]
    if not result: raise RuntimeError("Yahoo sin datos")
    ts=result.get("timestamp") or []; q=result.get("indicators",{}).get("quote",[{}])[0]; closes=q.get("close") or []
    rows=[{"timestamp":int(t),"close":float(c)} for t,c in zip(ts,closes) if c is not None]
    if len(rows)<MARKET_DATA_MIN_DAYS: raise RuntimeError(f"Yahoo solo devuelve {len(rows)} sesiones")
    return rows

def _fetch_stooq(symbol):
    period1=datetime.fromtimestamp(int(time.time())-400*86400,tz=timezone.utc).strftime("%Y%m%d")
    period2=datetime.now(timezone.utc).strftime("%Y%m%d")
    ss=_stooq_symbol(symbol)
    url=f"https://stooq.com/q/d/l/?s={quote(ss,safe='')}&i=d&d1={period1}&d2={period2}"
    req=Request(url,headers={"User-Agent":"Mozilla/5.0 InvestAI/5.2","Accept":"text/csv"})
    with urlopen(req,timeout=MARKET_STOOQ_TIMEOUT_SECONDS) as r: raw=r.read(4_000_000).decode("utf-8-sig",errors="replace")
    lines=[x.strip() for x in raw.splitlines() if x.strip()]
    if len(lines)<2: raise RuntimeError("Stooq sin datos")
    rows=[]
    for line in lines[1:]:
        cols=[x.strip() for x in line.split(',')]
        if len(cols)>=5:
            try:
                ts=int(datetime.strptime(cols[0],"%Y-%m-%d").replace(tzinfo=timezone.utc).timestamp())
                rows.append({"timestamp":ts,"close":float(cols[4])})
            except (ValueError,TypeError):
                continue
    if len(rows)<MARKET_DATA_MIN_DAYS: raise RuntimeError(f"Stooq solo devuelve {len(rows)} sesiones")
    return rows

def _fetch_price_history(symbol):
    # Provider chain: Yahoo first, Stooq on throttling/temporary failure.
    # The result is cached so the app never depends on a fresh request per screen.
    last_error=None
    try:
        rows=_fetch_yahoo(symbol)
        MARKET_REFRESH_STATE["provider_used"][symbol]="yahoo_chart_public"
        return rows, "yahoo_chart_public", False
    except Exception as exc:
        last_error=exc
        if "429" in str(exc): MARKET_REFRESH_STATE["last_429"] += 1
    try:
        if MARKET_RETRY_SECONDS > 0:
            time.sleep(MARKET_RETRY_SECONDS)
        rows=_fetch_stooq(symbol)
        MARKET_REFRESH_STATE["provider_used"][symbol]="stooq_public_fallback"
        return rows, "stooq_public_fallback", True
    except Exception as exc:
        last_error=exc
        raise RuntimeError(f"Yahoo/Stooq sin datos: {last_error}")

def _load_market_cache():
    try:
        if not MARKET_CACHE_FILE.exists(): return {}
        data=json.loads(MARKET_CACHE_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data,dict) else {}
    except Exception:
        return {}

def _save_market_cache(data):
    tmp=MARKET_CACHE_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data,ensure_ascii=False),encoding="utf-8")
    tmp.replace(MARKET_CACHE_FILE)

def _parse_news_epoch(value):
    if not value: return None
    try:
        txt=str(value).strip()
        if txt.endswith("Z"): txt=txt[:-1] + "+00:00"
        dt=datetime.fromisoformat(txt)
        if dt.tzinfo is None: dt=dt.replace(tzinfo=timezone.utc)
        return dt.timestamp()
    except Exception:
        # Common RSS date format.
        for fmt in ("%a, %d %b %Y %H:%M:%S %Z", "%a, %d %b %Y %H:%M:%S %z"):
            try: return datetime.strptime(str(value),fmt).timestamp()
            except Exception: pass
    return None

def _news_reliability_factor(value):
    return {"Alta":1.0,"Media-alta":0.9,"Media":0.75}.get(value,0.7)

def _local_news_attribution(item):
    """Fallback attribution when Gemini cannot identify exact companies."""
    text=(str(item.get("title","") )+" "+str(item.get("snippet","") )).lower()
    direct=[]
    for symbol,name in SYMBOL_TO_COMPANY.items():
        if symbol.lower() in text or name.lower() in text:
            direct.append(symbol)
    markets=[]
    for idx in INDEXES:
        if idx.lower() in text: markets.append(idx)
    # Never infer a company from an unrelated ticker-like substring.
    return direct[:8], markets[:8]

def _news_scores_by_company(index_name=None):
    cached=_read_cache()
    if not cached: return {}
    now=time.time(); result={}
    for item in cached.get("items",[]):
        try: sentiment=max(-100,min(100,float(item.get("sentiment",0))))
        except Exception: sentiment=0.0
        try: importance=max(0,min(100,float(item.get("importance",50))))
        except Exception: importance=50.0
        age_hours=0.0
        ts=_parse_news_epoch(item.get("date"))
        if ts:
            age_hours=max(0.0,(now-ts)/3600.0)
        recency=0.5 ** (age_hours/48.0) if age_hours>0 else 1.0
        reliability=_news_reliability_factor(item.get("reliability"))
        corroboration=1.08 if item.get("corroborated") else 1.0
        companies=item.get("affected_companies") if isinstance(item.get("affected_companies"),list) else []
        companies=[str(x).upper() for x in companies if str(x).upper() in SYMBOL_TO_COMPANY]
        markets=item.get("affected_markets") if isinstance(item.get("affected_markets"),list) else []
        if not companies:
            local_companies, local_markets=_local_news_attribution(item)
            companies=local_companies
            if not markets: markets=local_markets
        for sym in set(companies):
            relation=1.0
            weight=max(0.01,importance/100.0)*recency*reliability*corroboration*relation
            result.setdefault(sym,[]).append((sentiment,weight,"direct"))
        # Index/macro transmission is deliberately weaker than direct company news.
        for market in set(markets):
            for sym in SYMBOL_TO_COMPANY:
                if market in SYMBOL_TO_INDEXES.get(sym,[]):
                    relation=0.40
                    weight=max(0.01,importance/100.0)*recency*reliability*corroboration*relation
                    result.setdefault(sym,[]).append((sentiment,weight,"index"))
    out={}
    for sym, rows in result.items():
        total=sum(w for _,w,_ in rows)
        if total<=0: continue
        weighted=sum(sent*w for sent,w,_ in rows)/total
        # Keep direct evidence more important when both direct and index evidence exist.
        direct=sum(w for _,w,kind in rows if kind=="direct")
        coverage=min(100, round(100*(1.0 if direct>0 else min(0.75,total/1.5))))
        score=_score_band(50 + weighted/2)
        out[sym]={"score":score,"coverage_pct":coverage,"articles_used":len(rows),"weighted_sentiment":round(weighted,1),"direct_articles":sum(1 for _,_,k in rows if k=="direct")}
    return out

def _snapshot_from_rows(index_name,name,symbol,rows,provider,stale=False):
    closes=[x["close"] for x in rows]
    last=closes[-1]; prev=closes[-2] if len(closes)>1 else last
    technical=_technical_score(closes); risk=_risk_score(closes)
    fundamental=_fundamental_market_score(index_name,name,symbol,last)
    news_all=_news_scores_by_company(index_name)
    news=news_all.get(symbol,{})
    parts={"valuation":fundamental["scores"].get("valuation"),"growth":fundamental["scores"].get("growth"),
           "financial_health":fundamental["scores"].get("financial_health"),"technical":technical,"risk":risk,
           "news_sentiment":news.get("score")}
    score,coverage,available=_weighted_score(parts)
    status="completa" if coverage>=85 else ("provisional: todavía faltan algunos datos" if coverage>=60 else "insuficiente: faltan datos para una recomendación")
    recommendation=None
    if score is not None and coverage>=60:
        recommendation="interés alto" if score>=75 else ("interés medio" if score>=60 else ("vigilar" if score>=45 else "interés bajo"))
    out={"name":name,"symbol":symbol,"index":index_name,"price":round(last,4),"change_1d_pct":round((last/prev-1)*100,3) if prev else None,
         "technical_score":technical,"risk_score":risk,"opportunity_score":score,"score_weight_coverage_pct":coverage,
         "score_components_available":available,"score_status":status,"recommendation":recommendation,"data_points":len(rows),
         "news_score":news.get("score"),"news_coverage_pct":news.get("coverage_pct",0),"news_articles_used":news.get("articles_used",0),
         "news_direct_articles":news.get("direct_articles",0),"news_weighted_sentiment":news.get("weighted_sentiment"),
         "as_of_epoch":rows[-1]["timestamp"],"provider":provider,"stale":bool(stale)}
    if fundamental.get("fundamentals"):
        f=fundamental["fundamentals"]
        out["fundamental_scores"]=f.get("scores",{}); out["fundamental_metrics"]=f.get("metrics",{});
        out["fundamental_source"]=f.get("source"); out["fundamental_quality"]=f.get("data_quality")
    return out

def _fetch_one_market_symbol(pair):
    name, symbol = pair
    try:
        rows, provider, fallback = _fetch_price_history(symbol)
        return symbol, {"rows": rows, "provider": provider, "updated_at_epoch": time.time()}, None
    except Exception as exc:
        return symbol, None, str(exc)[:500]

def _refresh_market_symbols(symbols):
    if not MARKET_REFRESH_LOCK.acquire(blocking=False):
        return {"refreshed":0,"failed":0,"skipped":len(symbols),"reason":"actualización ya en curso"}
    started=time.time(); work=list(symbols[:MARKET_MAX_SYMBOLS_PER_REFRESH])
    MARKET_REFRESH_STATE.update({"last_started":started,"last_finished":0.0,"last_success":0,"last_failed":0,"last_429":0,"provider_used":{},"last_error":None,"in_progress":True,"completed":0,"total":len(work)})
    cache=_load_market_cache(); ok=failed=0
    try:
        with ThreadPoolExecutor(max_workers=max(1,min(MARKET_WORKERS,len(work) or 1)),thread_name_prefix="market-fetch") as pool:
            futures=[pool.submit(_fetch_one_market_symbol,pair) for pair in work]
            for fut in as_completed(futures):
                symbol,entry,error=fut.result()
                if entry is not None:
                    cache[symbol]=entry; ok+=1; MARKET_REFRESH_STATE["provider_used"][symbol]=entry["provider"]
                else:
                    failed+=1
                    if error and "429" in error: MARKET_REFRESH_STATE["last_429"]+=1
                    MARKET_REFRESH_STATE["last_error"]=error
                MARKET_REFRESH_STATE["completed"]=ok+failed; MARKET_REFRESH_STATE["last_success"]=ok; MARKET_REFRESH_STATE["last_failed"]=failed
                try:
                    with MARKET_CACHE_WRITE_LOCK: _save_market_cache(cache)
                except Exception as exc: MARKET_REFRESH_STATE["last_error"]=f"cache write: {exc}"
    except Exception as exc:
        MARKET_REFRESH_STATE["last_error"]=str(exc)[:500]
    finally:
        MARKET_REFRESH_STATE["last_success"]=ok; MARKET_REFRESH_STATE["last_failed"]=failed; MARKET_REFRESH_STATE["last_finished"]=time.time(); MARKET_REFRESH_STATE["in_progress"]=False; MARKET_REFRESH_LOCK.release()
    return {"refreshed":ok,"failed":failed,"duration_seconds":round(time.time()-started,1)}

def _market_snapshot_cached(index_name,name,symbol,allow_refresh=True):
    cache=_load_market_cache(); entry=cache.get(symbol) if isinstance(cache,dict) else None
    now=time.time()
    if isinstance(entry,dict) and isinstance(entry.get("rows"),list) and entry.get("rows"):
        age=now-float(entry.get("updated_at_epoch",0)); stale=age>MARKET_CACHE_MAX_AGE_SECONDS
        return _snapshot_from_rows(index_name,name,symbol,entry["rows"],entry.get("provider","cache"),stale=stale)
    if not allow_refresh: raise RuntimeError("sin datos en caché")
    rows,provider,_fallback=_fetch_price_history(symbol)
    cache[symbol]={"rows":rows,"provider":provider,"updated_at_epoch":now}; _save_market_cache(cache)
    return _snapshot_from_rows(index_name,name,symbol,rows,provider,stale=False)

def _all_market_symbols():
    symbols=[]
    seen=set()
    for companies in COMPANY_UNIVERSE.values():
        for pair in companies:
            if pair[1] not in seen:
                symbols.append(pair)
                seen.add(pair[1])
    return symbols

def _ensure_market_refresh_started():
    cache=_load_market_cache()
    if len(cache)>=len(_all_market_symbols()): return False
    if MARKET_REFRESH_STATE.get("in_progress") or MARKET_REFRESH_LOCK.locked(): return False
    def runner():
        try: _refresh_market_symbols(_all_market_symbols())
        except Exception as exc: MARKET_REFRESH_STATE["last_error"]=str(exc)[:500]; MARKET_REFRESH_STATE["in_progress"]=False
    threading.Thread(target=runner,daemon=True,name="investai-market-cold-start").start(); return True

def _company_market_snapshot(index_name,name,symbol):
    return _market_snapshot_cached(index_name,name,symbol,allow_refresh=True)

@app.get("/market/universe")
def market_universe(index: str | None = None):
    if index and index not in COMPANY_UNIVERSE: raise HTTPException(404,"Índice no encontrado")
    selected={index:COMPANY_UNIVERSE[index]} if index else COMPANY_UNIVERSE
    return {"indices":{k:[{"name":n,"symbol":s} for n,s in v] for k,v in selected.items()},"score_weights":SCORE_WEIGHTS,"status":"universo inicial de análisis; no es una recomendación automática"}

@app.get("/market/company")
def market_company(symbol: str, index: str = ""):
    found=None
    for idx,companies in COMPANY_UNIVERSE.items():
        for n,s in companies:
            if s.upper()==symbol.upper(): found=(idx,n,s); break
        if found: break
    if not found: raise HTTPException(404,"Símbolo no incluido en el universo inicial")
    try:
        snap=_company_market_snapshot(found[0],found[1],found[2])
        return {**snap,**_market_provider_status()}
    except Exception as exc:
        raise HTTPException(502,f"No se pudieron obtener datos de mercado para {symbol}: {exc}")

@app.get("/market/index")
def market_index(index: str):
    if index not in COMPANY_UNIVERSE: raise HTTPException(404,"Índice no encontrado")
    _ensure_market_refresh_started(); _ensure_fundamentals_refresh_started(); results=[]; errors=[]; cache=_load_market_cache(); now=time.time()
    for name,symbol in COMPANY_UNIVERSE[index]:
        try: results.append(_market_snapshot_cached(index,name,symbol,allow_refresh=False))
        except Exception as exc: errors.append({"name":name,"symbol":symbol,"error":str(exc)})
    ranked=sorted(results,key=lambda x:(x.get("opportunity_score") is not None,x.get("opportunity_score") or -1),reverse=True)
    ages=[float(v.get("updated_at_epoch",0)) for v in cache.values() if isinstance(v,dict) and v.get("updated_at_epoch")]
    return {"index":index,"companies":ranked,"errors":errors,"score_weights":SCORE_WEIGHTS,"provider":"cache + Yahoo/Stooq fallback","refresh_in_progress":bool(MARKET_REFRESH_STATE.get("in_progress")),"refresh_completed":MARKET_REFRESH_STATE.get("completed",0),"refresh_total":MARKET_REFRESH_STATE.get("total",0),"cache_age_seconds":None if not ages else round(max(0,now-min(ages)),1),"note":"La puntuación combina datos de mercado y, cuando están disponibles, fundamentales públicos. Revisiones y noticias se incorporarán después; la cobertura indica cuánto del modelo está realmente calculado."}

@app.get("/market/health")
def market_health():
    cache=_load_market_cache()
    if not cache and not MARKET_REFRESH_LOCK.locked():
        _ensure_market_refresh_started()
        cache=_load_market_cache()
    now=time.time(); fresh=sum(1 for v in cache.values() if isinstance(v,dict) and now-float(v.get("updated_at_epoch",0))<=MARKET_CACHE_MAX_AGE_SECONDS)
    stale=sum(1 for v in cache.values() if isinstance(v,dict) and now-float(v.get("updated_at_epoch",0))>MARKET_CACHE_MAX_AGE_SECONDS)
    return {"status":"ok","provider":"cache + Yahoo/Stooq fallback","indices":len(COMPANY_UNIVERSE),"companies":sum(len(v) for v in COMPANY_UNIVERSE.values()),"cached_companies":len(cache),"fresh_companies":fresh,"stale_companies":stale,"market_refresh_seconds":MARKET_REFRESH_SECONDS,"cache_max_age_seconds":MARKET_CACHE_MAX_AGE_SECONDS,"request_delay_seconds":MARKET_REQUEST_DELAY_SECONDS,"market_workers":MARKET_WORKERS,"yahoo_timeout_seconds":MARKET_YAHOO_TIMEOUT_SECONDS,"stooq_timeout_seconds":MARKET_STOOQ_TIMEOUT_SECONDS,"refresh_in_progress":bool(MARKET_REFRESH_STATE.get("in_progress")),"refresh_completed":MARKET_REFRESH_STATE.get("completed",0),"refresh_total":MARKET_REFRESH_STATE.get("total",0),"last_error":MARKET_REFRESH_STATE.get("last_error"),"last_refresh_started":MARKET_REFRESH_STATE.get("last_started"),"last_refresh_finished":MARKET_REFRESH_STATE.get("last_finished"),"last_refresh_success":MARKET_REFRESH_STATE.get("last_success",0),"last_refresh_failed":MARKET_REFRESH_STATE.get("last_failed",0),"yahoo_429_observed":MARKET_REFRESH_STATE.get("last_429",0),"provider_usage":MARKET_REFRESH_STATE.get("provider_used",{}),"score_weights":SCORE_WEIGHTS,"fundamentals_cached":len(_load_fundamentals_cache()),"fundamentals_refresh_in_progress":bool(FUNDAMENTALS_STATE.get("in_progress")),"fundamentals_refresh_completed":FUNDAMENTALS_STATE.get("completed",0),"fundamentals_refresh_total":FUNDAMENTALS_STATE.get("total",0),"fundamentals_last_error":FUNDAMENTALS_STATE.get("last_error"),"fundamentals_source_usage":FUNDAMENTALS_STATE.get("source_usage",{}),"note":"Las pantallas leen caché. Los fundamentales usan SEC CompanyFacts cuando existe y una fuente pública estructurada secundaria para el resto. La cobertura impide presentar como completa una puntuación con datos faltantes."}

@app.on_event("startup")
def startup():
    global _background_started
    if not _background_started:
        _background_started = True
        threading.Thread(target=_background_loop, daemon=True, name="investai-news-refresh").start()
        threading.Thread(target=lambda: (time.sleep(2), _ensure_market_refresh_started(), _ensure_fundamentals_refresh_started()), daemon=True, name="investai-market-bootstrap").start()

@app.get("/health")
def health():
    u = _load_usage(); age = _cache_age()
    cached = _read_cache()
    statuses = cached.get("collector_status", []) if cached else []
    if not statuses:
        statuses = _load_collector_status().get("statuses", [])
    ok_count = sum(1 for x in statuses if x.get("status") == "ok")
    failed_count = sum(1 for x in statuses if x.get("status") == "error")
    warning_count = sum(1 for x in statuses if x.get("status") == "warning")
    return {"status":"ok", "sources":len(ALL_PRIMARY_DOMAINS), "collector_sources_total":len(statuses), "provider":"Fuentes públicas + Gemini", "model":GEMINI_MODEL, "fallback_model":GEMINI_FALLBACK_MODEL, "gemini_http_timeout_seconds":GEMINI_HTTP_TIMEOUT_SECONDS, "gemini_thinking_level":"minimal (primary) / low (fallback)", "configured":bool(GEMINI_API_KEY), "news_cache_age_seconds":None if age == float("inf") else int(age), "refresh_interval_seconds":REFRESH_INTERVAL_SECONDS, "gemini_calls_today":u.get("gemini_calls",0), "daily_gemini_limit":MAX_GEMINI_CALLS_PER_DAY, "refreshes_today":u.get("refreshes",0), "daily_refresh_limit":MAX_REFRESHES_PER_DAY, "google_search_grounding":False, "collector_sources_ok":ok_count, "collector_sources_warning":warning_count, "collector_sources_failed":failed_count, "collector_source_status":statuses}

@app.get("/sources")
def sources():
    return {"primary_sources":PRIMARY_SOURCES, "count":len(ALL_PRIMARY_DOMAINS), "feeds":len(FEEDS), "collector":"Official RSS/Atom feeds + publisher discovery feeds", "policy":"Priorizar fuentes oficiales; usar Reuters/AP/CNBC/MarketWatch para contraste; cada fuente es independiente y una caída no detiene el resto; Gemini analiza solo material recopilado y conserva URLs."}

@app.get("/gemini-test")
def gemini_test():
    """Minimal authentication/model diagnostic; does not consume the news cache."""
    if not GEMINI_API_KEY:
        raise HTTPException(500, "GEMINI_API_KEY no configurada")
    try:
        text, used_model = _gemini_generate("Responde únicamente: OK", temperature=0.0)
        return {"ok": True, "model": used_model, "requested_model": GEMINI_MODEL, "fallback_model": GEMINI_FALLBACK_MODEL, "provider": "Gemini REST", "response": text}
    except Exception as exc:
        raise HTTPException(502, f"Gemini test falló: {exc}")

@app.get("/news")
def news():
    if not GEMINI_API_KEY: raise HTTPException(500, "GEMINI_API_KEY no configurada")
    cached = _read_cache(); age = _cache_age()
    if cached is None or age >= REFRESH_INTERVAL_SECONDS:
        ok, msg = _refresh_news("on_request")
        if ok: cached = _read_cache(); age = _cache_age()
        elif cached is None: raise HTTPException(502, f"No se pudieron obtener las noticias: {msg}")
    if cached is None: raise HTTPException(503, "Noticias todavía no disponibles")
    cached["cache_age_seconds"] = int(age) if age != float("inf") else None
    cached["cache_status"] = "fresh" if age < REFRESH_INTERVAL_SECONDS else "stale"
    return cached

@app.post("/news/refresh")
def manual_news_refresh():
    ok, msg = _refresh_news("manual")
    if not ok: return {"updated":False, "reason":msg, "health":health()}
    return {"updated":True, "news":_read_cache(), "health":health()}

@app.post("/chat")
def chat(body: Chat):
    if not GEMINI_API_KEY: raise HTTPException(500, "GEMINI_API_KEY no configurada")
    with _lock:
        u = _load_usage()
        if u.get("gemini_calls", 0) >= MAX_GEMINI_CALLS_PER_DAY:
            raise HTTPException(429, "Límite diario interno de Gemini alcanzado; Invest AI no hará más llamadas hoy.")
        u["gemini_calls"] = u.get("gemini_calls", 0) + 1; _save_usage(u)
    prompt = f"Contexto de cartera:\n{body.portfolio}\n\nContexto de Invest AI:\n{body.app_context}\n\nPregunta:\n{body.question}\n\nResponde usando solo el contexto proporcionado y conocimiento general; no afirmes haber consultado Internet en esta llamada."
    try:
        answer, used_model = _gemini_generate(prompt, system_instruction=SYSTEM, temperature=0.3)
        return {"answer":answer or "Gemini no devolvió contenido.", "provider":"Gemini", "model":used_model, "usage":{"gemini_calls_today":u["gemini_calls"], "daily_gemini_limit":MAX_GEMINI_CALLS_PER_DAY}}
    except Exception as exc:
        with _lock:
            u = _load_usage(); u["gemini_calls"] = max(0, u.get("gemini_calls", 1)-1); _save_usage(u)
        raise HTTPException(502, f"No se pudo consultar Gemini: {exc}")
