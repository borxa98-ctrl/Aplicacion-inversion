package com.investai.android;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.*;
import android.view.WindowInsets;
import android.widget.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.net.*;
import java.io.*;
import android.text.TextUtils;
import org.json.*;

public class MainActivity extends Activity {
    LinearLayout root, content, nav;
    TextView title, subtitle, status;
    boolean dark = false;
    String backend = "";
    final int GREEN=Color.rgb(33,180,122), YELLOW=Color.rgb(224,165,43), ORANGE=Color.rgb(232,116,65), RED=Color.rgb(218,73,78), BLUE=Color.rgb(69,105,235), PURPLE=Color.rgb(126,88,220), CYAN=Color.rgb(45,157,205);
    final String[] indices={"S&P 500","Nasdaq-100","Dow Jones","Russell 2000","EURO STOXX 50","STOXX Europe 600","DAX 40","FTSE 100","CAC 40","IBEX 35","SMI","Nikkei 225","TOPIX","Hang Seng","S&P/ASX 200"};
    final String[][] recommended={
        {"NVIDIA","Microsoft","Amazon","Meta","Alphabet","Broadcom","Apple","Eli Lilly","JPMorgan","Exxon Mobil"},
        {"NVIDIA","Microsoft","Amazon","Meta","Broadcom","Alphabet","Apple","Tesla","Netflix","Costco"},
        {"Microsoft","Apple","JPMorgan","Visa","Coca-Cola","Amazon","Walmart","Goldman Sachs","American Express","McDonald's"},
        {"AppLovin","Rocket Lab","Cava Group","Sprouts Farmers Market","Vertiv","Comfort Systems USA","Fabrinet","Abercrombie & Fitch","Wingstop","Duolingo"},
        {"ASML","SAP","LVMH","Siemens","Schneider Electric","Airbus","Allianz","TotalEnergies","Sanofi","Deutsche Telekom"},
        {"ASML","SAP","Schneider Electric","Siemens","Airbus","Roche","Novartis","Allianz","LVMH","ABB"},
        {"SAP","Siemens","Allianz","Airbus","Munich Re","Rheinmetall","Deutsche Telekom","Infineon","Mercedes-Benz","BASF"},
        {"AstraZeneca","Shell","HSBC","Unilever","Rolls-Royce","BP","RELX","BAE Systems","GSK","National Grid"},
        {"LVMH","Schneider Electric","Airbus","Safran","L'Oreal","Hermes","Vinci","Air Liquide","AXA","TotalEnergies"},
        {"Inditex","Iberdrola","Santander","BBVA","Amadeus IT","Aena","Ferrovial","Cellnex Telecom","CaixaBank","ACS"},
        {"Nestle","Novartis","Roche","UBS","ABB","Zurich Insurance","Richemont","Sika","Holcim","Swiss Re"},
        {"Toyota","Sony","Mitsubishi UFJ","Hitachi","Tokyo Electron","Keyence","Nintendo","Fast Retailing","Mitsubishi Heavy Industries","Recruit Holdings"},
        {"Toyota","Sony","Tokyo Electron","Mitsubishi UFJ","Hitachi","Keyence","Nintendo","Fast Retailing","Advantest","SoftBank Group"},
        {"Tencent","Alibaba","Meituan","HSBC","China Mobile","AIA Group","Xiaomi","JD.com","CNOOC","Lenovo"},
        {"BHP","Commonwealth Bank","CSL","Westpac","ANZ Group","Macquarie Group","Woodside Energy","Wesfarmers","Goodman Group","Transurban"}
    };

    final Map<String,Bitmap> logoCache=new ConcurrentHashMap<>();
    final Set<String> logoLoading=Collections.synchronizedSet(new HashSet<>());

    @Override public void onCreate(Bundle b){super.onCreate(b); dark=getPreferences(0).getBoolean("dark",true); backend=getPreferences(0).getString("backend",""); safeStart();}
    void safeStart(){try{build();showHome();}catch(Throwable e){fallback(e);}}
    void fallback(Throwable e){LinearLayout f=new LinearLayout(this);f.setOrientation(LinearLayout.VERTICAL);f.setPadding(dp(28),dp(36),dp(28),dp(24));f.setBackgroundColor(bg());TextView h=txt("Invest AI",30,fg(),true);f.addView(h);TextView m=txt("No se ha podido cargar la interfaz.",16,fg(),false);margin(m,0,14,0,0);f.addView(m);TextView d=txt(e.getClass().getSimpleName(),12,muted(),false);f.addView(d);Button r=button("Reintentar",BLUE);margin(r,18,0,0,0);f.addView(r);r.setOnClickListener(v->safeStart());setContentView(f);}

    int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    int bg(){return dark?Color.rgb(10,14,24):Color.rgb(244,246,250);} 
    int card(){return dark?Color.rgb(20,27,40):Color.WHITE;} 
    int soft(){return dark?Color.rgb(27,36,53):Color.rgb(235,239,246);} 
    int elevated(){return dark?Color.rgb(25,33,49):Color.rgb(248,249,252);} 
    int fg(){return dark?Color.WHITE:Color.rgb(24,29,41);} 
    int muted(){return dark?Color.rgb(145,157,178):Color.rgb(92,100,116);} 
    int line(){return dark?Color.rgb(43,54,74):Color.rgb(225,229,237);} 
    TextView txt(String s,float size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));t.setIncludeFontPadding(true);t.setLineSpacing(dp(2),1.02f);return t;}
    GradientDrawable shape(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp((int)r));return g;}
    GradientDrawable outline(int fill,int stroke,float r){GradientDrawable g=shape(fill,r);g.setStroke(dp(1),stroke);return g;}
    void margin(View v,int l,int t,int r,int b){ViewGroup.LayoutParams lp=v.getLayoutParams();LinearLayout.LayoutParams p=lp instanceof LinearLayout.LayoutParams?(LinearLayout.LayoutParams)lp:new LinearLayout.LayoutParams(-1,-2);p.setMargins(dp(l),dp(t),dp(r),dp(b));v.setLayoutParams(p);}
    LinearLayout box(int pad){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(pad),dp(pad),dp(pad),dp(pad));l.setBackground(shape(card(),18));l.setElevation(dp(2));return l;}
    LinearLayout flatBox(int pad){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(pad),dp(pad),dp(pad),dp(pad));l.setBackground(shape(elevated(),18));return l;}
    void add(View v){content.addView(v,new LinearLayout.LayoutParams(-1,-2));}
    TextView pill(String s,int c){TextView p=txt(s,10,c,true);p.setGravity(Gravity.CENTER);p.setPadding(dp(9),dp(6),dp(9),dp(6));p.setBackground(shape(Color.argb(dark?42:28,Color.red(c),Color.green(c),Color.blue(c)),30));return p;}
    Button button(String s,int c){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(14);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setPadding(dp(14),0,dp(14),0);b.setMinHeight(dp(48));b.setMinimumHeight(dp(48));b.setBackground(shape(c,14));return b;}
    TextView iconButton(String s){TextView x=txt(s,19,fg(),false);x.setGravity(Gravity.CENTER);x.setBackground(shape(soft(),15));x.setMinHeight(dp(44));x.setMinimumHeight(dp(44));x.setFocusable(true);return x;}
    TextView navItem(String icon,String label){TextView x=txt(icon+"\n"+label,10,muted(),true);x.setGravity(Gravity.CENTER);x.setLineSpacing(0,.92f);x.setPadding(0,dp(6),0,dp(5));x.setMinHeight(dp(56));x.setBackground(shape(Color.TRANSPARENT,14));x.setContentDescription(label);x.setFocusable(true);return x;}

    void build(){
        if(Build.VERSION.SDK_INT>=30){getWindow().setDecorFitsSystemWindows(true);}
        getWindow().setStatusBarColor(bg());
        getWindow().setNavigationBarColor(bg());
        if(Build.VERSION.SDK_INT>=23){getWindow().getDecorView().setSystemUiVisibility(dark?0:(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR));}
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg());

        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(20),dp(14),dp(20),dp(12));
        LinearLayout brand=new LinearLayout(this);brand.setOrientation(LinearLayout.VERTICAL);
        title=txt("Invest AI",23,fg(),true);brand.addView(title);
        subtitle=txt("Mercados · señales · cartera",12,muted(),false);margin(subtitle,0,4,0,0);brand.addView(subtitle);
        header.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView ai=iconButton("✦");ai.setContentDescription("Abrir analista financiero");header.addView(ai,new LinearLayout.LayoutParams(dp(44),dp(44)));margin(ai,0,0,7,0);ai.setOnClickListener(v->showChat());
        TextView mode=iconButton(dark?"☀":"☾");mode.setContentDescription(dark?"Cambiar a modo claro":"Cambiar a modo oscuro");header.addView(mode,new LinearLayout.LayoutParams(dp(44),dp(44)));mode.setOnClickListener(v->{dark=!dark;getPreferences(0).edit().putBoolean("dark",dark).apply();build();showHome();});
        root.addView(header);

        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(18),dp(2),dp(18),dp(24));ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.setClipToPadding(false);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));

        nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER_VERTICAL);nav.setPadding(dp(8),dp(8),dp(8),dp(8));nav.setBackgroundColor(card());
        TextView n1=navItem("⌂","Inicio"),n2=navItem("✦","Señales"),n3=navItem("▦","Mercados"),n4=navItem("▣","Cartera"),n5=navItem("•••","Más");
        nav.addView(n1,new LinearLayout.LayoutParams(0,dp(60),1));nav.addView(n2,new LinearLayout.LayoutParams(0,dp(60),1));nav.addView(n3,new LinearLayout.LayoutParams(0,dp(60),1));nav.addView(n4,new LinearLayout.LayoutParams(0,dp(60),1));nav.addView(n5,new LinearLayout.LayoutParams(0,dp(60),1));
        n1.setOnClickListener(v->showHome());n2.setOnClickListener(v->showSignals());n3.setOnClickListener(v->showMarkets());n4.setOnClickListener(v->showPortfolio());n5.setOnClickListener(v->showSettings());
        n1.setContentDescription("Inicio, resumen y actualidad");n2.setContentDescription("Señales de mercado");n3.setContentDescription("Mercados e índices");n4.setContentDescription("Mi cartera");n5.setContentDescription("Más opciones y conexión");
        root.addView(nav);
        status=txt("Datos públicos · sin capital invertido",10,muted(),false);status.setGravity(Gravity.CENTER);root.addView(status,new LinearLayout.LayoutParams(-1,dp(25)));
        root.setOnApplyWindowInsetsListener((v,insets)->{if(Build.VERSION.SDK_INT>=30){android.graphics.Insets top=insets.getInsets(WindowInsets.Type.statusBars());android.graphics.Insets bottom=insets.getInsets(WindowInsets.Type.navigationBars());header.setPadding(dp(20),dp(14)+top.top,dp(20),dp(12));nav.setPadding(dp(8),dp(8),dp(8),dp(8)+bottom.bottom);}return insets;});
        setContentView(root);
    }
    void setActiveNav(String page){if(nav==null)return;String active;
        if(page.equals("Invest AI"))active="Inicio";
        else if(page.equals("Señales"))active="Señales";
        else if(page.equals("Mi cartera"))active="Cartera";
        else if(page.equals("Más"))active="Más";
        else active="Mercados"; // Analista IA and individual index details remain secondary screens.
        for(int i=0;i<nav.getChildCount();i++){TextView v=(TextView)nav.getChildAt(i);String raw=v.getText().toString();String label=raw.substring(raw.indexOf('\n')+1);boolean on=label.equals(active);v.setTextColor(on?BLUE:muted());v.setBackground(shape(on?Color.argb(dark?34:20,Color.red(BLUE),Color.green(BLUE),Color.blue(BLUE)):Color.TRANSPARENT,14));v.setSelected(on);v.setAlpha(on?1f:.82f);}}
    void clear(String t,String sub){content.removeAllViews();title.setText(t);subtitle.setText(sub);setActiveNav(t);}
    TextView section(String s){TextView t=txt(s,18,fg(),true);margin(t,2,20,2,9);add(t);return t;}
    TextView eyebrow(String s){TextView t=txt(s.toUpperCase(Locale.US),12,BLUE,true);t.setLetterSpacing(.06f);margin(t,4,18,0,8);add(t);return t;}

    LinearLayout heroMoney(){
        LinearLayout x=box(20);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        TextView e=txt("PATRIMONIO TOTAL",11,muted(),true);top.addView(e,new LinearLayout.LayoutParams(0,-2,1));top.addView(pill("SIN POSICIONES",CYAN));x.addView(top);
        TextView amount=txt("0 €",38,fg(),true);margin(amount,0,10,0,0);x.addView(amount);
        TextView d=txt("No tienes capital invertido todavía",13,muted(),false);x.addView(d);
        View divider=new View(this);divider.setBackgroundColor(line());margin(divider,0,17,0,13);x.addView(divider,new LinearLayout.LayoutParams(-1,dp(1)));
        LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER_VERTICAL);
        Button addBtn=button("＋  Añadir",BLUE);actions.addView(addBtn,new LinearLayout.LayoutParams(0,dp(46),1));addBtn.setOnClickListener(v->showPortfolio());
        Button aiBtn=button("✦  Analista IA",PURPLE);margin(aiBtn,8,0,0,0);actions.addView(aiBtn,new LinearLayout.LayoutParams(0,dp(46),1));aiBtn.setOnClickListener(v->showChat());
        x.addView(actions);return x;
    }

    void showHome(){
        clear("Invest AI","Mercados · señales · cartera");
        add(heroMoney());
        eyebrow("MERCADOS");
        LinearLayout market=flatBox(18);
        LinearLayout mt=new LinearLayout(this);mt.setGravity(Gravity.CENTER_VERTICAL);
        TextView mh=txt("15 mercados",20,fg(),true);mt.addView(mh,new LinearLayout.LayoutParams(0,-2,1));TextView mv=txt("Ver todos  ›",13,BLUE,true);mt.addView(mv);market.addView(mt);
        TextView md=txt("S&P 500 · Nasdaq-100 · IBEX 35 · DAX 40 · Nikkei 225 y más",13,muted(),false);margin(md,7,0,0,0);market.addView(md);
        TextView ms=txt("Explora las empresas que el sistema tiene preparadas para analizar.",12,muted(),false);margin(ms,5,0,0,0);market.addView(ms);market.setOnClickListener(v->showMarkets());add(market);

        eyebrow("ACTUALIDAD");
        LinearLayout newsBox=box(18);TextView nh=txt("Lo que está moviendo el mercado",19,fg(),true);newsBox.addView(nh);
        TextView nd=txt("Titulares recientes que Invest AI está contrastando.",12,muted(),false);margin(nd,6,0,0,0);newsBox.addView(nd);
        LinearLayout newsList=new LinearLayout(this);newsList.setOrientation(LinearLayout.VERTICAL);margin(newsList,13,0,0,0);newsBox.addView(newsList);add(newsBox);loadNews(newsList);

        eyebrow("ANALISTA IA");
        LinearLayout ai=box(18);LinearLayout at=new LinearLayout(this);at.setGravity(Gravity.CENTER_VERTICAL);TextView aiTitle=txt("Tu analista financiero",19,fg(),true);at.addView(aiTitle,new LinearLayout.LayoutParams(0,-2,1));at.addView(pill("IA",PURPLE));ai.addView(at);
        TextView ad=txt("Pregunta por una empresa, un índice, una noticia o una señal.",13,muted(),false);margin(ad,7,0,0,0);ai.addView(ad);
        TextView aq=txt("Abrir analista  →",14,PURPLE,true);margin(aq,13,0,0,0);ai.addView(aq);ai.setOnClickListener(v->showChat());add(ai);

        TextView st=txt(backend==null||backend.trim().isEmpty()?"○  Servidor IA sin configurar":"●  Servidor IA configurado",11,backend==null||backend.trim().isEmpty()?muted():GREEN,false);margin(st,6,4,0,0);add(st);
    }

    void loadNews(LinearLayout target){
        if(backend==null||backend.trim().isEmpty()){
            TextView empty=txt("Conecta Invest AI en Más → Conexión IA para ver aquí los titulares que analiza el motor.",13,muted(),false);
            target.addView(empty);return;
        }
        TextView loading=txt("Actualizando titulares…",13,muted(),false);target.addView(loading);
        new Thread(()->{
            try{
                String raw=get(backend.replaceAll("/+$","")+"/news");
                JSONObject res=new JSONObject(raw);
                JSONArray items=res.optJSONArray("items");
                runOnUiThread(()->{
                    target.removeAllViews();
                    if(items==null||items.length()==0){target.addView(txt("No hay titulares disponibles ahora mismo.",13,muted(),false));return;}
                    for(int i=0;i<items.length();i++){
                        JSONObject item=items.optJSONObject(i); if(item==null) continue;
                        addNewsItem(target,item);
                    }
                    TextView upd=txt("Actualizado: "+res.optString("updated_at","ahora"),11,muted(),false);margin(upd,10,4,0,0);target.addView(upd);
                });
            }catch(Exception ex){
                runOnUiThread(()->{target.removeAllViews();TextView e=txt("No se han podido actualizar los titulares. Revisa la conexión IA en Más.",13,muted(),false);target.addView(e);});
            }
        }).start();
    }

    void addNewsItem(LinearLayout target,JSONObject item){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(dp(12),dp(11),dp(12),dp(11));row.setBackground(shape(soft(),14));
        TextView source=txt(item.optString("source","Fuente pública"),10,BLUE,true);row.addView(source);
        TextView titleNews=txt(item.optString("title","Titular sin título"),14,fg(),true);margin(titleNews,4,0,0,0);row.addView(titleNews);
        String meta=item.optString("date","");
        String why=item.optString("why","");
        if(!TextUtils.isEmpty(meta)||!TextUtils.isEmpty(why)){
            TextView info=txt((!TextUtils.isEmpty(meta)?meta:"")+( !TextUtils.isEmpty(meta)&&!TextUtils.isEmpty(why)?" · ":"")+why,11,muted(),false);margin(info,5,0,0,0);row.addView(info);
        }
        final String url=item.optString("url","");
        if(!TextUtils.isEmpty(url)){
            TextView open=txt("Leer fuente  →",12,BLUE,true);margin(open,7,0,0,0);row.addView(open);open.setOnClickListener(v->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception ignored){}});
            row.setOnClickListener(v->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception ignored){}});
        }
        margin(row,0,0,0,8);target.addView(row);
    }

    void showSignals(){clear("Señales","Solo aparecerán cuando existan datos reales");eyebrow("Ahora mismo");LinearLayout x=box(20);TextView h=txt("Sin señales todavía",22,fg(),true);x.addView(h);TextView d=txt("Tu cartera está vacía y el motor todavía no está conectado a datos de mercado. No mostramos entradas ni puntuaciones inventadas.",13,muted(),false);margin(d,8,0,0,0);x.addView(d);add(x);eyebrow("Estados");decision("ENTRADA","Condiciones favorables según el modelo.",GREEN);decision("MANTENER","La tesis sigue estable.",CYAN);decision("VIGILAR","Aparecen señales que requieren seguimiento.",YELLOW);decision("PREPARAR SALIDA","El deterioro merece revisión.",ORANGE);decision("SALIDA","Se cumplen condiciones críticas.",RED);}
    void decision(String s,String d,int c){LinearLayout x=box(16);LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);TextView dot=txt("●",15,c,true);top.addView(dot,new LinearLayout.LayoutParams(dp(25),-2));TextView h=txt(s,14,fg(),true);top.addView(h,new LinearLayout.LayoutParams(0,-2,1));x.addView(top);TextView q=txt(d,12,muted(),false);margin(q,6,0,0,0);x.addView(q);margin(x,0,0,0,8);add(x);}

    void showMarkets(){clear("Mercados","Toca un índice para abrir sus 10 empresas");eyebrow("Universo de análisis");TextView intro=txt("15 índices · selección preparada · puntuación pendiente de datos reales",12,muted(),false);margin(intro,0,0,0,13);add(intro);for(int i=0;i<indices.length;i++)indexCard(i,indices[i]);}
    void indexCard(int index,String name){LinearLayout x=box(18);LinearLayout top=new LinearLayout(this);TextView n=txt(name,16,fg(),true);top.addView(n,new LinearLayout.LayoutParams(0,-2,1));TextView arrow=txt("›",28,muted(),false);top.addView(arrow);x.addView(top);TextView d=txt("10 empresas · análisis pendiente",13,muted(),false);margin(d,8,0,0,0);x.addView(d);margin(x,0,0,0,10);x.setOnClickListener(v->showIndexCompanies(index));add(x);}
    void showIndexCompanies(int index){
        clear(indices[index],"10 empresas a analizar");
        TextView back=txt("‹  Volver a mercados",12,BLUE,true);margin(back,0,0,0,18);add(back);back.setOnClickListener(v->showMarkets());
        LinearLayout intro=box(18);TextView h=txt("Análisis del índice",17,fg(),true);intro.addView(h);
        TextView d=txt("Datos de mercado y puntuación calculada por Invest AI. Si faltan datos, la puntuación aparece como parcial y no se presenta como definitiva.",14,muted(),false);margin(d,7,0,0,0);intro.addView(d);add(intro);
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);add(list);
        if(backend==null||backend.trim().isEmpty()){
            TextView n=txt("Conecta el servidor en Más → Conexión IA para cargar datos de mercado.",14,muted(),false);margin(n,12,0,0,0);list.addView(n);for(int i=0;i<10;i++)companyRecommendationInto(list,i+1,recommended[index][i],"Datos no conectados");return;
        }
        TextView loading=txt("Cargando datos de mercado…",14,muted(),false);margin(loading,14,0,0,0);list.addView(loading);
        final String indexName=indices[index];
        new Thread(()->{try{
            String raw=get(backend.replaceAll("/+$","")+"/market/index?index="+URLEncoder.encode(indexName,"UTF-8"));
            JSONObject res=new JSONObject(raw);JSONArray companies=res.optJSONArray("companies");JSONArray errors=res.optJSONArray("errors");
            runOnUiThread(()->{list.removeAllViews();eyebrowInto(list,"10 empresas");TextView legend=txt("Noticias 1–100: 1 = vender urgente · 50 = mantener con riesgo · 100 = compra fuerte. Es una señal basada en titulares, no una garantía ni asesoramiento financiero.",11,muted(),false);margin(legend,0,0,0,8);list.addView(legend);
                if(companies!=null){for(int i=0;i<companies.length();i++){try{companyMarketInto(list,i+1,companies.getJSONObject(i));}catch(Exception ignored){}}}
                if(errors!=null&&errors.length()>0){TextView er=txt("Sin datos para "+errors.length()+" empresas en esta actualización.",12,muted(),false);margin(er,12,0,0,0);list.addView(er);}
                if((companies==null||companies.length()==0)&& (errors==null||errors.length()==0)){TextView er=txt("No hay datos de mercado disponibles.",14,muted(),false);list.addView(er);}
            });
        }catch(Exception ex){runOnUiThread(()->{list.removeAllViews();TextView er=txt("No se pudieron cargar los datos de mercado. Revisa la conexión del servidor.",14,muted(),false);list.addView(er);});}}).start();
    }
    void eyebrowInto(LinearLayout target,String s){TextView e=txt(s.toUpperCase(Locale.ROOT),11,muted(),true);margin(e,14,0,0,8);target.addView(e);}
    String logoDomain(String name){
        String n=name.toLowerCase(Locale.ROOT).replace("’","'").trim();
        switch(n){
            case "nvidia": return "nvidia.com"; case "microsoft": return "microsoft.com"; case "amazon": return "amazon.com"; case "meta": return "meta.com"; case "alphabet": return "abc.xyz"; case "broadcom": return "broadcom.com"; case "apple": return "apple.com"; case "eli lilly": return "lilly.com"; case "jpmorgan": return "jpmorganchase.com"; case "exxon mobil": return "exxonmobil.com"; case "tesla": return "tesla.com"; case "netflix": return "netflix.com"; case "costco": return "costco.com"; case "visa": return "visa.com"; case "coca-cola": return "coca-cola.com"; case "walmart": return "walmart.com"; case "goldman sachs": return "goldmansachs.com"; case "american express": return "americanexpress.com"; case "mcdonald's": return "mcdonalds.com";
            case "applovin": return "applovin.com"; case "rocket lab": return "rocketlabusa.com"; case "cava group": return "cava.com"; case "sprouts farmers market": return "sprouts.com"; case "vertiv": return "vertiv.com"; case "comfort systems usa": return "comfortsystemsusa.com"; case "fabrinet": return "fabrinet.com"; case "abercrombie & fitch": return "abercrombie.com"; case "wingstop": return "wingstop.com"; case "duolingo": return "duolingo.com";
            case "asml": return "asml.com"; case "sap": return "sap.com"; case "lvmh": return "lvmh.com"; case "siemens": return "siemens.com"; case "schneider electric": return "se.com"; case "airbus": return "airbus.com"; case "allianz": return "allianz.com"; case "totalenergies": return "totalenergies.com"; case "sanofi": return "sanofi.com"; case "deutsche telekom": return "telekom.com"; case "roche": return "roche.com"; case "novartis": return "novartis.com"; case "abb": return "abb.com"; case "munich re": return "munichre.com"; case "rheinmetall": return "rheinmetall.com"; case "deutsche telekom": return "telekom.com"; case "infineon": return "infineon.com"; case "mercedes-benz": return "mercedes-benz.com"; case "basf": return "basf.com";
            case "astrazeneca": return "astrazeneca.com"; case "shell": return "shell.com"; case "hsbc": return "hsbc.com"; case "unilever": return "unilever.com"; case "rolls-royce": return "rolls-royce.com"; case "bp": return "bp.com"; case "relx": return "relx.com"; case "bae systems": return "baesystems.com"; case "gsk": return "gsk.com"; case "national grid": return "nationalgrid.com"; case "l'oreal": return "loreal.com"; case "hermes": return "hermes.com"; case "vinci": return "vinci.com"; case "air liquide": return "airliquide.com"; case "axa": return "axa.com";
            case "inditex": return "inditex.com"; case "iberdrola": return "iberdrola.com"; case "santander": return "santander.com"; case "bbva": return "bbva.com"; case "amadeus it": return "amadeus.com"; case "aena": return "aena.es"; case "ferrovial": return "ferrovial.com"; case "cellnex telecom": return "cellnex.com"; case "caixabank": return "caixabank.com"; case "acs": return "grupoacs.com";
            case "nestle": return "nestle.com"; case "ubs": return "ubs.com"; case "zurich insurance": return "zurich.com"; case "richemont": return "richemont.com"; case "sika": return "sika.com"; case "holcim": return "holcim.com"; case "swiss re": return "swissre.com";
            case "toyota": return "toyota.com"; case "sony": return "sony.com"; case "mitsubishi ufj": return "mufg.jp"; case "hitachi": return "hitachi.com"; case "tokyo electron": return "tel.com"; case "keyence": return "keyence.com"; case "nintendo": return "nintendo.com"; case "fast retailing": return "fastretailing.com"; case "mitsubishi heavy industries": return "mhi.com"; case "recruit holdings": return "recruit-holdings.com"; case "advantest": return "advantest.com"; case "softbank group": return "group.softbank";
            case "tencent": return "tencent.com"; case "alibaba": return "alibabagroup.com"; case "meituan": return "meituan.com"; case "china mobile": return "chinamobileltd.com"; case "aia group": return "aia.com"; case "xiaomi": return "mi.com"; case "jd.com": return "jd.com"; case "cnooc": return "cnoocltd.com"; case "lenovo": return "lenovo.com";
            case "bhp": return "bhp.com"; case "commonwealth bank": return "commbank.com.au"; case "csl": return "csl.com.au"; case "westpac": return "westpac.com.au"; case "anz group": return "anz.com"; case "macquarie group": return "macquarie.com"; case "woodside energy": return "woodside.com"; case "wesfarmers": return "wesfarmers.com.au"; case "goodman group": return "goodman.com"; case "transurban": return "transurban.com";
        }
        return null;
    }
    String logoUrl(String name){String d=logoDomain(name);return d==null?null:"https://www.google.com/s2/favicons?sz=128&domain="+d;}
    ImageView logoView(String name){
        ImageView iv=new ImageView(this);
        iv.setContentDescription("Logotipo de "+name);
        int size=dp(42);
        iv.setLayoutParams(new LinearLayout.LayoutParams(size,size));
        iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        iv.setPadding(dp(5),dp(5),dp(5),dp(5));
        Bitmap cached=logoCache.get(name);
        iv.setImageBitmap(cached!=null?cached:initialsBitmap(name));
        String url=logoUrl(name);
        if(cached==null && url!=null && logoLoading.add(name)){new Thread(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(4000);c.setReadTimeout(5000);c.setRequestProperty("User-Agent","InvestAI/2.9");try(InputStream in=c.getInputStream()){Bitmap b=BitmapFactory.decodeStream(in);if(b!=null){logoCache.put(name,b);runOnUiThread(()->iv.setImageBitmap(b));}}}catch(Exception ignored){}finally{logoLoading.remove(name);}}).start();}
        return iv;
    }
    Bitmap initialsBitmap(String name){int size=dp(42);Bitmap b=Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(b);Paint bgp=new Paint(Paint.ANTI_ALIAS_FLAG);bgp.setColor(soft());c.drawRoundRect(0,0,size,size,dp(12),dp(12),bgp);Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(fg());p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(dp(12));p.setTextAlign(Paint.Align.CENTER);Paint.FontMetrics fm=p.getFontMetrics();float y=size/2f-(fm.ascent+fm.descent)/2f;c.drawText(initials(name),size/2f,y,p);return b;}
    String initials(String name){String[] p=name.trim().split("\\s+");if(p.length==1)return p[0].substring(0,Math.min(2,p[0].length())).toUpperCase(Locale.ROOT);return (p[0].charAt(0)+""+p[p.length-1].charAt(0)).toUpperCase(Locale.ROOT);}

    void companyRecommendationInto(LinearLayout target,int rank,String name,String detail){LinearLayout x=box(15);LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);TextView r=txt(String.format(Locale.US,"%02d",rank),11,BLUE,true);r.setGravity(Gravity.CENTER);r.setBackground(shape(soft(),11));row.addView(r,new LinearLayout.LayoutParams(dp(34),dp(34)));ImageView logo=logoView(name);row.addView(logo);LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);TextView n=txt(name,15,fg(),true);tx.addView(n);TextView d=txt(detail,13,muted(),false);margin(d,4,0,0,0);tx.addView(d);margin(tx,10,0,0,0);row.addView(tx,new LinearLayout.LayoutParams(0,-2,1));x.addView(row);margin(x,0,0,0,7);target.addView(x,new LinearLayout.LayoutParams(-1,-2));}
    void companyMarketInto(LinearLayout target,int rank,JSONObject o){
        String name=o.optString("name","Empresa");double score=o.optDouble("opportunity_score",Double.NaN);double price=o.optDouble("price",Double.NaN);double ch=o.optDouble("change_1d_pct",Double.NaN);double coverage=o.optDouble("score_weight_coverage_pct",0);String recommendation=o.optString("recommendation","");int color=Double.isNaN(score)||coverage<60?muted():(score>=70?GREEN:score>=50?YELLOW:ORANGE);
        LinearLayout x=box(15);LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);TextView r=txt(String.format(Locale.US,"%02d",rank),11,BLUE,true);r.setGravity(Gravity.CENTER);r.setBackground(shape(soft(),11));row.addView(r,new LinearLayout.LayoutParams(dp(34),dp(34)));ImageView logo=logoView(name);LinearLayout.LayoutParams lpLogo=new LinearLayout.LayoutParams(dp(42),dp(42));lpLogo.setMargins(dp(8),0,dp(10),0);row.addView(logo,lpLogo);LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);TextView n=txt(name,15,fg(),true);tx.addView(n);String p=Double.isNaN(price)?"Precio no disponible":String.format(Locale.US,"Precio %.2f",price);String c=Double.isNaN(ch)?"":String.format(Locale.US," · %+.2f%%",ch);TextView d=txt(p+c,13,muted(),false);margin(d,4,0,0,0);tx.addView(d);String scoreText=coverage<60?"Recomendación pendiente · datos insuficientes":(coverage<85?String.format(Locale.US,"Recomendación provisional: %.0f%% · cobertura %.0f%%",score,coverage):String.format(Locale.US,"Recomendación de inversión: %.0f%%",score));if(!recommendation.isEmpty()&&coverage>=60)scoreText+=" · "+recommendation;TextView st=txt(scoreText,13,color,true);margin(st,5,0,0,0);tx.addView(st);double nr=o.optDouble("news_recommendation",Double.NaN);double nconf=o.optDouble("news_recommendation_confidence_pct",0);String nlabel=o.optString("news_recommendation_label","");String ntxt=Double.isNaN(nr)?"Noticias: sin señal relevante todavía":String.format(Locale.US,"Noticias: %.0f/100 · %s · confianza %.0f%%",nr,nlabel,nconf);int ncolor=Double.isNaN(nr)?muted():(nr<=35?RED:nr<=44?ORANGE:nr<=55?YELLOW:GREEN);TextView nt=txt(ntxt,13,ncolor,true);margin(nt,4,0,0,0);tx.addView(nt);String hl=o.optString("news_top_headline","");if(!hl.isEmpty()&&!"null".equals(hl)){TextView ht=txt("Noticia clave: "+hl,11,muted(),false);margin(ht,3,0,0,0);tx.addView(ht);}margin(tx,0,0,0,0);row.addView(tx,new LinearLayout.LayoutParams(0,-2,1));if(!Double.isNaN(score)&&coverage>=60){TextView badge=txt(String.format(Locale.US,"%.0f%%",score),18,color,true);badge.setGravity(Gravity.CENTER);badge.setBackground(shape(soft(),14));badge.setPadding(dp(10),dp(8),dp(10),dp(8));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(dp(72),dp(50));bp.gravity=Gravity.CENTER_VERTICAL;row.addView(badge,bp);}x.addView(row);margin(x,0,0,0,7);target.addView(x,new LinearLayout.LayoutParams(-1,-2));}
    void companyRecommendation(int rank,String name){companyRecommendationInto(content,rank,name,"Análisis pendiente");}

    void showPortfolio(){clear("Mi cartera","Tu dinero, cuando decidas empezar");add(heroMoney());eyebrow("Posiciones");LinearLayout empty=box(20);TextView h=txt("Aquí aparecerán tus inversiones",18,fg(),true);empty.addView(h);TextView d=txt("Todavía no has añadido ninguna posición. No hay rentabilidad, pérdidas ni datos ficticios que mostrar.",12,muted(),false);margin(d,7,0,0,0);empty.addView(d);add(empty);eyebrow("Añadir posición");EditText e=field("Ticker · ej. NVDA");add(e);EditText q=field("Número de acciones");q.setInputType(2);margin(q,0,8,0,0);add(q);Button b=button("＋  Añadir posición",BLUE);margin(b,0,8,0,0);add(b);b.setOnClickListener(v->{if(e.getText().length()>0){holding(e.getText().toString().toUpperCase(Locale.US),q.getText().toString()+" acciones");e.setText("");q.setText("");}});}
    void holding(String name,String qty){LinearLayout x=box(15);LinearLayout top=new LinearLayout(this);TextView n=txt(name,16,fg(),true);top.addView(n,new LinearLayout.LayoutParams(0,-2,1));top.addView(pill("A ANALIZAR",CYAN));x.addView(top);TextView q=txt(qty,12,muted(),false);margin(q,7,0,0,0);x.addView(q);margin(x,0,0,0,7);add(x);}
    EditText field(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextColor(fg());e.setHintTextColor(muted());e.setSingleLine(true);e.setBackground(shape(soft(),14));e.setTextSize(16);e.setPadding(dp(16),dp(13),dp(16),dp(13));return e;}

    void showChat(){clear("Analista IA","Tu copiloto financiero");LinearLayout intro=box(20);TextView p=txt("✦  ANALISTA FINANCIERO",10,PURPLE,true);intro.addView(p);TextView h=txt("Entiende antes de decidir",22,fg(),true);margin(h,8,0,0,0);intro.addView(h);TextView d=txt("Pregúntame por una empresa, un índice, una noticia o cualquier dato financiero. Te explicaré qué significa y qué factores lo están moviendo.",12,muted(),false);margin(d,8,0,0,0);intro.addView(d);add(intro);eyebrow("Preguntas rápidas");String[] qs={"¿Qué debería vigilar ahora?","Explícame el PER de una empresa","¿Qué significa una señal de salida?","Analiza una empresa"};for(String q:qs){TextView b=txt(q+"  ›",13,fg(),true);b.setBackground(shape(soft(),14));b.setPadding(dp(15),dp(14),dp(15),dp(14));margin(b,0,0,0,7);add(b);b.setOnClickListener(v->sendChat(q));}eyebrow("Conversación");TextView log=txt("Escribe una pregunta para empezar.",13,muted(),false);log.setBackground(shape(card(),16));log.setPadding(dp(15),dp(15),dp(15),dp(15));add(log);EditText input=field("Escribe tu pregunta...");margin(input,0,8,0,0);add(input);Button send=button("Enviar",PURPLE);add(send);send.setOnClickListener(v->{String q=input.getText().toString().trim();if(!q.isEmpty()){log.setText("Tú: "+q+"\n\nAnalizando…");input.setText("");chatRequest(q,log,send);}});}
    void sendChat(String q){chatRequest(q,null,null);}
    void chatRequest(String question,TextView target,Button send){if(backend==null||backend.trim().isEmpty()){if(target!=null)target.setText("Para usar el Analista IA, configura primero el servidor en Más → Conexión IA.\n\nLa clave de OpenAI debe permanecer en el servidor, nunca dentro del APK.");else Toast.makeText(this,"Configura la conexión IA en Más",Toast.LENGTH_LONG).show();return;}if(send!=null)send.setEnabled(false);new Thread(()->{try{String url=backend.replaceAll("/+$","")+"/chat";HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setRequestMethod("POST");c.setConnectTimeout(8000);c.setReadTimeout(30000);c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");JSONObject body=new JSONObject();body.put("question",question);body.put("portfolio","0 € invertidos actualmente; sin posiciones registradas");body.put("app_context","Invest AI: análisis financiero por valoración, crecimiento, salud financiera, momentum, revisiones, noticias y riesgo. 15 índices internacionales.");OutputStream os=c.getOutputStream();os.write(body.toString().getBytes("UTF-8"));os.close();BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream(),"UTF-8"));StringBuilder b=new StringBuilder();String l;while((l=r.readLine())!=null)b.append(l);r.close();JSONObject res=new JSONObject(b.toString());String answer=res.optString("answer","No se recibió respuesta.");runOnUiThread(()->{if(target!=null)target.setText("Tú: "+question+"\n\nAnalista IA:\n"+answer);else new AlertDialog.Builder(this).setTitle("Analista IA").setMessage(answer).setPositiveButton("Cerrar",null).show();if(send!=null)send.setEnabled(true);});}catch(Exception ex){runOnUiThread(()->{if(target!=null)target.setText("No se pudo conectar con el Analista IA.\n\nComprueba la conexión en Más → Conexión IA.");else Toast.makeText(this,"No se pudo conectar con el servidor IA",Toast.LENGTH_LONG).show();if(send!=null)send.setEnabled(true);});}}).start();}

    void showSettings(){clear("Más","Configuración de Invest AI");eyebrow("Analista IA");LinearLayout ia=box(18);TextView h=txt("Conexión IA",17,fg(),true);ia.addView(h);TextView d=txt("Introduce la URL base del servidor. No añadas /chat ni /news; la app añade las rutas automáticamente. La clave de API permanece en el servidor.",13,muted(),false);margin(d,7,0,0,0);ia.addView(d);EditText e=field("https://tu-servidor.onrender.com");e.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);e.setText(backend);margin(e,12,0,0,0);ia.addView(e);Button b=button("Guardar conexión",PURPLE);margin(b,9,0,0,0);ia.addView(b);b.setOnClickListener(v->{String candidate=e.getText().toString().trim();if(candidate.isEmpty()){backend="";getPreferences(0).edit().remove("backend").apply();status.setText("Servidor IA sin configurar");Toast.makeText(this,"Conexión eliminada",Toast.LENGTH_SHORT).show();return;}while(candidate.endsWith("/"))candidate=candidate.substring(0,candidate.length()-1);String lower=candidate.toLowerCase(Locale.ROOT);if(lower.endsWith("/chat"))candidate=candidate.substring(0,candidate.length()-5);else if(lower.endsWith("/news"))candidate=candidate.substring(0,candidate.length()-5);Uri parsed=Uri.parse(candidate);String scheme=parsed.getScheme();if(parsed.getHost()==null||scheme==null||!(scheme.equalsIgnoreCase("https")||scheme.equalsIgnoreCase("http"))||!(parsed.getPath()==null||parsed.getPath().isEmpty()||parsed.getPath().equals("/"))){Toast.makeText(this,"Introduce una URL base válida, por ejemplo https://tu-servidor.onrender.com",Toast.LENGTH_LONG).show();return;}backend=candidate;getPreferences(0).edit().putString("backend",backend).apply();status.setText("Servidor IA configurado · pendiente de verificar");Toast.makeText(this,"URL guardada. La conexión se comprobará al consultar datos.",Toast.LENGTH_LONG).show();});add(ia);eyebrow("Apariencia");LinearLayout ap=box(18);TextView ah=txt("Tema",16,fg(),true);ap.addView(ah);TextView ad=txt(dark?"Modo oscuro activo":"Modo claro activo",12,muted(),false);margin(ad,6,0,0,0);ap.addView(ad);Button sw=button(dark?"☀  Usar modo claro":"☾  Usar modo oscuro",BLUE);margin(sw,12,0,0,0);ap.addView(sw);sw.setOnClickListener(v->{dark=!dark;getPreferences(0).edit().putBoolean("dark",dark).apply();build();showSettings();});add(ap);eyebrow("Modelo");LinearLayout md=box(18);TextView mh=txt("Puntuación de oportunidad",16,fg(),true);md.addView(mh);TextView mm=txt("0–100. Resume valoración, crecimiento, salud financiera, momentum, revisiones, noticias y riesgo. No representa una probabilidad de beneficio.",13,muted(),false);margin(mm,7,0,0,0);md.addView(mm);add(md);}

    String get(String u)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(10000);c.setRequestProperty("User-Agent","InvestAI/2.4");BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream()));StringBuilder b=new StringBuilder();String l;while((l=r.readLine())!=null)b.append(l);r.close();return b.toString();}
}
