#!/data/data/com.termux/files/usr/bin/bash
set -e
chmod +x gradlew
./gradlew assembleDebug
echo ""
echo "APK generado en:"
echo "app/build/outputs/apk/debug/app-debug.apk"
