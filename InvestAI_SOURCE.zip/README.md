# Invest AI — Android

Aplicación Android nativa para el proyecto Invest AI.

## Qué incluye
- Inicio con oportunidad global.
- Mercados con los 15 índices definidos.
- Top global.
- Mi cartera manual para posiciones de MyInvestor.
- Señales MANTENER / VIGILAR / PREPARAR SALIDA / SALIDA.
- Consulta de precios públicos mediante Yahoo Finance.
- Noticias públicas mediante GDELT.
- Modo de conexión opcional al backend Invest AI existente.
- Diseño pensado para smartphone.

## Abrir
Android Studio > Open > selecciona esta carpeta.

Después:
Build > Build APK(s)

El APK aparecerá normalmente en:
app/build/outputs/apk/debug/app-debug.apk

## Backend
En Ajustes de la app puedes indicar la URL de un backend Invest AI si quieres usar el motor completo que ya tenemos.
Ejemplo en una red local:
http://192.168.1.50:8000

Si no se configura backend, la aplicación usa el modo móvil público integrado para precios/noticias y una puntuación técnica local.

## Nota
Esta primera compilación Android está preparada para instalarse y probarse directamente. La conexión al motor completo permite ampliar después el universo de componentes, fundamentales, histórico y backtesting sin cambiar la interfaz.


## Compilación sin PC
Este paquete incluye `.github/workflows/build-apk.yml`. Puedes subir el proyecto
a un repositorio PRIVADO de GitHub desde el propio teléfono y ejecutar el workflow
"Build Invest AI APK". GitHub compila el APK en la nube y lo deja disponible como
Artifact para descargar desde el teléfono.

También incluye `build_apk.sh` para una compilación local en Android/Termux si se
dispone del SDK Android y Java.
