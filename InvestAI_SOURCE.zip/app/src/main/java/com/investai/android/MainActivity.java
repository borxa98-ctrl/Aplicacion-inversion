package com.investai.android;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import java.util.*;
import java.net.*;
import java.io.*;
import org.json.*;

public class MainActivity extends Activity {
    LinearLayout root, content, nav;
    TextView title, subtitle, status;
    boolean dark = true;
    String backend = "";
    final int GREEN=Color.rgb(39,201,139), YELLOW=Color.rgb(245,190,70), ORANGE=Color.rgb(255,145,80), RED=Color.rgb(245,88,88), BLUE=Color.rgb(78,124,255), CYAN=Color.rgb(72,190,255);
    final String[] indices={"S&P 500","Nasdaq-100","Dow Jones","Russell 2000","EURO STOXX 50","STOXX Europe 600","DAX 40","FTSE 100","CAC 40","IBEX 35","SMI","Nikkei 225","TOPIX","Hang Seng","S&P/ASX 200"};
    final String[][] recommended={
        {"NVIDIA","Microsoft","Amazon","Meta","Alphabet","Broadcom","Apple","Eli Lilly","JPMorgan","Exxon Mobil"},
        {"NVIDIA","Microsoft","Amazon","Meta","Broadcom","Alphabet","Apple","Tesla","Netflix","Costco"},
        {"Microsoft","Apple","JPMorgan","Visa","Coca-Cola","Amazon","Walmart","Goldman Sachs","American Express","McDonald's"},
        {"AppLovin","Rocket Lab","Cava Group","Sprouts Farmers Market","Vertiv","Comfort Systems USA","Fabrinet","Abercrombie & Fitch","Wingstop","Duolingo"},
        {"ASML","SAP","LVMH","Siemens","Schneider Electric","Airbus","Allianz","TotalEnergies","Sanofi","Deutsche Telekom"},
        {"ASML","SAP","Schneider Electric","Siemens","Airbus","Roche","Novartis","Allianz","LVMH","ABB"},
        {"SAP","Siemens","Allianz","Airbus","Munich Re","Rheinmetall","Deutsche Telekom","Infineon","Mercedes-Benz","BASF"},
        {"AstraZeneca","Shell","HSBC","Unilever","Rolls-Royce","BP","RELX","BAE Systems","GSK","National Grid"},
        {"LVMH","Schneider Electric","Airbus","Safran","L'Oreal","Hermes","Vinci","Air Liquide","AXA","TotalEnergies"},
        {"Inditex","Iberdrola","Santander","BBVA","Amadeus IT","Aena","Ferrovial","Cellnex Telecom","CaixaBank","ACS"},
        {"Nestle","Novartis","Roche","UBS","ABB","Zurich Insurance","Richemont","Sika","Holcim","Swiss Re"},
        {"Toyota","Sony","Mitsubishi UFJ","Hitachi","Tokyo Electron","Keyence","Nintendo","Fast Retailing","Mitsubishi Heavy Industries","Recruit Holdings"},
        {"Toyota","Sony","Tokyo Electron","Mitsubishi UFJ","Hitachi","Keyence","Nintendo","Fast Retailing","Advantest","SoftBank Group"},
        {"Tencent","Alibaba","Meituan","HSBC","China Mobile","AIA Group","Xiaomi","JD.com","CNOOC","Lenovo"},
        {"BHP","Commonwealth Bank","CSL","Westpac","ANZ Group","Macquarie Group","Woodside Energy","Wesfarmers","Goodman Group","Transurban"}
    };
    final String[] symbols={"NVDA","MSFT","AMZN","META","GOOGL","AVGO","AAPL","LLY","JPM","XOM"};

    @Override public void onCreate(Bundle b){super.onCreate(b); dark=getPreferences(0).getBoolean("dark",true); backend=getPreferences(0).getString("backend",""); safeStart();}
    void safeStart(){try{build();showHome();}catch(Throwable e){fallback(e);}}
    void fallback(Throwable e){ LinearLayout f=new LinearLayout(this); f.setOrientation(LinearLayout.VERTICAL); f.setPadding(dp(24),dp(32),dp(24),dp(24)); f.setBackgroundColor(bg()); TextView h=txt("Invest AI",28,fg(),true); f.addView(h); TextView m=txt("No se ha podido cargar la interfaz.",16,fg(),false); margin(m,0,16,0,0); f.addView(m); TextView d=txt(e.getClass().getSimpleName(),12,muted(),false); f.addView(d); Button r=button("Reintentar",BLUE); margin(r,0,18,0,0); f.addView(r); r.setOnClickListener(v->safeStart()); setContentView(f); }

    int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    int bg(){return dark?Color.rgb(8,12,24):Color.rgb(246,248,252);} int card(){return dark?Color.rgb(18,25,43):Color.WHITE;} int card2(){return dark?Color.rgb(25,34,56):Color.rgb(238,242,248);} int fg(){return dark?Color.WHITE:Color.rgb(24,31,45);} int muted(){return dark?Color.rgb(158,170,194):Color.rgb(95,105,125);}
    TextView txt(String s,float size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL);t.setIncludeFontPadding(false);return t;}
    GradientDrawable shape(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp((int)r));return g;}
    void margin(View v,int l,int t,int r,int b){ViewGroup.LayoutParams lp=v.getLayoutParams();LinearLayout.LayoutParams p=lp instanceof LinearLayout.LayoutParams?(LinearLayout.LayoutParams)lp:new LinearLayout.LayoutParams(-2,-2);p.setMargins(dp(l),dp(t),dp(r),dp(b));v.setLayoutParams(p);}
    LinearLayout box(int pad){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(pad),dp(pad),dp(pad),dp(pad));l.setBackground(shape(card(),18));return l;}
    void add(View v){content.addView(v,new LinearLayout.LayoutParams(-1,-2)); animate(v);}
    void animate(View v){v.setAlpha(0f);v.setTranslationY(dp(6));v.animate().alpha(1f).translationY(0).setDuration(180).start();}
    TextView pill(String s,int c){TextView p=txt(s,11,c,true);p.setGravity(Gravity.CENTER);p.setPadding(dp(10),dp(7),dp(10),dp(7));p.setBackground(shape(Color.argb(dark?42:25,Color.red(c),Color.green(c),Color.blue(c)),20));return p;}
    Button button(String s,int c){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(13);b.setAllCaps(false);b.setBackground(shape(c,14));return b;}

    void build(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg());
        LinearLayout header=new LinearLayout(this);header.setOrientation(LinearLayout.HORIZONTAL);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(18),dp(15),dp(18),dp(12));
        LinearLayout htxt=new LinearLayout(this);htxt.setOrientation(LinearLayout.VERTICAL);title=txt("Invest AI",24,fg(),true);htxt.addView(title);subtitle=txt("Decisiones explicadas visualmente",12,muted(),false);margin(subtitle,0,5,0,0);htxt.addView(subtitle);header.addView(htxt,new LinearLayout.LayoutParams(0,-2,1));
        TextView ai=txt("✦",22,fg(),false);ai.setGravity(Gravity.CENTER);ai.setPadding(dp(8),dp(5),dp(8),dp(5));ai.setBackground(shape(card2(),16));header.addView(ai,new LinearLayout.LayoutParams(dp(44),dp(44)));ai.setOnClickListener(v->showChat()); TextView mode=txt(dark?"☀":"☾",23,fg(),false);mode.setGravity(Gravity.CENTER);mode.setPadding(dp(8),dp(5),dp(8),dp(5));mode.setBackground(shape(card2(),16));header.addView(mode,new LinearLayout.LayoutParams(dp(44),dp(44)));mode.setOnClickListener(v->{dark=!dark;getPreferences(0).edit().putBoolean("dark",dark).apply();build();showHome();});
        root.addView(header,new LinearLayout.LayoutParams(-1,-2));
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(14),0,dp(14),dp(16));ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        nav=new LinearLayout(this);nav.setPadding(dp(7),dp(6),dp(7),dp(5));nav.setBackgroundColor(dark?Color.rgb(13,18,32):Color.WHITE);String[] ns={"⌂\nInicio","◉\nSeñales","◫\nMercados","▣\nCartera","⋯\nMás"};
        for(String n:ns){TextView x=txt(n,10,muted(),true);x.setGravity(Gravity.CENTER);x.setLineSpacing(0,0.85f);nav.addView(x,new LinearLayout.LayoutParams(0,dp(58),1));String key=n.substring(n.indexOf('\n')+1);if(key.equals("Inicio"))x.setOnClickListener(v->showHome());if(key.equals("Señales"))x.setOnClickListener(v->showSignals());if(key.equals("Mercados"))x.setOnClickListener(v->showMarkets());if(key.equals("Cartera"))x.setOnClickListener(v->showPortfolio());if(key.equals("Más"))x.setOnClickListener(v->showSettings());}
        root.addView(nav);status=txt("Datos públicos · modo visual",10,muted(),false);status.setGravity(Gravity.CENTER);root.addView(status,new LinearLayout.LayoutParams(-1,dp(25)));setContentView(root);
    }
    void clear(String t,String sub){content.removeAllViews();title.setText(t);subtitle.setText(sub);}
    TextView section(String s){TextView t=txt(s,18,fg(),true);margin(t,5,15,4,7);add(t);return t;}

    LinearLayout metric(String label,String value,String sub,int c){LinearLayout x=box(14);TextView l=txt(label.toUpperCase(Locale.US),10,muted(),true);x.addView(l);TextView v=txt(value,24,fg(),true);margin(v,0,7,0,0);x.addView(v);TextView q=txt(sub,11,c,true);x.addView(q);return x;}
    void showHome(){clear("Invest AI","Tu dinero, explicado de un vistazo");section("Resumen de cartera");LinearLayout row=new LinearLayout(this);row.addView(metric("Invertido","0 €","Sin capital invertido",BLUE),new LinearLayout.LayoutParams(0,-2,1));LinearLayout b=metric("Patrimonio","0 €","Añade una posición para empezar",muted());margin(b,7,0,0,0);row.addView(b,new LinearLayout.LayoutParams(0,-2,1));add(row);
        section("Estado actual");explainCard("Todavía no tienes inversiones","Tu cartera está vacía. Cuando añadas una posición, Invest AI calculará su estado, evolución y señales de salida.",BLUE);
        section("Qué necesita tu atención");signalCard("✓","No hay posiciones que vigilar","No tienes capital invertido actualmente. Cuando añadas una posición aparecerán aquí las alertas relevantes.",GREEN,"Ver cartera",()->showPortfolio());
        section("Lectura rápida del mercado");miniMarketEmpty("S&P 500");miniMarketEmpty("Nasdaq-100");miniMarketEmpty("IBEX 35");
        section("Habla con tu analista IA"); explainCard("¿No entiendes un dato? Pregunta","La IA puede explicarte PER, crecimiento, deuda, momentum, resultados, noticias y las señales de tu cartera en lenguaje claro.",CYAN); content.getChildAt(content.getChildCount()-1).setOnClickListener(v->showChat()); section("Lo importante");explainCard("No necesitas interpretar 7 indicadores","Invest AI convertirá valoración, crecimiento, tendencia, revisiones, noticias y riesgo en una lectura visual cuando los datos estén conectados.",BLUE);
    }
    void signalCard(String icon,String head,String body,int c,String action,Runnable r){LinearLayout x=box(14);LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);TextView i=txt(icon,25,fg(),false);top.addView(i,new LinearLayout.LayoutParams(dp(38),dp(42)));LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);TextView h=txt(head,15,fg(),true);tx.addView(h);TextView bd=txt(body,12,muted(),false);margin(bd,0,5,0,0);tx.addView(bd);top.addView(tx,new LinearLayout.LayoutParams(0,-2,1));x.addView(top);TextView go=txt("›  "+action,12,c,true);margin(go,dp(38),10,0,0);x.addView(go);x.setOnClickListener(v->r.run());margin(x,0,4,0,4);add(x);}
    void miniMarketEmpty(String name){LinearLayout x=box(13);LinearLayout top=new LinearLayout(this);TextView n=txt(name,14,fg(),true);top.addView(n,new LinearLayout.LayoutParams(0,-2,1));TextView s=txt("—",15,muted(),true);top.addView(s);x.addView(top);TextView h=txt("Sin análisis conectado · abre Mercados para consultar el índice",11,muted(),false);margin(h,0,7,0,0);x.addView(h);add(x);}
    void miniMarket(String name,int score,String hint,int c){LinearLayout x=box(13);LinearLayout top=new LinearLayout(this);TextView n=txt(name,14,fg(),true);top.addView(n,new LinearLayout.LayoutParams(0,-2,1));TextView s=txt(score+"/100",15,c,true);top.addView(s);x.addView(top);TextView h=txt("● "+hint,11,muted(),false);margin(h,0,7,0,0);x.addView(h);addProgress(x,score,c);margin(x,0,3,0,3);}
    void addProgress(LinearLayout parent,int score,int c){FrameLayout fr=new FrameLayout(this);fr.setPadding(0,0,0,0);TextView base=txt("",1,fg(),false);base.setBackground(shape(card2(),8));fr.addView(base,new FrameLayout.LayoutParams(-1,dp(7)));TextView fill=txt("",1,fg(),false);fill.setBackground(shape(c,8));FrameLayout.LayoutParams fp=new FrameLayout.LayoutParams(dp(Math.max(8,score*2)),dp(7));fr.addView(fill,fp);parent.addView(fr);}
    void explainCard(String h,String b,int c){LinearLayout x=box(15);TextView a=txt("CÓMO LEERLO",10,c,true);x.addView(a);TextView t=txt(h,16,fg(),true);margin(t,0,7,0,0);x.addView(t);TextView d=txt(b,12,muted(),false);x.addView(d);margin(x,0,4,0,4);add(x);}

    void showSignals(){clear("Señales","Entradas y cambios que merecen atención");section("Estado de señales");explainCard("Todavía no hay señales calculadas","La cartera está vacía y el motor de análisis todavía no está conectado a datos de mercado. Cuando esté activo, aquí aparecerán las entradas y los cambios que merezcan atención.",BLUE);section("Estados que utilizará el motor");decision("🟢 ENTRADA","Condiciones favorables según las reglas configuradas.",GREEN);decision("🔵 MANTENER","La tesis sigue sin deterioro relevante.",CYAN);decision("🟡 VIGILAR","Hay señales que requieren seguimiento.",YELLOW);decision("🟠 PREPARAR SALIDA","El deterioro ya es suficiente para revisar la posición.",ORANGE);decision("🔴 SALIDA","El motor detecta señales críticas.",RED);}
    void entry(String name,String price,String score,String zone,String why,int c){LinearLayout x=box(15);LinearLayout top=new LinearLayout(this);TextView n=txt(name,19,fg(),true);top.addView(n,new LinearLayout.LayoutParams(0,-2,1));top.addView(pill("🟢 ENTRADA",c));x.addView(top);TextView p=txt(price,25,fg(),true);margin(p,0,9,0,0);x.addView(p);TextView sc=txt("Puntuación "+score,13,c,true);x.addView(sc);TextView z=txt("Zona de entrada  ·  "+zone,12,muted(),false);margin(z,0,7,0,0);x.addView(z);TextView w=txt("¿Por qué?  "+why,12,fg(),false);x.addView(w);margin(x,0,5,0,5);add(x);}
    void decision(String h,String b,int c){LinearLayout x=box(12);TextView a=txt(h,14,c,true);x.addView(a);TextView d=txt(b,11,muted(),false);margin(d,0,4,0,0);x.addView(d);add(x);}

    void showMarkets(){clear("Mercados","Toca un índice para consultar sus 10 empresas");section("15 mercados disponibles");for(int i=0;i<indices.length;i++)indexCard(i,indices[i]);}
    void indexCard(int index,String name){LinearLayout x=box(14);LinearLayout top=new LinearLayout(this);TextView n=txt(name,16,fg(),true);top.addView(n,new LinearLayout.LayoutParams(0,-2,1));TextView go=txt("10 empresas  ›",12,BLUE,true);top.addView(go);x.addView(top);TextView h=txt("Abrir análisis del índice y consultar las empresas seleccionadas por el motor.",11,muted(),false);margin(h,0,8,0,0);x.addView(h);x.setClickable(true);x.setOnClickListener(v->showIndexCompanies(index));margin(x,0,3,0,3);add(x);}

    void showIndexCompanies(int index){
        String market=indices[index];
        clear(market,"10 empresas para analizar");
        TextView back=txt("‹  Volver a Mercados",13,BLUE,true);back.setPadding(dp(4),dp(6),dp(4),dp(10));content.addView(back,new LinearLayout.LayoutParams(-1,-2));back.setOnClickListener(v->showMarkets());
        TextView intro=txt("Estas 10 empresas pertenecen a este índice. La recomendación, el orden y la puntuación se calcularán con datos reales cuando el motor de análisis esté conectado.",12,muted(),false);margin(intro,0,0,0,10);add(intro);
        section("10 empresas");
        for(int i=0;i<10;i++) companyRecommendation(i+1,recommended[index][i]);
        section("Qué aparecerá cuando esté conectado");
        explainCard("Puntuación de oportunidad","Cada empresa recibirá una puntuación 0–100 basada en valoración, crecimiento, salud financiera, momentum, revisiones, noticias y riesgo. No se muestran puntuaciones ficticias.",BLUE);
    }
    void companyRecommendation(int rank,String name){
        LinearLayout x=box(13);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        TextView r=txt(String.format(Locale.US,"%02d",rank),13,BLUE,true);r.setGravity(Gravity.CENTER);r.setBackground(shape(card2(),12));top.addView(r,new LinearLayout.LayoutParams(dp(38),dp(38)));
        LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);TextView n=txt(name,15,fg(),true);tx.addView(n);TextView desc=txt("Pendiente de análisis",11,muted(),false);margin(desc,3,4,0,0);tx.addView(desc);margin(tx,10,0,0,0);top.addView(tx,new LinearLayout.LayoutParams(0,-2,1));
        TextView sv=txt("—",18,muted(),true);sv.setGravity(Gravity.CENTER);top.addView(sv,new LinearLayout.LayoutParams(dp(48),-2));
        x.addView(top);margin(x,0,3,0,3);add(x);
    }

    void showPortfolio(){clear("Mi cartera","Qué tienes, cómo va y qué debería vigilarse");section("Resumen");LinearLayout row=new LinearLayout(this);row.addView(metric("Invertido","0 €","Capital aportado",BLUE),new LinearLayout.LayoutParams(0,-2,1));LinearLayout m=metric("Actual","0 €","Sin posiciones",muted());margin(m,7,0,0,0);row.addView(m,new LinearLayout.LayoutParams(0,-2,1));add(row);section("Posiciones");explainCard("Tu cartera está vacía","No hay ninguna posición añadida. Puedes introducir una acción desde el formulario inferior cuando quieras empezar a seguirla.",BLUE);section("Añadir posición");EditText e=field("Ticker · ej. NVDA");add(e);EditText q=field("Número de acciones");q.setInputType(2);margin(q,0,8,0,0);add(q);Button b=button("＋  Añadir posición",BLUE);margin(b,0,8,0,0);add(b);b.setOnClickListener(v->{if(e.getText().length()>0){holding(e.getText().toString().toUpperCase(Locale.US),q.getText().toString()+" acciones","Pendiente de datos","—","🔵 A ANALIZAR",CYAN);e.setText("");q.setText("");}});}
    void holding(String name,String qty,String ret,String score,String state,int c){LinearLayout x=box(14);LinearLayout top=new LinearLayout(this);TextView n=txt(name,16,fg(),true);top.addView(n,new LinearLayout.LayoutParams(0,-2,1));top.addView(pill(state,c));x.addView(top);LinearLayout mid=new LinearLayout(this);TextView q=txt(qty,12,muted(),false);mid.addView(q,new LinearLayout.LayoutParams(0,-2,1));TextView r=txt(ret,14,c,true);mid.addView(r);margin(mid,0,9,0,0);x.addView(mid);TextView s=txt("Puntuación  "+score,12,muted(),false);x.addView(s);margin(x,0,4,0,4);add(x);}
    EditText field(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextColor(fg());e.setHintTextColor(muted());e.setSingleLine(true);e.setBackground(shape(card2(),14));e.setPadding(dp(14),dp(11),dp(14),dp(11));return e;}

    void showChat(){
        clear("Analista IA","Interpreta los datos de Invest AI contigo");
        LinearLayout intro=box(14);
        TextView a=txt("ANALISTA FINANCIERO",10,CYAN,true);intro.addView(a);
        TextView h=txt("Pregúntame qué significa cualquier dato",16,fg(),true);margin(h,0,6,0,0);intro.addView(h);
        TextView d=txt("Puedo explicar valoración, crecimiento, deuda, resultados, momentum, riesgo, noticias y señales. No inventaré datos: si faltan, te lo indicaré.",12,muted(),false);intro.addView(d);margin(intro,0,8,0,8);add(intro);
        section("Preguntas rápidas");
        String[] qs={"¿Cómo está mi cartera?","Explícame el PER de una empresa","¿Qué significa una señal de salida?","¿Qué debería vigilar en NVIDIA?"};
        for(String q:qs){TextView b=txt("›  "+q,13,fg(),true);b.setBackground(shape(card2(),14));b.setPadding(dp(14),dp(12),dp(14),dp(12));margin(b,0,4,0,4);add(b);b.setOnClickListener(v->sendChat(q));}
        section("Conversación");
        TextView chatlog=txt("Escribe una pregunta para empezar.",13,muted(),false);chatlog.setBackground(shape(card(),14));chatlog.setPadding(dp(14),dp(14),dp(14),dp(14));add(chatlog);
        EditText input=field("Escribe tu pregunta...");margin(input,0,7,0,0);add(input);
        Button send=button("Enviar a Analista IA",BLUE);add(send);
        send.setOnClickListener(v->{String q=input.getText().toString().trim();if(!q.isEmpty()){chatlog.setText("Tú: "+q+"\n\nAnalizando…");input.setText("");chatlog.setTextColor(fg());chatlog.setBackground(shape(card(),14));chatRequest(q,chatlog,send);}});
    }
    void sendChat(String q){
        showChat();
        new Handler(Looper.getMainLooper()).postDelayed(()->{
            // The quick question is sent through the same backend connector used by the chat box.
            if(content.getChildCount()>=1){ View v=content.getChildAt(content.getChildCount()-1); }
        },80);
        // Quick prompts use a simple background request and show the result in a dialog.
        chatRequest(q,null,null);
    }
    void chatRequest(String question, TextView target, Button send){
        if(backend==null || backend.trim().isEmpty()){
            if(target!=null) target.setText("Configura primero la conexión del Analista IA en Más → Conexión IA.\n\nPor seguridad, la clave de OpenAI no se guarda dentro del APK; el teléfono se conecta a un pequeño servidor tuyo que mantiene la clave protegida.");
            else Toast.makeText(this,"Configura la conexión IA en Más",Toast.LENGTH_LONG).show();
            if(send!=null)send.setEnabled(true);
            return;
        }
        if(send!=null)send.setEnabled(false);
        new Thread(()->{
            try{
                String url=backend.replaceAll("/+$","")+"/chat";
                HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
                c.setRequestMethod("POST");c.setConnectTimeout(8000);c.setReadTimeout(30000);c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");
                JSONObject body=new JSONObject();body.put("question",question);body.put("portfolio","0 € invertidos actualmente; sin posiciones registradas");body.put("app_context","Invest AI: análisis por valoración 20%, crecimiento/beneficios 20%, salud financiera 15%, momentum técnico 15%, revisiones 10%, noticias/sentimiento 10%, riesgo/volatilidad 10%. Índices: S&P 500, Nasdaq-100, Dow Jones, Russell 2000, EURO STOXX 50, STOXX Europe 600, DAX 40, FTSE 100, CAC 40, IBEX 35, SMI, Nikkei 225, TOPIX, Hang Seng, S&P/ASX 200.");
                OutputStream os=c.getOutputStream();os.write(body.toString().getBytes("UTF-8"));os.close();
                BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream(),"UTF-8"));StringBuilder b=new StringBuilder();String l;while((l=r.readLine())!=null)b.append(l);r.close();
                JSONObject res=new JSONObject(b.toString());String answer=res.optString("answer","No se recibió respuesta.");
                runOnUiThread(()->{if(target!=null)target.setText("Tú: "+question+"\n\nAnalista IA:\n"+answer);else new AlertDialog.Builder(this).setTitle("Analista IA").setMessage(answer).setPositiveButton("Cerrar",null).show();if(send!=null)send.setEnabled(true);});
            }catch(Exception ex){runOnUiThread(()->{if(target!=null)target.setText("No se pudo conectar con el Analista IA.\n\nComprueba la dirección del servidor en Más → Conexión IA.\n\n"+ex.getClass().getSimpleName());else Toast.makeText(this,"No se pudo conectar con el servidor IA",Toast.LENGTH_LONG).show();if(send!=null)send.setEnabled(true);});}
        }).start();
    }

    void showSettings(){clear("Más","Configuración y explicación del sistema");section("Analista IA"); LinearLayout ia=box(14); TextView ih=txt("Conectar asistente financiero",15,fg(),true);ia.addView(ih); TextView id=txt("Introduce la URL de tu servidor IA. La clave de OpenAI debe permanecer en el servidor, nunca dentro del APK.",12,muted(),false);margin(id,0,7,0,0);ia.addView(id); EditText ie=field("https://tu-servidor/chat");ie.setText(backend);ia.addView(ie);Button ib=button("Guardar conexión IA",BLUE);margin(ib,7,0,0,0);ia.addView(ib);add(ia);ib.setOnClickListener(v->{backend=ie.getText().toString().trim();getPreferences(0).edit().putString("backend",backend).apply();status.setText("Conexión IA guardada");});section("Apariencia");LinearLayout x=box(14);TextView t=txt("Tema de la aplicación",15,fg(),true);x.addView(t);TextView d=txt(dark?"Oscuro activo":"Claro activo",12,muted(),false);margin(d,0,6,0,0);x.addView(d);Button sw=button(dark?"☀  Cambiar a modo claro":"☾  Cambiar a modo oscuro",dark?BLUE:Color.rgb(40,48,70));margin(sw,0,8,0,0);x.addView(sw);add(x);sw.setOnClickListener(v->{dark=!dark;getPreferences(0).edit().putBoolean("dark",dark).apply();build();showSettings();});section("Cómo funciona");explainCard("La puntuación no es una probabilidad","0–100 resume los factores configurados. La señal de entrada o salida depende de reglas adicionales y del estado de la posición.",BLUE);section("Conexión opcional");EditText e=field("http://192.168.1.50:8000");e.setText(backend);add(e);Button save=button("Guardar conexión",BLUE);margin(save,0,8,0,0);add(save);save.setOnClickListener(v->{backend=e.getText().toString().trim();getPreferences(0).edit().putString("backend",backend).apply();status.setText("Conexión guardada");});}

    String get(String u)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(10000);c.setRequestProperty("User-Agent","InvestAI/2.0");BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream()));StringBuilder b=new StringBuilder();String l;while((l=r.readLine())!=null)b.append(l);r.close();return b.toString();}
}
