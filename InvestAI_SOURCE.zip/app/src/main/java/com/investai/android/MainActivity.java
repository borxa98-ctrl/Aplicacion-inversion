package com.investai.android;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.content.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    TextView title, status;
    String backend = "";
    final String[] indices = {"S&P 500","Nasdaq-100","Dow Jones","Russell 2000","EURO STOXX 50","STOXX Europe 600","DAX 40","FTSE 100","CAC 40","IBEX 35","SMI","Nikkei 225","TOPIX","Hang Seng","S&P/ASX 200"};
    final String[] symbols = {"AAPL","MSFT","NVDA","AMZN","GOOGL","META","AVGO","JPM","LLY","XOM"};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        backend = getPreferences(0).getString("backend","");
        build();
        showHome();
    }

    TextView tv(String s, int sp) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(Color.WHITE);
        t.setPadding(18,14,18,14); return t;
    }

    void build() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(11,16,32));
        title = tv("Invest AI", 24); title.setTypeface(null,1);
        root.addView(title, new LinearLayout.LayoutParams(-1,70));
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(this); sv.addView(content);
        root.addView(sv, new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav = new LinearLayout(this); nav.setPadding(4,4,4,4);
        String[] ns={"Inicio","Mercados","Top global","Cartera","Ajustes"};
        for(String n:ns){ Button x=new Button(this); x.setText(n); x.setTextSize(11);
            nav.addView(x,new LinearLayout.LayoutParams(0,60,1));
            if(n.equals("Inicio")) x.setOnClickListener(v->showHome());
            if(n.equals("Mercados")) x.setOnClickListener(v->showMarkets());
            if(n.equals("Top global")) x.setOnClickListener(v->showGlobal());
            if(n.equals("Cartera")) x.setOnClickListener(v->showPortfolio());
            if(n.equals("Ajustes")) x.setOnClickListener(v->showSettings());
        }
        root.addView(nav);
        status=tv("Conectando…",12); status.setTextColor(Color.LTGRAY); root.addView(status,new LinearLayout.LayoutParams(-1,42));
        setContentView(root);
    }

    void clear(String t){ content.removeAllViews(); title.setText(t); }
    void card(String text){
        TextView c=tv(text,16); c.setBackgroundColor(Color.rgb(22,30,52));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(10,8,10,8); content.addView(c,p);
    }

    void showHome(){
        clear("Invest AI");
        card("GUÍA DE INVERSIÓN\\nPuntuación de oportunidad: 0–100\\n\\nEl motor combina tendencia, riesgo, noticias y datos disponibles. No ejecuta operaciones automáticamente.");
        card("🚨 SALIDAS\\nMANTENER · VIGILAR · PREPARAR SALIDA · SALIDA\\n\\nLa señal de salida se calcula como alerta, no como ejecución.");
        card("🏆 TOP GLOBAL\\nConsulta las oportunidades agregadas de los índices seleccionados.");
        status.setText("Modo: " + (backend.isEmpty() ? "datos públicos móviles" : "backend conectado"));
    }

    void showMarkets(){
        clear("Mercados");
        for(String i:indices) card(i+"\\nTop 10 · puntuación 0–100\\nPulsa Top global para ver la selección agregada.");
    }

    void showGlobal(){
        clear("Top global");
        status.setText("Actualizando precios…");
        new Thread(()->{
            final ArrayList<String> out=new ArrayList<>();
            for(String s:symbols){
                try{
                    JSONObject j=new JSONObject(get("https://query1.finance.yahoo.com/v8/finance/chart/"+s+"?range=3mo&interval=1d"));
                    JSONArray a=j.getJSONObject("chart").getJSONArray("result").getJSONObject(0).getJSONObject("indicators").getJSONArray("quote").getJSONObject(0).getJSONArray("close");
                    ArrayList<Double> v=new ArrayList<>();
                    for(int k=0;k<a.length();k++) if(!a.isNull(k)) v.add(a.getDouble(k));
                    if(v.size()>25){
                        double last=v.get(v.size()-1), old=v.get(Math.max(0,v.size()-21));
                        double r=(last/old-1)*100;
                        double score=Math.max(0,Math.min(100,50+r*5));
                        out.add(s+"  ·  "+String.format(Locale.US,"%.1f/100",score)+"  ·  "+String.format(Locale.US,"%.2f%%",r));
                    }
                }catch(Exception e){ out.add(s+"  ·  datos no disponibles"); }
            }
            Collections.sort(out);
            runOnUiThread(()->{
                content.removeAllViews();
                card("TOP GLOBAL — selección técnica móvil");
                for(String x:out) card(x);
                status.setText("Actualizado: "+new Date());
            });
        }).start();
    }

    void showPortfolio(){
        clear("Mi cartera");
        card("Posiciones de MyInvestor\\nSe introducen manualmente para mantener la aplicación privada y sin credenciales bancarias.");
        EditText sym=new EditText(this); sym.setHint("Ticker, ej. NVDA"); sym.setTextColor(Color.WHITE); sym.setHintTextColor(Color.GRAY);
        EditText shares=new EditText(this); shares.setHint("Nº acciones"); shares.setInputType(2); shares.setTextColor(Color.WHITE);
        Button add=new Button(this); add.setText("Añadir posición");
        content.addView(sym); content.addView(shares); content.addView(add);
        add.setOnClickListener(v->{ if(sym.getText().length()>0) card("📌 "+sym.getText()+" · "+shares.getText()+" acciones\\nEstado: calcular al actualizar");});
    }

    void showSettings(){
        clear("Ajustes");
        card("Backend opcional\\nSi tienes el motor Invest AI ejecutándose en un ordenador de tu red, introduce aquí su dirección para que el móvil lo utilice.");
        EditText e=new EditText(this); e.setText(backend); e.setHint("http://192.168.1.50:8000"); e.setTextColor(Color.WHITE); e.setHintTextColor(Color.GRAY);
        Button save=new Button(this); save.setText("Guardar conexión");
        content.addView(e); content.addView(save);
        save.setOnClickListener(v->{backend=e.getText().toString().trim(); getPreferences(0).edit().putString("backend",backend).apply(); status.setText("Conexión guardada");});
        card("Fuentes públicas\\nPrecios: Yahoo Finance (endpoint público)\\nNoticias: GDELT\\nEl motor completo puede añadir SEC/EDGAR, ECB, FRED y el histórico local.");
    }

    String get(String u) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();
        c.setRequestMethod("GET"); c.setConnectTimeout(10000); c.setReadTimeout(15000);
        c.setRequestProperty("User-Agent","InvestAI/1.0");
        BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream()));
        StringBuilder b=new StringBuilder(); String line; while((line=r.readLine())!=null)b.append(line);
        r.close(); return b.toString();
    }
}