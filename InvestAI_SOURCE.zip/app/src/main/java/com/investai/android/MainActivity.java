package com.investai.android;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import java.util.*;
import java.net.*;
import java.io.*;
import org.json.*;

public class MainActivity extends Activity {
    LinearLayout root, content, nav;
    TextView title, subtitle, status;
    boolean dark = true;
    String backend = "";
    final int GREEN=Color.rgb(39,201,139), YELLOW=Color.rgb(245,190,70), ORANGE=Color.rgb(255,145,80), RED=Color.rgb(245,88,88), BLUE=Color.rgb(78,124,255), CYAN=Color.rgb(72,190,255);
    final String[] indices={"S&P 500","Nasdaq-100","Dow Jones","Russell 2000","EURO STOXX 50","STOXX Europe 600","DAX 40","FTSE 100","CAC 40","IBEX 35","SMI","Nikkei 225","TOPIX","Hang Seng","S&P/ASX 200"};
    final String[] symbols={"NVDA","MSFT","AMZN","META","GOOGL","AVGO","AAPL","LLY","JPM","XOM"};

    @Override public void onCreate(Bundle b){super.onCreate(b); dark=getPreferences(0).getBoolean("dark",true); backend=getPreferences(0).getString("backend",""); safeStart();}
    void safeStart(){try{build();showHome();}catch(Throwable e){fallback(e);}}
    void fallback(Throwable e){ LinearLayout f=new LinearLayout(this); f.setOrientation(LinearLayout.VERTICAL); f.setPadding(dp(24),dp(32),dp(24),dp(24)); f.setBackgroundColor(bg()); TextView h=txt("Invest AI",28,fg(),true); f.addView(h); TextView m=txt("No se ha podido cargar la interfaz.",16,fg(),false); margin(m,0,16,0,0); f.addView(m); TextView d=txt(e.getClass().getSimpleName(),12,muted(),false); f.addView(d); Button r=button("Reintentar",BLUE); margin(r,0,18,0,0); f.addView(r); r.setOnClickListener(v->safeStart()); setContentView(f); }

    int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    int bg(){return dark?Color.rgb(8,12,24):Color.rgb(246,248,252);} int card(){return dark?Color.rgb(18,25,43):Color.WHITE;} int card2(){return dark?Color.rgb(25,34,56):Color.rgb(238,242,248);} int fg(){return dark?Color.WHITE:Color.rgb(24,31,45);} int muted(){return dark?Color.rgb(158,170,194):Color.rgb(95,105,125);}
    TextView txt(String s,float size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL);t.setIncludeFontPadding(false);return t;}
    GradientDrawable shape(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp((int)r));return g;}
    void margin(View v,int l,int t,int r,int b){ViewGroup.LayoutParams lp=v.getLayoutParams();LinearLayout.LayoutParams p=lp instanceof LinearLayout.LayoutParams?(LinearLayout.LayoutParams)lp:new LinearLayout.LayoutParams(-2,-2);p.setMargins(dp(l),dp(t),dp(r),dp(b));v.setLayoutParams(p);}
    LinearLayout box(int pad){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(pad),dp(pad),dp(pad),dp(pad));l.setBackground(shape(card(),18));return l;}
    void add(View v){content.addView(v,new LinearLayout.LayoutParams(-1,-2)); animate(v);}
    void animate(View v){v.setAlpha(0f);v.setTranslationY(dp(6));v.animate().alpha(1f).translationY(0).setDuration(180).start();}
    TextView pill(String s,int c){TextView p=txt(s,11,c,true);p.setGravity(Gravity.CENTER);p.setPadding(dp(10),dp(7),dp(10),dp(7));p.setBackground(shape(Color.argb(dark?42:25,Color.red(c),Color.green(c),Color.blue(c)),20));return p;}
    Button button(String s,int c){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(13);b.setAllCaps(false);b.setBackground(shape(c,14));return b;}

    void build(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg());
        LinearLayout header=new LinearLayout(this);header.setOrientation(LinearLayout.HORIZONTAL);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(18),dp(15),dp(18),dp(12));
        LinearLayout htxt=new LinearLayout(this);htxt.setOrientation(LinearLayout.VERTICAL);title=txt("Invest AI",24,fg(),true);htxt.addView(title);subtitle=txt("Decisiones explicadas visualmente",12,muted(),false);margin(subtitle,0,5,0,0);htxt.addView(subtitle);header.addView(htxt,new LinearLayout.LayoutParams(0,-2,1));
        TextView mode=txt(dark?"☀":"☾",23,fg(),false);mode.setGravity(Gravity.CENTER);mode.setPadding(dp(8),dp(5),dp(8),dp(5));mode.setBackground(shape(card2(),16));header.addView(mode,new LinearLayout.LayoutParams(dp(44),dp(44)));mode.setOnClickListener(v->{dark=!dark;getPreferences(0).edit().putBoolean("dark",dark).apply();build();showHome();});
        root.addView(header,new LinearLayout.LayoutParams(-1,-2));
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(14),0,dp(14),dp(16));ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        nav=new LinearLayout(this);nav.setPadding(dp(7),dp(6),dp(7),dp(5));nav.setBackgroundColor(dark?Color.rgb(13,18,32):Color.WHITE);String[] ns={"⌂\nInicio","◉\nSeñales","◫\nMercados","▣\nCartera","⋯\nMás"};
        for(String n:ns){TextView x=txt(n,10,muted(),true);x.setGravity(Gravity.CENTER);x.setLineSpacing(0,0.85f);nav.addView(x,new LinearLayout.LayoutParams(0,dp(58),1));String key=n.substring(n.indexOf('\n')+1);if(key.equals("Inicio"))x.setOnClickListener(v->showHome());if(key.equals("Señales"))x.setOnClickListener(v->showSignals());if(key.equals("Mercados"))x.setOnClickListener(v->showMarkets());if(key.equals("Cartera"))x.setOnClickListener(v->showPortfolio());if(key.equals("Más"))x.setOnClickListener(v->showSettings());}
        root.addView(nav);status=txt("Datos públicos · modo visual",10,muted(),false);status.setGravity(Gravity.CENTER);root.addView(status,new LinearLayout.LayoutParams(-1,dp(25)));setContentView(root);
    }
    void clear(String t,String sub){content.removeAllViews();title.setText(t);subtitle.setText(sub);}
    TextView section(String s){TextView t=txt(s,18,fg(),true);margin(t,5,15,4,7);add(t);return t;}

    LinearLayout metric(String label,String value,String sub,int c){LinearLayout x=box(14);TextView l=txt(label.toUpperCase(Locale.US),10,muted(),true);x.addView(l);TextView v=txt(value,24,fg(),true);margin(v,0,7,0,0);x.addView(v);TextView q=txt(sub,11,c,true);x.addView(q);return x;}
    void showHome(){clear("Invest AI","Tu dinero, explicado de un vistazo");TextView badge=pill("●  DATOS DE DEMOSTRACIÓN",YELLOW);margin(badge,0,3,0,10);add(badge);section("Resumen de cartera");LinearLayout row=new LinearLayout(this);row.addView(metric("Valor","12.480 €","+346 € este mes",GREEN),new LinearLayout.LayoutParams(0,-2,1));LinearLayout b=metric("Resultado","+2,84 %","Evolución mensual",GREEN);margin(b,7,0,0,0);row.addView(b,new LinearLayout.LayoutParams(0,-2,1));add(row);
        section("Qué necesita tu atención");signalCard("🟢","3 entradas detectadas","Hay valores que cumplen las condiciones de entrada del modelo.",GREEN,"Ver entradas",()->showSignals());signalCard("🟠","2 posiciones a vigilar","El motor ha detectado señales de deterioro que conviene revisar.",ORANGE,"Ver cartera",()->showPortfolio());
        section("Lectura rápida del mercado");miniMarket("S&P 500",82,"Tendencia positiva",GREEN);miniMarket("Nasdaq-100",89,"Momentum fuerte",GREEN);miniMarket("IBEX 35",64,"Entorno mixto",YELLOW);
        section("Lo importante");explainCard("No necesitas interpretar 7 indicadores","Invest AI convierte valoración, crecimiento, tendencia, revisiones, noticias y riesgo en una lectura visual.",BLUE);
    }
    void signalCard(String icon,String head,String body,int c,String action,Runnable r){LinearLayout x=box(14);LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);TextView i=txt(icon,25,fg(),false);top.addView(i,new LinearLayout.LayoutParams(dp(38),dp(42)));LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);TextView h=txt(head,15,fg(),true);tx.addView(h);TextView bd=txt(body,12,muted(),false);margin(bd,0,5,0,0);tx.addView(bd);top.addView(tx,new LinearLayout.LayoutParams(0,-2,1));x.addView(top);TextView go=txt("›  "+action,12,c,true);margin(go,dp(38),10,0,0);x.addView(go);x.setOnClickListener(v->r.run());margin(x,0,4,0,4);add(x);}
    void miniMarket(String name,int score,String hint,int c){LinearLayout x=box(13);LinearLayout top=new LinearLayout(this);TextView n=txt(name,14,fg(),true);top.addView(n,new LinearLayout.LayoutParams(0,-2,1));TextView s=txt(score+"/100",15,c,true);top.addView(s);x.addView(top);TextView h=txt("● "+hint,11,muted(),false);margin(h,0,7,0,0);x.addView(h);addProgress(x,score,c);margin(x,0,3,0,3);}
    void addProgress(LinearLayout parent,int score,int c){FrameLayout fr=new FrameLayout(this);fr.setPadding(0,0,0,0);TextView base=txt("",1,fg(),false);base.setBackground(shape(card2(),8));fr.addView(base,new FrameLayout.LayoutParams(-1,dp(7)));TextView fill=txt("",1,fg(),false);fill.setBackground(shape(c,8));FrameLayout.LayoutParams fp=new FrameLayout.LayoutParams(dp(Math.max(8,score*2)),dp(7));fr.addView(fill,fp);parent.addView(fr);}
    void explainCard(String h,String b,int c){LinearLayout x=box(15);TextView a=txt("CÓMO LEERLO",10,c,true);x.addView(a);TextView t=txt(h,16,fg(),true);margin(t,0,7,0,0);x.addView(t);TextView d=txt(b,12,muted(),false);x.addView(d);margin(x,0,4,0,4);add(x);}

    void showSignals(){clear("Señales","Entradas y cambios que merecen atención");section("Entradas detectadas");entry("NVIDIA","178,42 €","92/100","Zona 172–180 €","Momentum + beneficios + revisiones",GREEN);entry("Microsoft","512,30 €","87/100","Zona 500–515 €","Tendencia + fundamentales",GREEN);entry("Amazon","229,10 €","84/100","Zona 220–230 €","Crecimiento + revisiones",GREEN);section("Qué significa una entrada");explainCard("No es una garantía de rentabilidad","La etiqueta aparece cuando el conjunto de factores definidos por el motor alcanza las condiciones de entrada.",BLUE);section("Escala de decisión");decision("🟢 ENTRADA","Condiciones favorables para estudiar una posición.",GREEN);decision("🔵 MANTENER","La tesis sigue sin deterioro relevante.",CYAN);decision("🟡 VIGILAR","Hay señales que requieren seguimiento.",YELLOW);decision("🟠 PREPARAR SALIDA","El deterioro ya es suficiente para revisar la posición.",ORANGE);decision("🔴 SALIDA","El motor detecta señales críticas.",RED);}
    void entry(String name,String price,String score,String zone,String why,int c){LinearLayout x=box(15);LinearLayout top=new LinearLayout(this);TextView n=txt(name,19,fg(),true);top.addView(n,new LinearLayout.LayoutParams(0,-2,1));top.addView(pill("🟢 ENTRADA",c));x.addView(top);TextView p=txt(price,25,fg(),true);margin(p,0,9,0,0);x.addView(p);TextView sc=txt("Puntuación "+score,13,c,true);x.addView(sc);TextView z=txt("Zona de entrada  ·  "+zone,12,muted(),false);margin(z,0,7,0,0);x.addView(z);TextView w=txt("¿Por qué?  "+why,12,fg(),false);x.addView(w);margin(x,0,5,0,5);add(x);}
    void decision(String h,String b,int c){LinearLayout x=box(12);TextView a=txt(h,14,c,true);x.addView(a);TextView d=txt(b,11,muted(),false);margin(d,0,4,0,0);x.addView(d);add(x);}

    void showMarkets(){clear("Mercados","15 índices · entender el entorno sin leer una tabla");section("Mapa del mercado");int[] sc={82,89,74,68,77,73,80,71,70,64,76,83,79,69,72};for(int i=0;i<indices.length;i++)indexCard(indices[i],sc[i]);}
    void indexCard(String name,int score){int c=score>=80?GREEN:score>=70?BLUE:YELLOW;LinearLayout x=box(14);LinearLayout top=new LinearLayout(this);TextView n=txt(name,15,fg(),true);top.addView(n,new LinearLayout.LayoutParams(0,-2,1));top.addView(pill(score>=80?"FAVORABLE":score>=70?"MIXTO":"PRECAUCIÓN",c));x.addView(top);TextView s=txt(score+" / 100",22,fg(),true);margin(s,0,10,0,0);x.addView(s);addProgress(x,score,c);TextView h=txt(score>=80?"La tendencia y el momentum apoyan el entorno.":score>=70?"Hay señales positivas y otras mixtas.":"El entorno requiere más prudencia.",11,muted(),false);margin(h,0,7,0,0);x.addView(h);margin(x,0,4,0,4);add(x);}

    void showPortfolio(){clear("Mi cartera","Qué tienes, cómo va y qué debería vigilarse");section("Resumen");LinearLayout row=new LinearLayout(this);row.addView(metric("Invertido","12.134 €","Capital aportado",BLUE),new LinearLayout.LayoutParams(0,-2,1));LinearLayout m=metric("Actual","12.480 €","+346 € · +2,84 %",GREEN);margin(m,7,0,0,0);row.addView(m,new LinearLayout.LayoutParams(0,-2,1));add(row);section("Posiciones");holding("NVIDIA","12 acciones","+8,4 %","92/100","🟢 MANTENER",GREEN);holding("Microsoft","8 acciones","+4,1 %","87/100","🟢 MANTENER",GREEN);holding("Tesla","5 acciones","−4,2 %","61/100","🟡 VIGILAR",YELLOW);section("Añadir posición");EditText e=field("Ticker · ej. NVDA");add(e);EditText q=field("Número de acciones");q.setInputType(2);margin(q,0,8,0,0);add(q);Button b=button("＋  Añadir posición",BLUE);margin(b,0,8,0,0);add(b);b.setOnClickListener(v->{if(e.getText().length()>0){holding(e.getText().toString().toUpperCase(Locale.US),q.getText().toString()+" acciones","Pendiente de datos","—","🔵 A ANALIZAR",CYAN);e.setText("");q.setText("");}});}
    void holding(String name,String qty,String ret,String score,String state,int c){LinearLayout x=box(14);LinearLayout top=new LinearLayout(this);TextView n=txt(name,16,fg(),true);top.addView(n,new LinearLayout.LayoutParams(0,-2,1));top.addView(pill(state,c));x.addView(top);LinearLayout mid=new LinearLayout(this);TextView q=txt(qty,12,muted(),false);mid.addView(q,new LinearLayout.LayoutParams(0,-2,1));TextView r=txt(ret,14,c,true);mid.addView(r);margin(mid,0,9,0,0);x.addView(mid);TextView s=txt("Puntuación  "+score,12,muted(),false);x.addView(s);margin(x,0,4,0,4);add(x);}
    EditText field(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextColor(fg());e.setHintTextColor(muted());e.setSingleLine(true);e.setBackground(shape(card2(),14));e.setPadding(dp(14),dp(11),dp(14),dp(11));return e;}

    void showSettings(){clear("Más","Configuración y explicación del sistema");section("Apariencia");LinearLayout x=box(14);TextView t=txt("Tema de la aplicación",15,fg(),true);x.addView(t);TextView d=txt(dark?"Oscuro activo":"Claro activo",12,muted(),false);margin(d,0,6,0,0);x.addView(d);Button sw=button(dark?"☀  Cambiar a modo claro":"☾  Cambiar a modo oscuro",dark?BLUE:Color.rgb(40,48,70));margin(sw,0,8,0,0);x.addView(sw);add(x);sw.setOnClickListener(v->{dark=!dark;getPreferences(0).edit().putBoolean("dark",dark).apply();build();showSettings();});section("Cómo funciona");explainCard("La puntuación no es una probabilidad","0–100 resume los factores configurados. La señal de entrada o salida depende de reglas adicionales y del estado de la posición.",BLUE);section("Conexión opcional");EditText e=field("http://192.168.1.50:8000");e.setText(backend);add(e);Button save=button("Guardar conexión",BLUE);margin(save,0,8,0,0);add(save);save.setOnClickListener(v->{backend=e.getText().toString().trim();getPreferences(0).edit().putString("backend",backend).apply();status.setText("Conexión guardada");});}

    String get(String u)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(10000);c.setRequestProperty("User-Agent","InvestAI/2.0");BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream()));StringBuilder b=new StringBuilder();String l;while((l=r.readLine())!=null)b.append(l);r.close();return b.toString();}
}
