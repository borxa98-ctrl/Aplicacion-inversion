package com.investai.android;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    TextView title, subtitle, status;
    String backend = "";
    final int BG = Color.rgb(8,12,24), CARD = Color.rgb(18,25,43), CARD2 = Color.rgb(24,32,54);
    final int TEXT = Color.WHITE, MUTED = Color.rgb(158,170,194), BLUE = Color.rgb(79,124,255);
    final String[] indices = {"S&P 500","Nasdaq-100","Dow Jones","Russell 2000","EURO STOXX 50","STOXX Europe 600","DAX 40","FTSE 100","CAC 40","IBEX 35","SMI","Nikkei 225","TOPIX","Hang Seng","S&P/ASX 200"};
    final String[] symbols = {"NVDA","MSFT","AMZN","META","GOOGL","AVGO","AAPL","LLY","JPM","XOM"};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        try {
            backend = getPreferences(0).getString("backend","");
            build();
            showHome();
        } catch (Throwable e) {
            showStartupError(e);
        }
    }

    void showStartupError(Throwable e){
        LinearLayout fallback=new LinearLayout(this);
        fallback.setOrientation(LinearLayout.VERTICAL);
        fallback.setPadding(dp(24),dp(32),dp(24),dp(24));
        fallback.setBackgroundColor(BG);
        TextView h=text("Invest AI",26,TEXT,true); fallback.addView(h);
        TextView m=text("No se ha podido cargar la interfaz. La aplicación sigue instalada.",16,TEXT,false); margin(m,0,18,0,0); fallback.addView(m);
        TextView d=text("Error: "+e.getClass().getSimpleName(),13,MUTED,false); fallback.addView(d);
        Button b=new Button(this); b.setText("Reintentar"); b.setAllCaps(false); b.setTextColor(TEXT); b.setBackground(bg(BLUE,14)); margin(b,0,18,0,0); fallback.addView(b);
        b.setOnClickListener(v->{ build(); showHome(); });
        setContentView(fallback);
    }

    int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    TextView text(String s, float sp, int color, boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT, bold?Typeface.BOLD:Typeface.NORMAL); t.setIncludeFontPadding(false); return t;
    }
    GradientDrawable bg(int color, float radius){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp((int)radius)); return g; }
    LinearLayout box(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(16),dp(14),dp(16),dp(14)); return l; }
    void add(View v){ content.addView(v,new LinearLayout.LayoutParams(-1,-2)); }
    void margin(View v,int l,int t,int r,int b){
        ViewGroup.LayoutParams lp=v.getLayoutParams();
        LinearLayout.LayoutParams p;
        if(lp instanceof LinearLayout.LayoutParams) p=(LinearLayout.LayoutParams)lp;
        else p=new LinearLayout.LayoutParams(-2,-2);
        p.setMargins(dp(l),dp(t),dp(r),dp(b));
        v.setLayoutParams(p);
    }

    void build(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        LinearLayout header=new LinearLayout(this); header.setOrientation(LinearLayout.VERTICAL); header.setPadding(dp(18),dp(16),dp(18),dp(12));
        title=text("Invest AI",25,TEXT,true); header.addView(title);
        subtitle=text("Inteligencia para tus inversiones",13,MUTED,false); margin(subtitle,0,5,0,0); header.addView(subtitle);
        root.addView(header,new LinearLayout.LayoutParams(-1,-2));
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(14),dp(2),dp(14),dp(18));
        ScrollView sv=new ScrollView(this); sv.setFillViewport(true); sv.addView(content); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav=new LinearLayout(this); nav.setPadding(dp(6),dp(6),dp(6),dp(6)); nav.setBackgroundColor(Color.rgb(13,18,32));
        String[] ns={"Inicio","Mercados","Oportunidades","Cartera","Más"};
        for(String n:ns){ TextView x=text(n,11,MUTED,true); x.setGravity(Gravity.CENTER); x.setPadding(2,dp(10),2,dp(10)); nav.addView(x,new LinearLayout.LayoutParams(0,dp(54),1));
            if(n.equals("Inicio")) x.setOnClickListener(v->showHome());
            if(n.equals("Mercados")) x.setOnClickListener(v->showMarkets());
            if(n.equals("Oportunidades")) x.setOnClickListener(v->showGlobal());
            if(n.equals("Cartera")) x.setOnClickListener(v->showPortfolio());
            if(n.equals("Más")) x.setOnClickListener(v->showSettings());
        }
        root.addView(nav);
        status=text("Datos públicos · móvil",11,MUTED,false); status.setGravity(Gravity.CENTER); root.addView(status,new LinearLayout.LayoutParams(-1,dp(30)));
        setContentView(root);
    }

    void clear(String t){ content.removeAllViews(); title.setText(t); subtitle.setText(t.equals("Invest AI")?"Inteligencia para tus inversiones":"Análisis visual y accionable"); }
    LinearLayout card(String label,String value,String extra,int accent){
        LinearLayout c=box(); c.setBackground(bg(CARD,18));
        TextView a=text(label.toUpperCase(Locale.US),11,MUTED,true); c.addView(a);
        TextView v=text(value,24,TEXT,true); margin(v,0,7,0,0); c.addView(v);
        if(extra!=null){ TextView e=text(extra,12,accent,false); margin(e,0,3,0,0); c.addView(e); }
        margin(c,0,6,0,6); add(c); return c;
    }
    TextView section(String s){ TextView t=text(s,17,TEXT,true); margin(t,4,14,4,6); add(t); return t; }
    TextView pill(String s,int color){ TextView p=text(s,11,color,true); p.setGravity(Gravity.CENTER); p.setPadding(dp(10),dp(7),dp(10),dp(7)); p.setBackground(bg(Color.argb(35,Color.red(color),Color.green(color),Color.blue(color)),20)); return p; }

    LinearLayout scoreRow(String name,int score,String trend,String state){
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(14),dp(13),dp(12),dp(13)); row.setBackground(bg(CARD,16));
        LinearLayout left=new LinearLayout(this); left.setOrientation(LinearLayout.VERTICAL); TextView n=text(name,16,TEXT,true); left.addView(n); TextView tr=text(trend,11,MUTED,false); margin(tr,0,5,0,0); left.addView(tr);
        row.addView(left,new LinearLayout.LayoutParams(0,-2,1));
        TextView st=pill(state,state.equals("MANTENER")?Color.rgb(62,210,139):state.equals("VIGILAR")?Color.rgb(245,190,70):Color.rgb(255,120,75)); row.addView(st,new LinearLayout.LayoutParams(-2,-2));
        TextView sc=text(String.valueOf(score),22,TEXT,true); sc.setGravity(Gravity.CENTER); margin(sc,12,0,0,0); row.addView(sc,new LinearLayout.LayoutParams(dp(45),-2));
        margin(row,0,4,0,4); add(row); return row;
    }

    void showHome(){
        clear("Invest AI");
        TextView hi=text("Buenos días",14,MUTED,false); add(hi);
        section("Resumen");
        LinearLayout grid=new LinearLayout(this); grid.setOrientation(LinearLayout.HORIZONTAL);
        grid.addView(metric("Cartera","12.480 €","+2,84 %",Color.rgb(62,210,139)),new LinearLayout.LayoutParams(0,-2,1));
        grid.addView(metric("Oportunidades","7","> 80/100",BLUE),new LinearLayout.LayoutParams(0,-2,1)); add(grid);
        section("Qué está pasando");
        alertCard("🟢","Mercado estable","La señal agregada no muestra deterioro relevante.",Color.rgb(62,210,139));
        alertCard("🟠","2 posiciones a vigilar","El motor detecta pérdida de momentum en algunas posiciones.",Color.rgb(255,166,70));
        section("Mejores oportunidades");
        scoreRow("NVIDIA",92,"Momentum fuerte · crecimiento sólido","MANTENER");
        scoreRow("Microsoft",87,"Fundamentales fuertes · riesgo moderado","MANTENER");
        scoreRow("Amazon",84,"Revisiones positivas · momentum","MANTENER");
        section("Salida");
        scoreRow("Tesla",61,"Score deteriorándose · revisar posición","VIGILAR");
        scoreRow("Ejemplo cartera",48,"Señales técnicas + fundamentales débiles","PREPARAR");
    }

    LinearLayout metric(String label,String value,String extra,int accent){
        LinearLayout c=box(); c.setBackground(bg(CARD,18)); TextView l=text(label,11,MUTED,true); c.addView(l); TextView v=text(value,22,TEXT,true); margin(v,0,7,0,0); c.addView(v); TextView e=text(extra,11,accent,true); c.addView(e); margin(c,0,4,5,4); return c;
    }
    void alertCard(String icon,String titleText,String body,int color){
        LinearLayout c=box(); c.setOrientation(LinearLayout.HORIZONTAL); c.setBackground(bg(CARD,16));
        TextView i=text(icon,24,TEXT,false); i.setGravity(Gravity.CENTER); c.addView(i,new LinearLayout.LayoutParams(dp(38),dp(50)));
        LinearLayout tx=new LinearLayout(this); tx.setOrientation(LinearLayout.VERTICAL); TextView t=text(titleText,15,TEXT,true); tx.addView(t); TextView b=text(body,12,MUTED,false); margin(b,0,5,0,0); tx.addView(b); c.addView(tx,new LinearLayout.LayoutParams(0,-2,1));
        margin(c,0,4,0,4); add(c);
    }

    void showMarkets(){
        clear("Mercados");
        TextView intro=text("15 índices · una lectura rápida del mercado",13,MUTED,false); add(intro);
        section("Índices seleccionados");
        int[] sc={82,89,74,68,77,73,80,71,70,64,76,83,79,69,72};
        for(int k=0;k<indices.length;k++) indexCard(indices[k],sc[k]);
    }
    void indexCard(String name,int score){
        LinearLayout c=box(); c.setBackground(bg(CARD,16)); LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView n=text(name,15,TEXT,true); top.addView(n,new LinearLayout.LayoutParams(0,-2,1)); TextView s=text(score+"/100",17,TEXT,true); top.addView(s); c.addView(top);
        TextView bar=text("",1,TEXT,false); bar.setBackground(bg(Color.rgb(48,62,92),8)); margin(bar,0,12,0,0); c.addView(bar,new LinearLayout.LayoutParams(-1,dp(7)));
        TextView fill=text("",1,TEXT,false); fill.setBackground(bg(score>=80?Color.rgb(62,210,139):score>=70?BLUE:Color.rgb(245,190,70),8));
        LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(dp(score*2),dp(7)); fp.gravity=Gravity.TOP; c.addView(fill,fp);
        TextView hint=text(score>=80?"Entorno favorable":score>=70?"Entorno mixto":"Precaución",11,MUTED,false); margin(hint,0,8,0,0); c.addView(hint);
        margin(c,0,4,0,4); add(c);
    }

    void showGlobal(){
        clear("Oportunidades");
        TextView intro=text("Ranking visual de valores con mayor puntuación disponible.",13,MUTED,false); add(intro);
        section("Top global");
        TextView refresh=text("Actualizando precios…",11,MUTED,false); add(refresh);
        new Thread(()->{
            final ArrayList<String[]> out=new ArrayList<>();
            for(String s:symbols){
                try{
                    JSONObject j=new JSONObject(get("https://query1.finance.yahoo.com/v8/finance/chart/"+s+"?range=3mo&interval=1d"));
                    JSONArray a=j.getJSONObject("chart").getJSONArray("result").getJSONObject(0).getJSONObject("indicators").getJSONArray("quote").getJSONObject(0).getJSONArray("close");
                    ArrayList<Double> v=new ArrayList<>(); for(int k=0;k<a.length();k++) if(!a.isNull(k)) v.add(a.getDouble(k));
                    if(v.size()>25){ double last=v.get(v.size()-1),old=v.get(Math.max(0,v.size()-21)); double r=(last/old-1)*100; int score=(int)Math.max(0,Math.min(100,50+r*5)); out.add(new String[]{s,String.valueOf(score),String.format(Locale.US,"%+.2f%%  ·  1 mes",r)}); }
                }catch(Exception e){ out.add(new String[]{s,"—","Datos no disponibles"}); }
            }
            runOnUiThread(()->{ content.removeAllViews(); TextView h=text("Top global",22,TEXT,true); add(h); TextView d=text("Ordenado por señal técnica disponible",12,MUTED,false); add(d); Collections.sort(out,(a,b)->{try{return Integer.compare(Integer.parseInt(b[1]),Integer.parseInt(a[1]));}catch(Exception e){return 0;}}); for(String[] x:out){ int score=x[1].equals("—")?0:Integer.parseInt(x[1]); scoreRow(x[0],score,x[2],score>=80?"MANTENER":score>=60?"VIGILAR":"PREPARAR"); } status.setText("Actualizado: "+new Date()); });
        }).start();
    }

    void showPortfolio(){
        clear("Mi cartera");
        TextView intro=text("Introduce tus posiciones de MyInvestor. No guardamos credenciales bancarias.",13,MUTED,false); add(intro);
        section("Resumen");
        card("VALOR TOTAL","12.480 €","+346 € · +2,84 %",Color.rgb(62,210,139));
        section("Añadir posición");
        EditText sym=new EditText(this); sym.setHint("Ticker · ej. NVDA"); sym.setTextColor(TEXT); sym.setHintTextColor(Color.rgb(105,115,135)); sym.setSingleLine(true); sym.setBackground(bg(CARD2,14)); sym.setPadding(dp(14),dp(12),dp(14),dp(12)); add(sym);
        EditText shares=new EditText(this); shares.setHint("Número de acciones"); shares.setInputType(2); shares.setTextColor(TEXT); shares.setHintTextColor(Color.rgb(105,115,135)); shares.setSingleLine(true); shares.setBackground(bg(CARD2,14)); shares.setPadding(dp(14),dp(12),dp(14),dp(12)); margin(shares,0,8,0,0); add(shares);
        Button addBtn=new Button(this); addBtn.setText("＋  Añadir posición"); addBtn.setTextColor(TEXT); addBtn.setAllCaps(false); addBtn.setBackground(bg(BLUE,14)); margin(addBtn,0,8,0,0); add(addBtn);
        addBtn.setOnClickListener(v->{ if(sym.getText().length()>0){ scoreRow(sym.getText().toString().toUpperCase(Locale.US),0,"Posición añadida · actualizar para analizar","VIGILAR"); sym.setText(""); shares.setText(""); }});
        section("Posiciones");
        scoreRow("NVIDIA",92,"+3,8 % · 12 acciones","MANTENER"); scoreRow("Microsoft",87,"+1,9 % · 8 acciones","MANTENER"); scoreRow("Tesla",61,"-4,2 % · 5 acciones","VIGILAR");
    }

    void showSettings(){
        clear("Más");
        section("Conexión");
        TextView intro=text("Backend opcional. La app puede funcionar con datos públicos desde el móvil.",13,MUTED,false); add(intro);
        EditText e=new EditText(this); e.setText(backend); e.setHint("http://192.168.1.50:8000"); e.setTextColor(TEXT); e.setHintTextColor(Color.rgb(105,115,135)); e.setSingleLine(true); e.setBackground(bg(CARD2,14)); e.setPadding(dp(14),dp(12),dp(14),dp(12)); margin(e,0,10,0,0); add(e);
        Button save=new Button(this); save.setText("Guardar conexión"); save.setAllCaps(false); save.setTextColor(TEXT); save.setBackground(bg(BLUE,14)); add(save); save.setOnClickListener(v->{backend=e.getText().toString().trim();getPreferences(0).edit().putString("backend",backend).apply();status.setText("Conexión guardada");});
        section("Fuentes"); card("DATOS PÚBLICOS","Yahoo Finance · GDELT","El motor completo puede añadir SEC/EDGAR, ECB, FRED y datos históricos.",MUTED);
        section("Estados de salida"); alertCard("🟢","MANTENER","Sin deterioro relevante detectado.",Color.rgb(62,210,139)); alertCard("🟡","VIGILAR","Hay señales que requieren seguimiento.",Color.rgb(245,190,70)); alertCard("🟠","PREPARAR SALIDA","Deterioro suficiente para revisar la posición.",Color.rgb(255,166,70)); alertCard("🔴","SALIDA","Señales críticas según el motor.",Color.rgb(255,90,90));
    }

    String get(String u) throws Exception { HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection(); c.setRequestMethod("GET"); c.setConnectTimeout(10000); c.setReadTimeout(15000); c.setRequestProperty("User-Agent","InvestAI/1.1"); BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream())); StringBuilder b=new StringBuilder(); String line; while((line=r.readLine())!=null)b.append(line); r.close(); return b.toString(); }
}
